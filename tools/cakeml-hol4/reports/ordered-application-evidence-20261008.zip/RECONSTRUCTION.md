# Reconstruction scope

The development run checks 38 exports at CakeML
f8da03aeecd4d58a35bb88286780ff7e7e4ca7d6. The source-built original-release
run checks the same 31 macro/generated/search goals, excluding the seven
report witnesses whose theory depends on the incompatible parser hook.
No vendor prebuilt replay, complete SML97 bridge or macro machine-code
certificate is included.

The development checker was built from QuasarRay/HOL
bc025dff474b4dabff1a3d7606e929e492778fe8; the original-release checker was
built from HOL-Theorem-Prover/HOL's trindemossen-2 tag,
bdc6917eeafd45f1067c08b6061c2243c1b1edb0. Both used Poly/ML 5.9.2 from
4557554077078decce4ce5f90da00a713cfc32e4 (the exact git identity is also
recorded in host-toolchain.json). HOL4's tracked core sources were unchanged.
The receipts distinguish the release's shell launcher from its native
buildheap runner and runtime image.

## Development reconstruction

Use the pinned SML97 checkout c4212f434cafd06669171619f7d332341a5b31f3,
the exact report CakeML checkout and the retained MetaRocq reuse lock. Build
the selected HOL/CakeML prerequisites described in the qualification
workflow. Set HOLDIR, CAKEMLDIR, SML97DIR, HOL4_Z3_EXECUTABLE,
HOL4_TACTICTOE_CACHE and HOL4_EGGLOG_PYTHON to those explicit dependencies.
Run tools/cakeml-hol4/qualify_gap_report.sh. It creates a fresh run directory.

Verify the retained development manifest using:

```sh
python3 tools/cakeml-hol4/proof_bundle.py verify \
  --root /absolute/path/to/extracted/development \
  --manifest /absolute/path/to/extracted/development/bundle.json
```

A digest check is an integrity check. The proof scripts must be reconstructed
by the selected kernel; importing .dat exports alone is not proof replay.

## Original-release macro reconstruction

Build the unmodified release tag and its machine_ieee, integer_word and
mergesort prerequisites, then link them into sigobj. Select the original
release explicitly as HOLDIR. Stage a new context from a clean report checkout:

```sh
python3 tools/cakeml-hol4/materialize_release_context.py \
  --source /absolute/path/to/clean-report-cakeml \
  --output /absolute/path/to/new-release-context \
  --trindemossen2-proof-adapters \
  --legacy-tactictoe-cache /absolute/path/to/restored-metarocq-cache
```

The staging receipt identifies the 67 pre-adaptation inputs. The adaptation
receipt identifies the final three changed dependency files and every
replacement. All semantic definitions and theorem statements are retained.
The ten project ML files match the development proof sources exactly.

The old TacticToe uses HOLDIR/src/tactictoe/ttt_tacdata instead of an environment
override. Copy the generated legacy-tactictoe-hints files there under their
theory names, checking the receipt digests first and retaining existing
progress. These are raw untrusted candidates; the old release lacks the
modern manifest's ancestry validation. The observed release run loaded
1,503 of the 1,759 exported calls.

Set HOL_NOCONFIG=1, HOL4_Z3_EXECUTABLE to Z3 4.13.0,
HOL4_MACRO_REWRITES to development/macros/macro.rewrites and
HOL4_APPLICATION_REWRITES to development/macros/application.rewrites.
From the staged context run:

```sh
"$HOLDIR/bin/Holmake" --nolmbc --qof --no_preexecs --rebuild_deps -j2 \
  Hol4SmlMacroQualificationTheory.uo
"$HOLDIR/bin/hol" < Hol4SmlMacroInspect.sml
```

Require HOL4_MACRO_EXPORTS_INSPECTED 31 and successful guarded inspection.
The recorded run reconstructed both Egglog candidate goals, the Z3 proof and
the TacticToe theorem. Every selected export has no hypotheses, no axiom tags
and only ordinary DISK_THM dependency tags.

The report target is deliberately separate. temp_enable_pmatch is absent in
this release. ENABLE_PMATCH_CASES replaces ordinary case grammar and cannot
be substituted for the newer separate pmatch keyword without an equivalence
proof. The attempted substitution was removed; rejected-attempt.json and
failure logs preserve this boundary. No release parser witness is accepted.

## Remaining obligations

The authoritative SML97 typing, elaboration, value/closure relation and full
source lowering remain open, as do all-79 report certification, complete
runtime contracts and macro-generator machine-code equivalence. All seven
cited CakeML source authorities differ between the report pin f8da03a and
the existing compiler pin c98da7f. They cannot be combined into a machine
claim without a matching compiler reconstruction or a preservation theorem.
