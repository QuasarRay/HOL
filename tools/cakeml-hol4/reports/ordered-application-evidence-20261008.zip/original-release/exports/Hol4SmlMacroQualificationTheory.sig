signature Hol4SmlMacroQualificationTheory =
sig
  type thm = Thm.thm
  
  (*  Theorems  *)
    val egglog_application_replay : thm
    val egglog_sequence_replay : thm
    val generated_fn_application_expansion : thm
    val generated_fn_application_semantics : thm
    val generated_fn_closure : thm
    val generated_fn_expansion : thm
    val generated_left_application_expansion : thm
    val generated_left_application_semantics : thm
    val generated_match_expansion : thm
    val generated_match_semantics : thm
    val generated_sequence_expansion : thm
    val generated_sequence_semantics : thm
    val generated_variable_application_expansion : thm
    val generated_variable_application_semantics : thm
    val tactictoe_clause_count : thm
    val z3_clock_step : thm
(*
   [Hol4SmlApplication] Parent theory of "Hol4SmlMacroQualification"
   
   [HolSmt] Parent theory of "Hol4SmlMacroQualification"
   
   [egglog_application_replay]  Theorem
      
      ⊢ fname ≠ aname ∧ argument_binding_stable st env fname aexp ⇒
        evaluate st env [lower_sml_left_application fname aname fexp aexp] =
        sml_left_application_reference st env fexp aexp
   
   [egglog_sequence_replay]  Theorem
      
      ⊢ evaluate st env [Let NONE e1 e2] =
        sml_sequence_reference st env e1 e2
   
   [generated_fn_application_expansion]  Theorem
      
      ⊢ lower_sml_multifn_application «subject»
          [(Plit (IntLit 0),Lit (IntLit 10));
           (Plit (IntLit 1),Lit (IntLit 20))] (Short «sml_match_exception»)
          (Short «argument») =
        App Opapp
          [Fun «subject»
             (Mat (Var (Short «subject»))
                ([(Plit (IntLit 0),Lit (IntLit 10));
                  (Plit (IntLit 1),Lit (IntLit 20))] ++
                 [(Pany,Raise (Var (Short «sml_match_exception»)))]));
           Var (Short «argument»)]
   
   [generated_fn_application_semantics]  Theorem
      
      ⊢ nsLookup env.v (Short «argument») = SOME value ∧
        nsLookup (nsBind «subject» value env.v)
          (Short «sml_match_exception») = SOME match_value ⇒
        evaluate st env
          [App Opapp
             [Fun «subject»
                (Mat (Var (Short «subject»))
                   ([(Plit (IntLit 0),Lit (IntLit 10));
                     (Plit (IntLit 1),Lit (IntLit 20))] ++
                    [(Pany,Raise (Var (Short «sml_match_exception»)))]));
              Var (Short «argument»)]] =
        if st.clock = 0 then (st,Rerr (Rabort Rtimeout_error))
        else
          sml_match_reference (dec_clock st)
            (env with v := nsBind «subject» value env.v)
            (Var (Short «subject»))
            [(Plit (IntLit 0),Lit (IntLit 10));
             (Plit (IntLit 1),Lit (IntLit 20))] match_value
   
   [generated_fn_closure]  Theorem
      
      ⊢ evaluate st env
          [Fun «subject»
             (Mat (Var (Short «subject»))
                ([(Plit (IntLit 0),Lit (IntLit 10));
                  (Plit (IntLit 1),Lit (IntLit 20))] ++
                 [(Pany,Raise (Var (Short «sml_match_exception»)))]))] =
        (st,
         Rval
           [Closure env «subject»
              (lower_sml_match (Var (Short «subject»))
                 [(Plit (IntLit 0),Lit (IntLit 10));
                  (Plit (IntLit 1),Lit (IntLit 20))]
                 (Short «sml_match_exception»))])
   
   [generated_fn_expansion]  Theorem
      
      ⊢ lower_sml_multifn «subject»
          [(Plit (IntLit 0),Lit (IntLit 10));
           (Plit (IntLit 1),Lit (IntLit 20))] (Short «sml_match_exception») =
        Fun «subject»
          (Mat (Var (Short «subject»))
             ([(Plit (IntLit 0),Lit (IntLit 10));
               (Plit (IntLit 1),Lit (IntLit 20))] ++
              [(Pany,Raise (Var (Short «sml_match_exception»)))]))
   
   [generated_left_application_expansion]  Theorem
      
      ⊢ lower_sml_left_application «application_function»
          «application_argument» (Var (Short «function»)) (Lit (IntLit 7)) =
        Let (SOME «application_function») (Var (Short «function»))
          (Let (SOME «application_argument») (Lit (IntLit 7))
             (App Opapp
                [Var (Short «application_function»);
                 Var (Short «application_argument»)]))
   
   [generated_left_application_semantics]  Theorem
      
      ⊢ evaluate st env
          [Let (SOME «application_function») (Var (Short «function»))
             (Let (SOME «application_argument») (Lit (IntLit 7))
                (App Opapp
                   [Var (Short «application_function»);
                    Var (Short «application_argument»)]))] =
        sml_left_application_reference st env (Var (Short «function»))
          (Lit (IntLit 7))
   
   [generated_match_expansion]  Theorem
      
      ⊢ lower_sml_match (Var (Short «subject»))
          [(Plit (IntLit 0),Lit (IntLit 10));
           (Plit (IntLit 1),Lit (IntLit 20))] (Short «sml_match_exception») =
        Mat (Var (Short «subject»))
          ([(Plit (IntLit 0),Lit (IntLit 10));
            (Plit (IntLit 1),Lit (IntLit 20))] ++
           [(Pany,Raise (Var (Short «sml_match_exception»)))])
   
   [generated_match_semantics]  Theorem
      
      ⊢ nsLookup env.v (Short «sml_match_exception») = SOME match_value ⇒
        evaluate st env
          [Mat (Var (Short «subject»))
             ([(Plit (IntLit 0),Lit (IntLit 10));
               (Plit (IntLit 1),Lit (IntLit 20))] ++
              [(Pany,Raise (Var (Short «sml_match_exception»)))])] =
        sml_match_reference st env (Var (Short «subject»))
          [(Plit (IntLit 0),Lit (IntLit 10));
           (Plit (IntLit 1),Lit (IntLit 20))] match_value
   
   [generated_sequence_expansion]  Theorem
      
      ⊢ Let NONE (Lit (IntLit 1)) (Lit (IntLit 2)) =
        Let NONE (Lit (IntLit 1)) (Lit (IntLit 2))
   
   [generated_sequence_semantics]  Theorem
      
      ⊢ evaluate st env [Let NONE (Lit (IntLit 1)) (Lit (IntLit 2))] =
        sml_sequence_reference st env (Lit (IntLit 1)) (Lit (IntLit 2))
   
   [generated_variable_application_expansion]  Theorem
      
      ⊢ lower_sml_left_application «application_function»
          «application_argument» (Var (Short «function»))
          (Var (Short «argument»)) =
        Let (SOME «application_function») (Var (Short «function»))
          (Let (SOME «application_argument») (Var (Short «argument»))
             (App Opapp
                [Var (Short «application_function»);
                 Var (Short «application_argument»)]))
   
   [generated_variable_application_semantics]  Theorem
      
      ⊢ evaluate st env
          [Let (SOME «application_function») (Var (Short «function»))
             (Let (SOME «application_argument») (Var (Short «argument»))
                (App Opapp
                   [Var (Short «application_function»);
                    Var (Short «application_argument»)]))] =
        sml_left_application_reference st env (Var (Short «function»))
          (Var (Short «argument»))
   
   [tactictoe_clause_count]  Theorem
      
      ⊢ ∀clauses.
          LENGTH
            (clauses ++ [(Pany,Raise (Var (Short «sml_match_exception»)))]) =
          LENGTH clauses + 1
   
   [z3_clock_step]  Theorem
      
      ⊢ ∀clock. 0 < clock ⇒ clock − 1 < clock
   
   
*)
end
