open HolKernel Parse boolLib bossLib arithmeticTheory;
val release_mod_sub = Q.prove (
  `n MOD k = 0 /\ m MOD k = 0 /\ 0 < k ==> (n - m) MOD k = 0`,
  Cases_on `m <= n` \\ fs []
  \\ imp_res_tac LESS_EQ_EXISTS \\ rw []
  \\ qpat_x_assum `(m + _) MOD k = 0` mp_tac
  \\ qpat_x_assum `0 < k` (fn h =>
       ONCE_REWRITE_TAC [GSYM (MATCH_MP (Q.SPEC `k` MOD_PLUS) h)]
       THEN ASM_SIMP_TAC (srw_ss()) [MATCH_MP (Q.SPEC `k` MOD_MOD) h]));
val _ = (print ("ORIGINAL_RELEASE_MOD_SUB_RECONSTRUCTED\n"), release_mod_sub);
OS.Process.exit OS.Process.success;
