signature typeSysPropsTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val db_merge_def : thm
    val deBruijn_subst_tenvE_def : thm
    val type_pes_def : thm
  
  (*  Theorems  *)
    val add_tenvE_bvl : thm
    val add_tenvE_nsAppend : thm
    val bind_tvar0 : thm
    val bind_tvar_rewrites : thm
    val bind_var_list_append : thm
    val check_ctor_tenv_EVERY : thm
    val check_ctor_tenv_change_tenvT : thm
    val check_ctor_tenv_ok : thm
    val check_freevars_add : thm
    val check_freevars_subst : thm
    val check_freevars_subst_inc : thm
    val check_freevars_subst_list : thm
    val check_freevars_subst_single : thm
    val check_freevars_type_name_subst : thm
    val ctMap_ok_lookup : thm
    val ctMap_ok_merge_imp : thm
    val ctMap_ok_type_defs : thm
    val db_merge_bvl : thm
    val deBruijn_inc0 : thm
    val deBruijn_inc_deBruijn_inc : thm
    val deBruijn_subst2 : thm
    val deBruijn_subst_E_bvl : thm
    val deBruijn_subst_check_freevars : thm
    val deBruijn_subst_check_freevars2 : thm
    val deBruijn_subst_freevars : thm
    val deBruijn_subst_id : thm
    val extend_dec_tenv_assoc : thm
    val extend_dec_tenv_ok : thm
    val mem_type_def_to_ctMap : thm
    val nil_deBruijn_inc : thm
    val nil_deBruijn_subst : thm
    val nsLookup_add_tenvE1 : thm
    val nsLookup_add_tenvE2 : thm
    val nsLookup_add_tenvE3 : thm
    val nsMap_build_ctor_tenv : thm
    val num_tvs_bind_var_list : thm
    val num_tvs_db_merge : thm
    val num_tvs_deBruijn_subst_tenvE : thm
    val subst_inc_cancel : thm
    val tenv_abbrev_ok_lookup : thm
    val tenv_abbrev_ok_merge : thm
    val tenv_abbrev_ok_nsEmpty : thm
    val tenv_ctor_ok_lookup : thm
    val tenv_ctor_ok_merge : thm
    val tenv_ctor_ok_nsEmpty : thm
    val tenv_ok_empty : thm
    val tenv_val_exp_ok_bvl : thm
    val tenv_val_exp_ok_bvl_funs : thm
    val tenv_val_exp_ok_bvl_tvs : thm
    val tenv_val_exp_ok_db_merge : thm
    val tenv_val_ok_add_tenvE : thm
    val tenv_val_ok_nsEmpty : thm
    val tveLookup_add_inc : thm
    val tveLookup_bvl : thm
    val tveLookup_db_merge_none : thm
    val tveLookup_db_merge_some : thm
    val tveLookup_freevars : thm
    val tveLookup_freevars_subst : thm
    val tveLookup_inc_none : thm
    val tveLookup_inc_some : thm
    val tveLookup_no_tvs : thm
    val tveLookup_subst_none : thm
    val tveLookup_subst_some : thm
    val type_ctor_long : thm
    val type_d_check_uniq : thm
    val type_d_tenv_ok : thm
    val type_d_tenv_ok_helper : thm
    val type_def_to_ctMap_def : thm
    val type_def_to_ctMap_ind : thm
    val type_def_to_ctMap_mem : thm
    val type_ds_empty : thm
    val type_ds_sing : thm
    val type_e_freevars : thm
    val type_e_subst : thm
    val type_e_subst_lem3 : thm
    val type_es_length : thm
    val type_es_list_rel : thm
    val type_funs_MAP_FST : thm
    val type_funs_Tfn : thm
    val type_funs_distinct : thm
    val type_funs_find_recfun : thm
    val type_funs_lookup : thm
    val type_funs_tenv_exp_ok : thm
    val type_op_cases : thm
    val type_p_bvl : thm
    val type_p_freevars : thm
    val type_p_subst : thm
    val type_p_tenvV_indep : thm
    val type_pes_cons : thm
    val type_ps_length : thm
    val type_recfun_lookup : thm
    val type_subst : thm
    val type_subst_deBruijn_inc_list : thm
    val type_subst_deBruijn_subst_list : thm
    val type_v_freevars : thm
    val unchanged_tenv : thm
(*
   [semanticPrimitivesProps] Parent theory of "typeSysProps"
   
   [typeSoundInvariants] Parent theory of "typeSysProps"
   
   [db_merge_def]  Definition
      
      ⊢ (∀e. db_merge Empty e = e) ∧
        (∀tvs e1 e2.
           db_merge (Bind_tvar tvs e1) e2 = Bind_tvar tvs (db_merge e1 e2)) ∧
        ∀x tvs t e1 e2.
          db_merge (Bind_name x tvs t e1) e2 =
          Bind_name x tvs t (db_merge e1 e2)
   
   [deBruijn_subst_tenvE_def]  Definition
      
      ⊢ (∀targs. deBruijn_subst_tenvE targs Empty = Empty) ∧
        (∀targs tvs env.
           deBruijn_subst_tenvE targs (Bind_tvar tvs env) =
           Bind_tvar tvs (deBruijn_subst_tenvE targs env)) ∧
        ∀targs x tvs t env.
          deBruijn_subst_tenvE targs (Bind_name x tvs t env) =
          Bind_name x tvs
            (deBruijn_subst (tvs + num_tvs env)
               (MAP (deBruijn_inc 0 (tvs + num_tvs env)) targs) t)
            (deBruijn_subst_tenvE targs env)
   
   [type_pes_def]  Definition
      
      ⊢ ∀tvs tvs' tenv tenvE pes t1 t2.
          type_pes tvs tvs' tenv tenvE pes t1 t2 ⇔
          ∀(p,e)::set pes. ∃bindings.
            ALL_DISTINCT (pat_bindings p []) ∧
            type_p tvs tenv p t1 bindings ∧
            type_e tenv (bind_var_list tvs' bindings tenvE) e t2
   
   [add_tenvE_bvl]  Theorem
      
      ⊢ ∀n bindings tenvE tenvV.
          add_tenvE (bind_var_list n bindings tenvE) tenvV =
          nsBindList (MAP (λ(x,t). (x,n,t)) bindings)
            (add_tenvE tenvE tenvV)
   
   [add_tenvE_nsAppend]  Theorem
      
      ⊢ ∀tenvE tenvV.
          nsAppend (add_tenvE tenvE nsEmpty) tenvV = add_tenvE tenvE tenvV
   
   [bind_tvar0]  Theorem
      
      ⊢ ∀x. bind_tvar 0 x = x
   
   [bind_tvar_rewrites]  Theorem
      
      ⊢ (∀tvs e1 e2.
           db_merge (bind_tvar tvs e1) e2 = bind_tvar tvs (db_merge e1 e2)) ∧
        (∀tvs e. num_tvs (bind_tvar tvs e) = tvs + num_tvs e) ∧
        (∀tvs e. num_tvs (Bind_tvar tvs e) = tvs + num_tvs e) ∧
        (∀tvs n t e. num_tvs (Bind_name n tvs t e) = num_tvs e) ∧
        (∀tvs e. num_tvs Empty = 0) ∧
        (∀n inc tvs e.
           tveLookup n inc (bind_tvar tvs e) = tveLookup n (inc + tvs) e) ∧
        (∀tvs e. tenv_val_exp_ok (bind_tvar tvs e) ⇔ tenv_val_exp_ok e) ∧
        ∀targs tvs e.
          deBruijn_subst_tenvE targs (bind_tvar tvs e) =
          bind_tvar tvs (deBruijn_subst_tenvE targs e)
   
   [bind_var_list_append]  Theorem
      
      ⊢ ∀n te1 te2 te3.
          bind_var_list n (te1 ++ te2) te3 =
          bind_var_list n te1 (bind_var_list n te2 te3)
   
   [check_ctor_tenv_EVERY]  Theorem
      
      ⊢ ∀tenvT tds.
          check_ctor_tenv tenvT tds ⇔
          EVERY check_dup_ctors tds ∧ EVERY (ALL_DISTINCT ∘ FST) tds ∧
          EVERY
            (λ(tvs,tn,ctors).
                 EVERY
                   (λ(cn,ts).
                        EVERY (check_freevars_ast tvs) ts ∧
                        EVERY (check_type_names tenvT) ts) ctors) tds ∧
          ALL_DISTINCT (MAP (FST ∘ SND) tds)
   
   [check_ctor_tenv_change_tenvT]  Theorem
      
      ⊢ ∀tenvT1 env tenvT2.
          EVERY
            (λ(cn,ts).
                 EVERY (check_type_names tenvT1) ts ⇒
                 EVERY (check_type_names tenvT2) ts)
            (FLAT (MAP (SND ∘ SND) env)) ∧ check_ctor_tenv tenvT1 env ⇒
          check_ctor_tenv tenvT2 env
   
   [check_ctor_tenv_ok]  Theorem
      
      ⊢ ∀tenvT tds tis.
          LENGTH tds = LENGTH tis ∧ check_ctor_tenv tenvT tds ∧
          tenv_abbrev_ok tenvT ⇒
          tenv_ctor_ok (build_ctor_tenv tenvT tds tis)
   
   [check_freevars_add]  Theorem
      
      ⊢ ∀tvs tvs' t.
          check_freevars tvs tvs' t ⇒
          ∀tvs''. tvs'' ≥ tvs ⇒ check_freevars tvs'' tvs' t
   
   [check_freevars_subst]  Theorem
      
      ⊢ ∀tvs tvs2 t.
          check_freevars tvs tvs2 t ⇒
          ∀tvs' targs tvs1.
            tvs = LENGTH targs + tvs' ∧
            EVERY (check_freevars (tvs1 + tvs') tvs2) targs ⇒
            check_freevars (tvs1 + tvs') tvs2 (deBruijn_subst 0 targs t)
   
   [check_freevars_subst_inc]  Theorem
      
      ⊢ ∀tvs tvs2 t.
          check_freevars tvs tvs2 t ⇒
          ∀tvs' targs tvs1.
            tvs = LENGTH targs + tvs' ∧
            EVERY (check_freevars (tvs1 + tvs') tvs2) targs ⇒
            check_freevars (tvs1 + tvs') tvs2
              (deBruijn_subst 0 targs (deBruijn_inc (LENGTH targs) tvs1 t))
   
   [check_freevars_subst_list]  Theorem
      
      ⊢ ∀dbmax tvs tvs' ts ts'.
          LENGTH tvs = LENGTH ts ∧ EVERY (check_freevars dbmax tvs) ts' ∧
          EVERY (check_freevars dbmax tvs') ts ⇒
          EVERY (check_freevars dbmax tvs')
            (MAP (type_subst (alist_to_fmap (ZIP (tvs,ts)))) ts')
   
   [check_freevars_subst_single]  Theorem
      
      ⊢ ∀dbmax tvs t tvs' ts.
          LENGTH tvs = LENGTH ts ∧ check_freevars dbmax tvs t ∧
          EVERY (check_freevars dbmax tvs') ts ⇒
          check_freevars dbmax tvs'
            (type_subst (alist_to_fmap (ZIP (tvs,ts))) t)
   
   [check_freevars_type_name_subst]  Theorem
      
      ⊢ ∀tvs t dbmax tenvT.
          tenv_abbrev_ok tenvT ∧ check_type_names tenvT t ∧
          check_freevars_ast tvs t ⇒
          check_freevars dbmax tvs (type_name_subst tenvT t)
   
   [ctMap_ok_lookup]  Theorem
      
      ⊢ ∀ctMap cn tvs ts ti tn.
          ctMap_ok ctMap ∧ FLOOKUP ctMap tn = SOME (tvs,ts,ti) ⇒
          EVERY (check_freevars 0 tvs) ts
   
   [ctMap_ok_merge_imp]  Theorem
      
      ⊢ ∀ctMap1 ctMap2.
          DISJOINT (FRANGE ((SND ∘ SND) o_f ctMap1))
            (FRANGE ((SND ∘ SND) o_f ctMap2)) ∧ ctMap_ok ctMap1 ∧
          ctMap_ok ctMap2 ⇒
          ctMap_ok (ctMap1 ⊌ ctMap2)
   
   [ctMap_ok_type_defs]  Theorem
      
      ⊢ ∀tenvT next tds tids.
          ALL_DISTINCT tids ∧ DISJOINT (set tids) (set prim_type_nums) ∧
          LENGTH tds = LENGTH tids ∧ check_ctor_tenv tenvT tds ∧
          tenv_abbrev_ok tenvT ⇒
          ctMap_ok
            (FEMPTY |++ REVERSE (type_def_to_ctMap tenvT next tds tids))
   
   [db_merge_bvl]  Theorem
      
      ⊢ ∀tenv1 tenv2 tenv3 tvs.
          db_merge (bind_var_list tvs tenv1 tenv2) tenv3 =
          bind_var_list tvs tenv1 (db_merge tenv2 tenv3)
   
   [deBruijn_inc0]  Theorem
      
      ⊢ (∀t sk. deBruijn_inc sk 0 t = t) ∧
        ∀ts sk. MAP (deBruijn_inc sk 0) ts = ts
   
   [deBruijn_inc_deBruijn_inc]  Theorem
      
      ⊢ ∀sk i2 t i1.
          deBruijn_inc sk i1 (deBruijn_inc sk i2 t) =
          deBruijn_inc sk (i1 + i2) t
   
   [deBruijn_subst2]  Theorem
      
      ⊢ (∀t sk targs targs' tvs'.
           check_freevars (LENGTH targs) [] t ⇒
           deBruijn_subst sk (MAP (deBruijn_inc 0 sk) targs')
             (deBruijn_subst 0 targs t) =
           deBruijn_subst 0
             (MAP (deBruijn_subst sk (MAP (deBruijn_inc 0 sk) targs'))
                targs) t) ∧
        ∀ts sk targs targs' tvs'.
          EVERY (check_freevars (LENGTH targs) []) ts ⇒
          MAP (deBruijn_subst sk (MAP (deBruijn_inc 0 sk) targs'))
            (MAP (deBruijn_subst 0 targs) ts) =
          MAP
            (deBruijn_subst 0
               (MAP (deBruijn_subst sk (MAP (deBruijn_inc 0 sk) targs'))
                  targs)) ts
   
   [deBruijn_subst_E_bvl]  Theorem
      
      ⊢ ∀tenv1 tenv2 tvs.
          deBruijn_subst_tenvE targs (bind_var_list tvs tenv1 tenv2) =
          bind_var_list tvs
            (MAP
               (λ(x,t).
                    (x,
                     deBruijn_subst (tvs + num_tvs tenv2)
                       (MAP (deBruijn_inc 0 (tvs + num_tvs tenv2)) targs) t))
               tenv1) (deBruijn_subst_tenvE targs tenv2)
   
   [deBruijn_subst_check_freevars]  Theorem
      
      ⊢ ∀tvs tvs' t ts n.
          check_freevars tvs tvs' t ∧ EVERY (check_freevars tvs tvs') ts ⇒
          check_freevars tvs tvs' (deBruijn_subst 0 ts t)
   
   [deBruijn_subst_check_freevars2]  Theorem
      
      ⊢ ∀tvs tvs' t ts n tvs''.
          check_freevars (LENGTH ts) tvs' t ∧
          EVERY (check_freevars tvs tvs') ts ⇒
          check_freevars tvs tvs' (deBruijn_subst 0 ts t)
   
   [deBruijn_subst_freevars]  Theorem
      
      ⊢ ∀skip targs t tvs.
          skip = 0 ∧ EVERY (check_freevars tvs []) targs ∧
          check_freevars (LENGTH targs) [] t ⇒
          check_freevars tvs [] (deBruijn_subst skip targs t)
   
   [deBruijn_subst_id]  Theorem
      
      ⊢ (∀t n.
           check_freevars n [] t ⇒
           deBruijn_subst 0 (MAP Tvar_db (COUNT_LIST n)) t = t) ∧
        ∀ts n.
          EVERY (check_freevars n []) ts ⇒
          MAP (deBruijn_subst 0 (MAP Tvar_db (COUNT_LIST n))) ts = ts
   
   [extend_dec_tenv_assoc]  Theorem
      
      ⊢ ∀tenv1 tenv2 tenv3.
          extend_dec_tenv tenv1 (extend_dec_tenv tenv2 tenv3) =
          extend_dec_tenv (extend_dec_tenv tenv1 tenv2) tenv3
   
   [extend_dec_tenv_ok]  Theorem
      
      ⊢ ∀tenv tenv'.
          tenv_ok tenv ∧ tenv_ok tenv' ⇒
          tenv_ok (extend_dec_tenv tenv tenv')
   
   [mem_type_def_to_ctMap]  Theorem
      
      ⊢ ∀tenvT next tds ids stamp x.
          MEM (stamp,x) (type_def_to_ctMap tenvT next tds ids) ∧
          LENGTH tds = LENGTH ids ⇒
          ∃cn i. stamp = TypeStamp cn i ∧ next ≤ i ∧ i < next + LENGTH tds
   
   [nil_deBruijn_inc]  Theorem
      
      ⊢ ∀skip tvs t.
          check_freevars skip [] t ∨
          check_freevars skip [] (deBruijn_inc skip tvs t) ⇒
          deBruijn_inc skip tvs t = t
   
   [nil_deBruijn_subst]  Theorem
      
      ⊢ ∀skip tvs t.
          check_freevars skip [] t ⇒ deBruijn_subst skip tvs t = t
   
   [nsLookup_add_tenvE1]  Theorem
      
      ⊢ ∀tenvE tenvV n tvs t tvs2.
          check_freevars tvs2 [] t ∧ tveLookup n tvs tenvE = SOME (tvs2,t) ⇒
          nsLookup (add_tenvE tenvE tenvV) (Short n) = SOME (tvs2,t)
   
   [nsLookup_add_tenvE2]  Theorem
      
      ⊢ ∀tenvE tenvV n tvs t tvs2.
          tveLookup n tvs tenvE = NONE ∧
          nsLookup tenvV (Short n) = SOME (tvs2,t) ⇒
          nsLookup (add_tenvE tenvE tenvV) (Short n) = SOME (tvs2,t)
   
   [nsLookup_add_tenvE3]  Theorem
      
      ⊢ ∀tenvE tenvV n t tvs2 mn.
          nsLookup tenvV (Long mn n) = SOME (tvs2,t) ⇒
          nsLookup (add_tenvE tenvE tenvV) (Long mn n) = SOME (tvs2,t)
   
   [nsMap_build_ctor_tenv]  Theorem
      
      ⊢ ∀ga g h tenvT tds ids.
          LENGTH tds = LENGTH ids ∧
          (∀x. MEM x (MAP SND (FLAT (MAP (SND ∘ SND) tds))) ⇒
               MAP (type_name_subst tenvT) (ga x) =
               g (MAP (type_name_subst tenvT) x)) ⇒
          nsMap (λ(tvs,ts,tid). (tvs,g ts,h tid))
            (build_ctor_tenv tenvT tds ids) =
          build_ctor_tenv tenvT (MAP (I ## I ## MAP (I ## ga)) tds)
            (MAP h ids)
   
   [num_tvs_bind_var_list]  Theorem
      
      ⊢ ∀tvs env tenvE.
          num_tvs (bind_var_list tvs env tenvE) = num_tvs tenvE
   
   [num_tvs_db_merge]  Theorem
      
      ⊢ ∀e1 e2. num_tvs (db_merge e1 e2) = num_tvs e1 + num_tvs e2
   
   [num_tvs_deBruijn_subst_tenvE]  Theorem
      
      ⊢ ∀targs tenvE.
          num_tvs (deBruijn_subst_tenvE targs tenvE) = num_tvs tenvE
   
   [subst_inc_cancel]  Theorem
      
      ⊢ (∀t ts inc.
           deBruijn_subst 0 ts (deBruijn_inc 0 (inc + LENGTH ts) t) =
           deBruijn_inc 0 inc t) ∧
        ∀ts' ts inc.
          MAP (deBruijn_subst 0 ts)
            (MAP (deBruijn_inc 0 (inc + LENGTH ts)) ts') =
          MAP (deBruijn_inc 0 inc) ts'
   
   [tenv_abbrev_ok_lookup]  Theorem
      
      ⊢ ∀tenvT tn tvs t.
          tenv_abbrev_ok tenvT ∧ nsLookup tenvT tn = SOME (tvs,t) ⇒
          check_freevars 0 tvs t
   
   [tenv_abbrev_ok_merge]  Theorem
      
      ⊢ ∀tenvT1 tenvT2.
          tenv_abbrev_ok tenvT1 ∧ tenv_abbrev_ok tenvT2 ⇒
          tenv_abbrev_ok (nsAppend tenvT1 tenvT2)
   
   [tenv_abbrev_ok_nsEmpty]  Theorem
      
      ⊢ tenv_abbrev_ok nsEmpty
   
   [tenv_ctor_ok_lookup]  Theorem
      
      ⊢ ∀tenvC cn tvs ts tn.
          tenv_ctor_ok tenvC ∧ nsLookup tenvC cn = SOME (tvs,ts,tn) ⇒
          EVERY (check_freevars 0 tvs) ts
   
   [tenv_ctor_ok_merge]  Theorem
      
      ⊢ ∀tenvC1 tenvC2.
          tenv_ctor_ok tenvC1 ∧ tenv_ctor_ok tenvC2 ⇒
          tenv_ctor_ok (nsAppend tenvC1 tenvC2)
   
   [tenv_ctor_ok_nsEmpty]  Theorem
      
      ⊢ tenv_ctor_ok nsEmpty
   
   [tenv_ok_empty]  Theorem
      
      ⊢ tenv_ok <|v := nsEmpty; c := nsEmpty; t := nsEmpty|>
   
   [tenv_val_exp_ok_bvl]  Theorem
      
      ⊢ ∀tenvE env.
          tenv_val_exp_ok tenvE ∧
          EVERY (check_freevars (num_tvs tenvE) []) (MAP SND env) ⇒
          tenv_val_exp_ok (bind_var_list 0 env tenvE)
   
   [tenv_val_exp_ok_bvl_funs]  Theorem
      
      ⊢ ∀funs env tenv bindings tenv_val tenvE.
          type_funs tenv (bind_var_list 0 bindings tenvE) funs env ∧
          tenv_val_exp_ok tenvE ⇒
          tenv_val_exp_ok (bind_var_list 0 env tenvE)
   
   [tenv_val_exp_ok_bvl_tvs]  Theorem
      
      ⊢ ∀funs tenv env tvs bindings tenvE.
          type_funs tenv (bind_var_list 0 bindings (bind_tvar tvs tenvE))
            funs env ∧ tenv_val_exp_ok tenvE ⇒
          tenv_val_exp_ok (bind_var_list tvs env tenvE)
   
   [tenv_val_exp_ok_db_merge]  Theorem
      
      ⊢ ∀e1 e2. tenv_val_exp_ok (db_merge e1 e2) ⇒ tenv_val_exp_ok e2
   
   [tenv_val_ok_add_tenvE]  Theorem
      
      ⊢ ∀tenvE tenvV.
          num_tvs tenvE = 0 ∧ tenv_val_exp_ok tenvE ∧ tenv_val_ok tenvV ⇒
          tenv_val_ok (add_tenvE tenvE tenvV)
   
   [tenv_val_ok_nsEmpty]  Theorem
      
      ⊢ tenv_val_ok nsEmpty
   
   [tveLookup_add_inc]  Theorem
      
      ⊢ ∀x inc tenv tvs t inc2.
          tveLookup x inc tenv = SOME (tvs,t) ⇒
          tveLookup x (inc2 + inc) tenv =
          SOME (tvs,deBruijn_inc tvs inc2 t)
   
   [tveLookup_bvl]  Theorem
      
      ⊢ ∀x tvs tvs' bindings tenvE.
          tveLookup x tvs (bind_var_list tvs' bindings tenvE) =
          case ALOOKUP bindings x of
            NONE => tveLookup x tvs tenvE
          | SOME t => SOME (tvs',deBruijn_inc tvs' tvs t)
   
   [tveLookup_db_merge_none]  Theorem
      
      ⊢ ∀n inc e1 e2.
          tveLookup n inc (db_merge e1 e2) = NONE ⇔
          tveLookup n inc e1 = NONE ∧
          tveLookup n (num_tvs e1 + inc) e2 = NONE
   
   [tveLookup_db_merge_some]  Theorem
      
      ⊢ ∀n inc tenvE1 tenvE2 tvs t.
          tveLookup n inc (db_merge tenvE1 tenvE2) = SOME (tvs,t) ⇔
          tveLookup n inc tenvE1 = SOME (tvs,t) ∨
          tveLookup n inc tenvE1 = NONE ∧
          tveLookup n (num_tvs tenvE1 + inc) tenvE2 = SOME (tvs,t)
   
   [tveLookup_freevars]  Theorem
      
      ⊢ ∀n tvs tenvE tvs' t.
          tenv_val_exp_ok tenvE ∧ num_tvs tenvE = 0 ∧
          tveLookup n tvs tenvE = SOME (tvs',t) ⇒
          check_freevars tvs' [] t
   
   [tveLookup_freevars_subst]  Theorem
      
      ⊢ ∀tenvE targs n t inc.
          EVERY (check_freevars (inc + num_tvs tenvE) []) targs ∧
          tveLookup n inc tenvE = SOME (LENGTH targs,t) ∧
          tenv_val_exp_ok tenvE ⇒
          check_freevars (inc + num_tvs tenvE) []
            (deBruijn_subst 0 targs t)
   
   [tveLookup_inc_none]  Theorem
      
      ⊢ ∀n inc e. tveLookup n inc e = NONE ⇔ tveLookup n 0 e = NONE
   
   [tveLookup_inc_some]  Theorem
      
      ⊢ ∀n inc e tvs t inc2.
          tveLookup n inc e = SOME (tvs,t) ⇒
          ∃t'.
            t = deBruijn_inc tvs inc t' ∧
            tveLookup n inc2 e = SOME (tvs,deBruijn_inc tvs inc2 t')
   
   [tveLookup_no_tvs]  Theorem
      
      ⊢ ∀tvs l tenv n t.
          tenv_val_exp_ok tenv ∧ num_tvs tenv = 0 ⇒
          (tveLookup n tvs tenv = SOME (l,t) ⇔
           tveLookup n 0 tenv = SOME (l,t))
   
   [tveLookup_subst_none]  Theorem
      
      ⊢ ∀n inc e.
          tveLookup n inc (deBruijn_subst_tenvE targs e) = NONE ⇔
          tveLookup n inc e = NONE
   
   [tveLookup_subst_some]  Theorem
      
      ⊢ ∀n e targs tvs t inc.
          tveLookup n inc e = SOME (tvs,t) ⇒
          tveLookup n inc (deBruijn_subst_tenvE targs e) =
          SOME
            (tvs,
             deBruijn_subst (tvs + inc + num_tvs e)
               (MAP (deBruijn_inc 0 (tvs + inc + num_tvs e)) targs) t)
   
   [type_ctor_long]  Theorem
      
      ⊢ ∀ctMap mn id. type_ctor ctMap (Long mn id) = type_ctor ctMap id
   
   [type_d_check_uniq]  Theorem
      
      ⊢ (∀check tenv d tdecs new_tenv.
           type_d check tenv d tdecs new_tenv ⇒
           type_d F tenv d tdecs new_tenv) ∧
        ∀check tenv d tdecs new_tenv.
          type_ds check tenv d tdecs new_tenv ⇒
          type_ds F tenv d tdecs new_tenv
   
   [type_d_tenv_ok]  Theorem
      
      ⊢ ∀check tenv d tdecs tenv'.
          type_d check tenv d tdecs tenv' ∧ tenv_ok tenv ⇒
          tenv_ok (extend_dec_tenv tenv' tenv)
   
   [type_d_tenv_ok_helper]  Theorem
      
      ⊢ (∀check tenv d tdecs tenv'.
           type_d check tenv d tdecs tenv' ⇒ tenv_ok tenv ⇒ tenv_ok tenv') ∧
        ∀check tenv d tdecs tenv'.
          type_ds check tenv d tdecs tenv' ⇒ tenv_ok tenv ⇒ tenv_ok tenv'
   
   [type_def_to_ctMap_def]  Theorem
      
      ⊢ (∀tenvT next_stamp. type_def_to_ctMap tenvT next_stamp [] [] = []) ∧
        ∀tvs tn tenvT tds next_stamp ids id ctors.
          type_def_to_ctMap tenvT next_stamp ((tvs,tn,ctors)::tds)
            (id::ids) =
          type_def_to_ctMap tenvT (next_stamp + 1) tds ids ++
          REVERSE
            (MAP
               (λ(cn,ts).
                    (TypeStamp cn next_stamp,tvs,
                     MAP (type_name_subst tenvT) ts,id)) ctors)
   
   [type_def_to_ctMap_ind]  Theorem
      
      ⊢ ∀P. (∀tenvT next_stamp. P tenvT next_stamp [] []) ∧
            (∀tenvT next_stamp tvs tn ctors tds id ids.
               P tenvT (next_stamp + 1) tds ids ⇒
               P tenvT next_stamp ((tvs,tn,ctors)::tds) (id::ids)) ∧
            (∀v13 v12 v10 v11. P v13 v12 [] (v10::v11)) ∧
            (∀v19 v18 v16 v17. P v19 v18 (v16::v17) []) ⇒
            ∀v v1 v2 v3. P v v1 v2 v3
   
   [type_def_to_ctMap_mem]  Theorem
      
      ⊢ ∀tenvT next tds tids.
          ALOOKUP (type_def_to_ctMap tenvT next tds tids) k = SOME x ∧
          LENGTH tds = LENGTH tids ⇒
          MEM (SND (SND x)) tids
   
   [type_ds_empty]  Theorem
      
      ⊢ ∀check tenv decls r.
          type_ds check tenv [] decls r ⇔
          decls = ∅ ∧ r = <|v := nsEmpty; c := nsEmpty; t := nsEmpty|>
   
   [type_ds_sing]  Theorem
      
      ⊢ ∀check tenv d decls r.
          type_ds check tenv [d] decls r ⇔ type_d check tenv d decls r
   
   [type_e_freevars]  Theorem
      
      ⊢ (∀tenv tenvE e t.
           type_e tenv tenvE e t ⇒
           tenv_val_exp_ok tenvE ∧ tenv_val_ok tenv.v ⇒
           check_freevars (num_tvs tenvE) [] t) ∧
        (∀tenv tenvE es ts.
           type_es tenv tenvE es ts ⇒
           tenv_val_exp_ok tenvE ∧ tenv_val_ok tenv.v ⇒
           EVERY (check_freevars (num_tvs tenvE) []) ts) ∧
        ∀tenv tenvE funs env.
          type_funs tenv tenvE funs env ⇒
          tenv_val_exp_ok tenvE ∧ tenv_val_ok tenv.v ⇒
          EVERY (check_freevars (num_tvs tenvE) []) (MAP SND env)
   
   [type_e_subst]  Theorem
      
      ⊢ (∀tenv tenvE e t.
           type_e tenv tenvE e t ⇒
           ∀tenvE1 targs tvs targs'.
             num_tvs tenvE2 = 0 ∧ tenv_abbrev_ok tenv.t ∧
             tenv_ctor_ok tenv.c ∧ tenv_val_ok tenv.v ∧
             tenv_val_exp_ok tenvE ∧ EVERY (check_freevars tvs []) targs ∧
             tenvE = db_merge tenvE1 (bind_tvar (LENGTH targs) tenvE2) ∧
             targs' = MAP (deBruijn_inc 0 (num_tvs tenvE1)) targs ⇒
             type_e tenv
               (db_merge (deBruijn_subst_tenvE targs tenvE1)
                  (bind_tvar tvs tenvE2)) e
               (deBruijn_subst (num_tvs tenvE1) targs' t)) ∧
        (∀tenv tenvE es ts.
           type_es tenv tenvE es ts ⇒
           ∀tenvE1 targs tvs targs'.
             num_tvs tenvE2 = 0 ∧ tenv_abbrev_ok tenv.t ∧
             tenv_ctor_ok tenv.c ∧ tenv_val_ok tenv.v ∧
             tenv_val_exp_ok tenvE ∧ EVERY (check_freevars tvs []) targs ∧
             tenvE = db_merge tenvE1 (bind_tvar (LENGTH targs) tenvE2) ∧
             targs' = MAP (deBruijn_inc 0 (num_tvs tenvE1)) targs ⇒
             type_es tenv
               (db_merge (deBruijn_subst_tenvE targs tenvE1)
                  (bind_tvar tvs tenvE2)) es
               (MAP (deBruijn_subst (num_tvs tenvE1) targs') ts)) ∧
        ∀tenv tenvE funs env.
          type_funs tenv tenvE funs env ⇒
          ∀tenvE1 targs tvs targs'.
            num_tvs tenvE2 = 0 ∧ tenv_abbrev_ok tenv.t ∧
            tenv_ctor_ok tenv.c ∧ tenv_val_ok tenv.v ∧
            tenv_val_exp_ok tenvE ∧ EVERY (check_freevars tvs []) targs ∧
            tenvE = db_merge tenvE1 (bind_tvar (LENGTH targs) tenvE2) ∧
            targs' = MAP (deBruijn_inc 0 (num_tvs tenvE1)) targs ⇒
            type_funs tenv
              (db_merge (deBruijn_subst_tenvE targs tenvE1)
                 (bind_tvar tvs tenvE2)) funs
              (MAP (λ(x,t). (x,deBruijn_subst (num_tvs tenvE1) targs' t))
                 env)
   
   [type_e_subst_lem3]  Theorem
      
      ⊢ ∀tvs tvs2 t.
          check_freevars tvs tvs2 t ⇒
          ∀tvs' targs n.
            tvs = n + LENGTH targs ∧ EVERY (check_freevars tvs' tvs2) targs ⇒
            check_freevars (n + tvs') tvs2
              (deBruijn_subst n (MAP (deBruijn_inc 0 n) targs) t)
   
   [type_es_length]  Theorem
      
      ⊢ ∀tenv tenvE es ts. type_es tenv tenvE es ts ⇒ LENGTH es = LENGTH ts
   
   [type_es_list_rel]  Theorem
      
      ⊢ ∀es ts tenv tenvE.
          type_es tenv tenvE es ts ⇔ LIST_REL (type_e tenv tenvE) es ts
   
   [type_funs_MAP_FST]  Theorem
      
      ⊢ ∀funs tenv tenvE env.
          type_funs tenv tenvE funs env ⇒ MAP FST funs = MAP FST env
   
   [type_funs_Tfn]  Theorem
      
      ⊢ ∀tenv tenvE funs bindings tvs t n.
          type_funs tenv tenvE funs bindings ∧ ALOOKUP bindings n = SOME t ⇒
          ∃t1 t2.
            t = Tfn t1 t2 ∧ check_freevars (num_tvs tenvE) [] (Tfn t1 t2)
   
   [type_funs_distinct]  Theorem
      
      ⊢ ∀tenv tenvE funs bindings.
          type_funs tenv tenvE funs bindings ⇒
          ALL_DISTINCT (MAP (λ(x,y,z). x) funs)
   
   [type_funs_find_recfun]  Theorem
      
      ⊢ ∀fn env funs bindings e tenv tenvE t.
          ALOOKUP bindings fn = SOME t ∧ type_funs tenv tenvE funs bindings ⇒
          ∃n e. find_recfun fn funs = SOME (n,e)
   
   [type_funs_lookup]  Theorem
      
      ⊢ ∀fn tenvE funs bindings n e tenv.
          MEM (fn,n,e) funs ∧ type_funs tenv tenvE funs bindings ⇒
          ∃t. ALOOKUP bindings fn = SOME t
   
   [type_funs_tenv_exp_ok]  Theorem
      
      ⊢ ∀funs env tenv tenvE tvs bindings.
          num_tvs tenvE = 0 ∧
          type_funs tenv (bind_var_list 0 bindings (bind_tvar tvs tenvE))
            funs env ⇒
          tenv_val_exp_ok (bind_var_list tvs env Empty)
   
   [type_op_cases]  Theorem
      
      ⊢ type_op op ts t3 ⇔
        (∃a ty.
           op = Arith a ty ∧ EVERY (λarg. arg = t_of ty) ts ∧
           t3 = t_of ty ∧ supported_arith a ty = SOME (LENGTH ts)) ∨
        (∃ty1 ty2.
           op = FromTo ty1 ty2 ∧ ts = [t_of ty1] ∧ t3 = t_of ty2 ∧
           supported_conversion ty1 ty2) ∨
        ((∃v20 v21.
            op = Shift W8 v20 v21 ∧ ts = [Tapp [] Tword8_num] ∧
            t3 = Tapp [] Tword8_num) ∨
         ∃v20 v21.
           op = Shift W64 v20 v21 ∧ ts = [Tapp [] Tword64_num] ∧
           t3 = Tapp [] Tword64_num) ∨
        (∃t1''. op = Equality ∧ ts = [t1''; t1''] ∧ t3 = Tapp [] Tbool_num) ∨
        (∃test ty'.
           op = Test test ty' ∧ ts = [t_of ty'; t_of ty'] ∧
           t3 = Tapp [] Tbool_num ∧ supported_test test ty') ∨
        (∃t2. op = Opapp ∧ ts = [Tapp [t2; t3] Tfn_num; t2]) ∨
        (∃t2'³'.
           op = Opassign ∧ ts = [Tapp [t2'³'] Tref_num; t2'³'] ∧
           t3 = Tapp [] Ttup_num) ∨
        (∃t1'⁶'. op = Opref ∧ ts = [t1'⁶'] ∧ t3 = Tapp [t1'⁶'] Tref_num) ∨
        op = Opderef ∧ ts = [Tapp [t3] Tref_num] ∨
        op = Aw8alloc ∧ ts = [Tapp [] Tint_num; Tapp [] Tword8_num] ∧
        t3 = Tapp [] Tword8array_num ∨
        op = Aw8sub ∧ ts = [Tapp [] Tword8array_num; Tapp [] Tint_num] ∧
        t3 = Tapp [] Tword8_num ∨
        op = Aw8length ∧ ts = [Tapp [] Tword8array_num] ∧
        t3 = Tapp [] Tint_num ∨
        op = Aw8update ∧
        ts =
        [Tapp [] Tword8array_num; Tapp [] Tint_num; Tapp [] Tword8_num] ∧
        t3 = Tapp [] Ttup_num ∨
        op = CopyStrStr ∧
        ts = [Tapp [] Tstring_num; Tapp [] Tint_num; Tapp [] Tint_num] ∧
        t3 = Tapp [] Tstring_num ∨
        op = CopyStrAw8 ∧
        ts =
        [Tapp [] Tstring_num; Tapp [] Tint_num; Tapp [] Tint_num;
         Tapp [] Tword8array_num; Tapp [] Tint_num] ∧ t3 = Tapp [] Ttup_num ∨
        op = CopyAw8Str ∧
        ts = [Tapp [] Tword8array_num; Tapp [] Tint_num; Tapp [] Tint_num] ∧
        t3 = Tapp [] Tstring_num ∨
        op = CopyAw8Aw8 ∧
        ts =
        [Tapp [] Tword8array_num; Tapp [] Tint_num; Tapp [] Tint_num;
         Tapp [] Tword8array_num; Tapp [] Tint_num] ∧ t3 = Tapp [] Ttup_num ∨
        op = Implode ∧ ts = [Tapp [Tapp [] Tchar_num] Tlist_num] ∧
        t3 = Tapp [] Tstring_num ∨
        op = Explode ∧ ts = [Tapp [] Tstring_num] ∧
        t3 = Tapp [Tapp [] Tchar_num] Tlist_num ∨
        op = Strsub ∧ ts = [Tapp [] Tstring_num; Tapp [] Tint_num] ∧
        t3 = Tapp [] Tchar_num ∨
        op = Strlen ∧ ts = [Tapp [] Tstring_num] ∧ t3 = Tapp [] Tint_num ∨
        op = Strcat ∧ ts = [Tapp [Tapp [] Tstring_num] Tlist_num] ∧
        t3 = Tapp [] Tstring_num ∨
        (∃t1'²¹'.
           op = VfromList ∧ ts = [Tapp [t1'²¹'] Tlist_num] ∧
           t3 = Tapp [t1'²¹'] Tvector_num) ∨
        op = Vsub ∧ ts = [Tapp [t3] Tvector_num; Tapp [] Tint_num] ∨
        (∃t1'²³'.
           op = Vlength ∧ ts = [Tapp [t1'²³'] Tvector_num] ∧
           t3 = Tapp [] Tint_num) ∨
        (∃t2'¹³'.
           op = Aalloc ∧ ts = [Tapp [] Tint_num; t2'¹³'] ∧
           t3 = Tapp [t2'¹³'] Tarray_num) ∨
        (∃t2.
           op = AallocEmpty ∧ ts = [Tapp [] Ttup_num] ∧
           t3 = Tapp [t2] Tarray_num) ∨
        op = Asub ∧ ts = [Tapp [t3] Tarray_num; Tapp [] Tint_num] ∨
        (∃t1'²⁷'.
           op = Alength ∧ ts = [Tapp [t1'²⁷'] Tarray_num] ∧
           t3 = Tapp [] Tint_num) ∨
        (∃t3'⁵'.
           op = Aupdate ∧
           ts = [Tapp [t3'⁵'] Tarray_num; Tapp [] Tint_num; t3'⁵'] ∧
           t3 = Tapp [] Ttup_num) ∨
        (∃t1'³¹'.
           op = ListAppend ∧
           ts = [Tapp [t1'³¹'] Tlist_num; Tapp [t1'³¹'] Tlist_num] ∧
           t3 = Tapp [t1'³¹'] Tlist_num) ∨
        op = ConfigGC ∧ ts = [Tapp [] Tint_num; Tapp [] Tint_num] ∧
        t3 = Tapp [] Ttup_num ∨
        ∃n. op = FFI n ∧
            ts = [Tapp [] Tstring_num; Tapp [] Tword8array_num] ∧
            t3 = Tapp [] Ttup_num
   
   [type_p_bvl]  Theorem
      
      ⊢ (∀tvs tenvC p t bindings.
           type_p tvs tenvC p t bindings ⇒
           ∀tenv'.
             tenv_val_exp_ok tenv' ⇒
             tenv_val_exp_ok (bind_var_list tvs bindings tenv')) ∧
        ∀tvs tenvC ps ts bindings.
          type_ps tvs tenvC ps ts bindings ⇒
          ∀tenv'.
            tenv_val_exp_ok tenv' ⇒
            tenv_val_exp_ok (bind_var_list tvs bindings tenv')
   
   [type_p_freevars]  Theorem
      
      ⊢ (∀tvs tenvC p t env'.
           type_p tvs tenvC p t env' ⇒
           check_freevars tvs [] t ∧
           EVERY (check_freevars tvs []) (MAP SND env')) ∧
        ∀tvs tenvC ps ts env'.
          type_ps tvs tenvC ps ts env' ⇒
          EVERY (check_freevars tvs []) ts ∧
          EVERY (check_freevars tvs []) (MAP SND env')
   
   [type_p_subst]  Theorem
      
      ⊢ (∀n tenv p t new_bindings.
           type_p n tenv p t new_bindings ⇒
           ∀targs' inc tvs targs.
             tenv_abbrev_ok tenv.t ∧ tenv_ctor_ok tenv.c ∧
             n = inc + LENGTH targs ∧ EVERY (check_freevars tvs []) targs ∧
             targs' = MAP (deBruijn_inc 0 inc) targs ⇒
             type_p (inc + tvs) tenv p (deBruijn_subst inc targs' t)
               (MAP (λ(x,t). (x,deBruijn_subst inc targs' t)) new_bindings)) ∧
        ∀n tenv ps ts new_bindings.
          type_ps n tenv ps ts new_bindings ⇒
          ∀targs' inc targs tvs.
            tenv_abbrev_ok tenv.t ∧ tenv_ctor_ok tenv.c ∧
            n = inc + LENGTH targs ∧ EVERY (check_freevars tvs []) targs ∧
            targs' = MAP (deBruijn_inc 0 inc) targs ⇒
            type_ps (inc + tvs) tenv ps
              (MAP (deBruijn_subst inc targs') ts)
              (MAP (λ(x,t). (x,deBruijn_subst inc targs' t)) new_bindings)
   
   [type_p_tenvV_indep]  Theorem
      
      ⊢ (∀p tvs tenv t bindings tenvV.
           type_p tvs tenv p t bindings ⇔
           type_p tvs (tenv with v := tenvV) p t bindings) ∧
        ∀ps tvs tenv t bindings tenvV.
          type_ps tvs tenv ps t bindings ⇔
          type_ps tvs (tenv with v := tenvV) ps t bindings
   
   [type_pes_cons]  Theorem
      
      ⊢ ∀tvs tvs' tenv tenvE p e pes t1 t2.
          type_pes tvs tvs' tenv tenvE ((p,e)::pes) t1 t2 ⇔
          ALL_DISTINCT (pat_bindings p []) ∧
          (∃bindings.
             type_p tvs tenv p t1 bindings ∧
             type_e tenv (bind_var_list tvs' bindings tenvE) e t2) ∧
          type_pes tvs tvs' tenv tenvE pes t1 t2
   
   [type_ps_length]  Theorem
      
      ⊢ ∀tvs tenvC ps ts tenv.
          type_ps tvs tenvC ps ts tenv ⇒ LENGTH ps = LENGTH ts
   
   [type_recfun_lookup]  Theorem
      
      ⊢ ∀fn funs n e tenv tenvE bindings tvs t1 t2.
          find_recfun fn funs = SOME (n,e) ∧
          type_funs tenv tenvE funs bindings ∧
          ALOOKUP bindings fn = SOME (Tfn t1 t2) ⇒
          type_e tenv (Bind_name n 0 t1 tenvE) e t2 ∧
          check_freevars (num_tvs tenvE) [] (Tfn t1 t2)
   
   [type_subst]  Theorem
      
      ⊢ ∀tvs ctMap tenvS v t.
          type_v tvs ctMap tenvS v t ⇒
          tvs = LENGTH targs ∧ ctMap_ok ctMap ∧
          EVERY (check_freevars tvs' []) targs ∧
          check_freevars (LENGTH targs) [] t ⇒
          type_v tvs' ctMap tenvS v (deBruijn_subst 0 targs t)
   
   [type_subst_deBruijn_inc_list]  Theorem
      
      ⊢ ∀ts' ts tvs inc sk.
          LENGTH tvs = LENGTH ts ∧ EVERY (check_freevars 0 tvs) ts' ⇒
          MAP (deBruijn_inc sk inc)
            (MAP (type_subst (alist_to_fmap (ZIP (tvs,ts)))) ts') =
          MAP
            (type_subst
               (alist_to_fmap
                  (ZIP (tvs,MAP (λt. deBruijn_inc sk inc t) ts)))) ts'
   
   [type_subst_deBruijn_subst_list]  Theorem
      
      ⊢ ∀t tvs tvs' ts ts' ts'' inc.
          LENGTH tvs = LENGTH ts ∧ EVERY (check_freevars 0 tvs) ts'' ⇒
          MAP (deBruijn_subst inc ts')
            (MAP (type_subst (alist_to_fmap (ZIP (tvs,ts)))) ts'') =
          MAP
            (type_subst
               (alist_to_fmap
                  (ZIP (tvs,MAP (λt. deBruijn_subst inc ts' t) ts)))) ts''
   
   [type_v_freevars]  Theorem
      
      ⊢ ∀tvs tenvC tenvS v t.
          type_v tvs tenvC tenvS v t ⇒ check_freevars tvs [] t
   
   [unchanged_tenv]  Theorem
      
      ⊢ ∀tenv. <|v := tenv.v; c := tenv.c; t := tenv.t|> = tenv
   
   
*)
end
