structure closLangTheory :> closLangTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading closLangTheory ... "
    else ()
  
  open Type Term Thm
  local open backend_commonTheory fpSemTheory in end;
  
  structure TDB = struct
    val path =
      holpathdb.subst_pathvars "$(CAKEMLDIR)/compiler/backend/closLangTheory.dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "closLang",
        hash = "5317ea49df6be1f6bec27b03ebd97cbae4dd59b6",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "closLang" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op word_op_size_def _ = ()
  val op word_op_size_def = TDB.find "word_op_size_def"
  fun op word_op_nchotomy _ = ()
  val op word_op_nchotomy = TDB.find "word_op_nchotomy"
  fun op word_op_induction _ = ()
  val op word_op_induction = TDB.find "word_op_induction"
  fun op word_op_distinct _ = ()
  val op word_op_distinct = TDB.find "word_op_distinct"
  fun op word_op_case_eq _ = ()
  val op word_op_case_eq = TDB.find "word_op_case_eq"
  fun op word_op_case_def _ = ()
  val op word_op_case_def = TDB.find "word_op_case_def"
  fun op word_op_case_cong _ = ()
  val op word_op_case_cong = TDB.find "word_op_case_cong"
  fun op word_op_TY_DEF _ = ()
  val op word_op_TY_DEF = TDB.find "word_op_TY_DEF"
  fun op word_op_Axiom _ = ()
  val op word_op_Axiom = TDB.find "word_op_Axiom"
  fun op word_op_11 _ = () val op word_op_11 = TDB.find "word_op_11"
  fun op pure_op_def _ = () val op pure_op_def = TDB.find "pure_op_def"
  fun op pure_ind _ = () val op pure_ind = TDB.find "pure_ind"
  fun op pure_def_primitive _ = ()
  val op pure_def_primitive = TDB.find "pure_def_primitive"
  fun op pure_def _ = () val op pure_def = TDB.find "pure_def"
  fun op op_size_def _ = () val op op_size_def = TDB.find "op_size_def"
  fun op op_nchotomy _ = () val op op_nchotomy = TDB.find "op_nchotomy"
  fun op op_induction _ = () val op op_induction = TDB.find "op_induction"
  fun op op_distinct _ = () val op op_distinct = TDB.find "op_distinct"
  fun op op_case_eq _ = () val op op_case_eq = TDB.find "op_case_eq"
  fun op op_case_def _ = () val op op_case_def = TDB.find "op_case_def"
  fun op op_case_cong _ = () val op op_case_cong = TDB.find "op_case_cong"
  fun op op_TY_DEF _ = () val op op_TY_DEF = TDB.find "op_TY_DEF"
  fun op op_Axiom _ = () val op op_Axiom = TDB.find "op_Axiom"
  fun op op_11 _ = () val op op_11 = TDB.find "op_11"
  fun op mem_op_size_def _ = ()
  val op mem_op_size_def = TDB.find "mem_op_size_def"
  fun op mem_op_nchotomy _ = ()
  val op mem_op_nchotomy = TDB.find "mem_op_nchotomy"
  fun op mem_op_induction _ = ()
  val op mem_op_induction = TDB.find "mem_op_induction"
  fun op mem_op_distinct _ = ()
  val op mem_op_distinct = TDB.find "mem_op_distinct"
  fun op mem_op_case_eq _ = ()
  val op mem_op_case_eq = TDB.find "mem_op_case_eq"
  fun op mem_op_case_def _ = ()
  val op mem_op_case_def = TDB.find "mem_op_case_def"
  fun op mem_op_case_cong _ = ()
  val op mem_op_case_cong = TDB.find "mem_op_case_cong"
  fun op mem_op_TY_DEF _ = ()
  val op mem_op_TY_DEF = TDB.find "mem_op_TY_DEF"
  fun op mem_op_Axiom _ = () val op mem_op_Axiom = TDB.find "mem_op_Axiom"
  fun op mem_op_11 _ = () val op mem_op_11 = TDB.find "mem_op_11"
  fun op int_op_size_def _ = ()
  val op int_op_size_def = TDB.find "int_op_size_def"
  fun op int_op_nchotomy _ = ()
  val op int_op_nchotomy = TDB.find "int_op_nchotomy"
  fun op int_op_induction _ = ()
  val op int_op_induction = TDB.find "int_op_induction"
  fun op int_op_distinct _ = ()
  val op int_op_distinct = TDB.find "int_op_distinct"
  fun op int_op_case_eq _ = ()
  val op int_op_case_eq = TDB.find "int_op_case_eq"
  fun op int_op_case_def _ = ()
  val op int_op_case_def = TDB.find "int_op_case_def"
  fun op int_op_case_cong _ = ()
  val op int_op_case_cong = TDB.find "int_op_case_cong"
  fun op int_op_TY_DEF _ = ()
  val op int_op_TY_DEF = TDB.find "int_op_TY_DEF"
  fun op int_op_Axiom _ = () val op int_op_Axiom = TDB.find "int_op_Axiom"
  fun op int_op_11 _ = () val op int_op_11 = TDB.find "int_op_11"
  fun op has_install_ind _ = ()
  val op has_install_ind = TDB.find "has_install_ind"
  fun op has_install_def_UNION_primitive _ = ()
  val op has_install_def_UNION_primitive = TDB.find
    "has_install_def_UNION_primitive"
  fun op has_install_def_UNION_extract1 _ = ()
  val op has_install_def_UNION_extract1 = TDB.find
    "has_install_def_UNION_extract1"
  fun op has_install_def_UNION_extract0 _ = ()
  val op has_install_def_UNION_extract0 = TDB.find
    "has_install_def_UNION_extract0"
  fun op has_install_def _ = ()
  val op has_install_def = TDB.find "has_install_def"
  fun op glob_op_size_def _ = ()
  val op glob_op_size_def = TDB.find "glob_op_size_def"
  fun op glob_op_nchotomy _ = ()
  val op glob_op_nchotomy = TDB.find "glob_op_nchotomy"
  fun op glob_op_induction _ = ()
  val op glob_op_induction = TDB.find "glob_op_induction"
  fun op glob_op_distinct _ = ()
  val op glob_op_distinct = TDB.find "glob_op_distinct"
  fun op glob_op_case_eq _ = ()
  val op glob_op_case_eq = TDB.find "glob_op_case_eq"
  fun op glob_op_case_def _ = ()
  val op glob_op_case_def = TDB.find "glob_op_case_def"
  fun op glob_op_case_cong _ = ()
  val op glob_op_case_cong = TDB.find "glob_op_case_cong"
  fun op glob_op_TY_DEF _ = ()
  val op glob_op_TY_DEF = TDB.find "glob_op_TY_DEF"
  fun op glob_op_Axiom _ = ()
  val op glob_op_Axiom = TDB.find "glob_op_Axiom"
  fun op glob_op_11 _ = () val op glob_op_11 = TDB.find "glob_op_11"
  fun op exp_size_def _ = () val op exp_size_def = TDB.find "exp_size_def"
  fun op exp_nchotomy _ = () val op exp_nchotomy = TDB.find "exp_nchotomy"
  fun op exp_induction _ = ()
  val op exp_induction = TDB.find "exp_induction"
  fun op exp_distinct _ = () val op exp_distinct = TDB.find "exp_distinct"
  fun op exp_case_eq _ = () val op exp_case_eq = TDB.find "exp_case_eq"
  fun op exp_case_def _ = () val op exp_case_def = TDB.find "exp_case_def"
  fun op exp_case_cong _ = ()
  val op exp_case_cong = TDB.find "exp_case_cong"
  fun op exp_TY_DEF _ = () val op exp_TY_DEF = TDB.find "exp_TY_DEF"
  fun op exp_Axiom _ = () val op exp_Axiom = TDB.find "exp_Axiom"
  fun op exp_11 _ = () val op exp_11 = TDB.find "exp_11"
  fun op exp1_size_lemma _ = ()
  val op exp1_size_lemma = TDB.find "exp1_size_lemma"
  fun op datatype_word_op _ = ()
  val op datatype_word_op = TDB.find "datatype_word_op"
  fun op datatype_op _ = () val op datatype_op = TDB.find "datatype_op"
  fun op datatype_mem_op _ = ()
  val op datatype_mem_op = TDB.find "datatype_mem_op"
  fun op datatype_int_op _ = ()
  val op datatype_int_op = TDB.find "datatype_int_op"
  fun op datatype_glob_op _ = ()
  val op datatype_glob_op = TDB.find "datatype_glob_op"
  fun op datatype_exp _ = () val op datatype_exp = TDB.find "datatype_exp"
  fun op datatype_const_part _ = ()
  val op datatype_const_part = TDB.find "datatype_const_part"
  fun op datatype_const _ = ()
  val op datatype_const = TDB.find "datatype_const"
  fun op datatype_block_op _ = ()
  val op datatype_block_op = TDB.find "datatype_block_op"
  fun op const_size_def _ = ()
  val op const_size_def = TDB.find "const_size_def"
  fun op const_part_size_def _ = ()
  val op const_part_size_def = TDB.find "const_part_size_def"
  fun op const_part_nchotomy _ = ()
  val op const_part_nchotomy = TDB.find "const_part_nchotomy"
  fun op const_part_induction _ = ()
  val op const_part_induction = TDB.find "const_part_induction"
  fun op const_part_distinct _ = ()
  val op const_part_distinct = TDB.find "const_part_distinct"
  fun op const_part_case_eq _ = ()
  val op const_part_case_eq = TDB.find "const_part_case_eq"
  fun op const_part_case_def _ = ()
  val op const_part_case_def = TDB.find "const_part_case_def"
  fun op const_part_case_cong _ = ()
  val op const_part_case_cong = TDB.find "const_part_case_cong"
  fun op const_part_TY_DEF _ = ()
  val op const_part_TY_DEF = TDB.find "const_part_TY_DEF"
  fun op const_part_Axiom _ = ()
  val op const_part_Axiom = TDB.find "const_part_Axiom"
  fun op const_part_11 _ = ()
  val op const_part_11 = TDB.find "const_part_11"
  fun op const_nchotomy _ = ()
  val op const_nchotomy = TDB.find "const_nchotomy"
  fun op const_induction _ = ()
  val op const_induction = TDB.find "const_induction"
  fun op const_distinct _ = ()
  val op const_distinct = TDB.find "const_distinct"
  fun op const_case_eq _ = ()
  val op const_case_eq = TDB.find "const_case_eq"
  fun op const_case_def _ = ()
  val op const_case_def = TDB.find "const_case_def"
  fun op const_case_cong _ = ()
  val op const_case_cong = TDB.find "const_case_cong"
  fun op const_TY_DEF _ = () val op const_TY_DEF = TDB.find "const_TY_DEF"
  fun op const_Axiom _ = () val op const_Axiom = TDB.find "const_Axiom"
  fun op const_11 _ = () val op const_11 = TDB.find "const_11"
  fun op block_op_size_def _ = ()
  val op block_op_size_def = TDB.find "block_op_size_def"
  fun op block_op_nchotomy _ = ()
  val op block_op_nchotomy = TDB.find "block_op_nchotomy"
  fun op block_op_induction _ = ()
  val op block_op_induction = TDB.find "block_op_induction"
  fun op block_op_distinct _ = ()
  val op block_op_distinct = TDB.find "block_op_distinct"
  fun op block_op_case_eq _ = ()
  val op block_op_case_eq = TDB.find "block_op_case_eq"
  fun op block_op_case_def _ = ()
  val op block_op_case_def = TDB.find "block_op_case_def"
  fun op block_op_case_cong _ = ()
  val op block_op_case_cong = TDB.find "block_op_case_cong"
  fun op block_op_TY_DEF _ = ()
  val op block_op_TY_DEF = TDB.find "block_op_TY_DEF"
  fun op block_op_Axiom _ = ()
  val op block_op_Axiom = TDB.find "block_op_Axiom"
  fun op block_op_11 _ = () val op block_op_11 = TDB.find "block_op_11"
  fun op assign_get_code_label_ind _ = ()
  val op assign_get_code_label_ind = TDB.find "assign_get_code_label_ind"
  fun op assign_get_code_label_def_primitive _ = ()
  val op assign_get_code_label_def_primitive = TDB.find
    "assign_get_code_label_def_primitive"
  fun op assign_get_code_label_def _ = ()
  val op assign_get_code_label_def = TDB.find "assign_get_code_label_def"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "closLang"

end
