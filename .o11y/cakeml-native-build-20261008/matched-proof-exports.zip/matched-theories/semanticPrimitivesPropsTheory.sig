signature semanticPrimitivesPropsTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val FV_dec_def : thm
    val FV_def_UNION_extract0 : thm
    val FV_def_UNION_extract1 : thm
    val FV_def_UNION_extract2 : thm
    val FV_def_UNION_extract3 : thm
    val FV_def_UNION_primitive : thm
    val ctors_of_dec_def_primitive : thm
    val ctors_of_tdef_def : thm
    val dest_Refv_def : thm
    val every_error_result_def : thm
    val every_result_def : thm
    val is_Refv_def_primitive : thm
    val map_error_result_def : thm
    val map_result_def : thm
    val map_sv_def : thm
    val shift_lookup_def : thm
    val store_v_vs_def : thm
    val store_vs_def : thm
  
  (*  Theorems  *)
    val Boolv_11 : thm
    val EVERY_store_vs_intro : thm
    val EVERY_sv_every_EVERY_store_vs : thm
    val EVERY_sv_every_MAP_map_sv : thm
    val FV_def : thm
    val FV_defs_MAP : thm
    val FV_ind : thm
    val FV_pes_MAP : thm
    val LIST_REL_store_vs_intro : thm
    val build_rec_env_merge : thm
    val concrete_v_list : thm
    val concrete_v_simps : thm
    val ctors_of_dec_def : thm
    val ctors_of_dec_ind : thm
    val do_app_NONE_ffi : thm
    val do_app_SOME_ffi_same : thm
    val do_app_cases : thm
    val do_app_ffi_changed : thm
    val do_app_ffi_unchanged : thm
    val do_app_not_timeout : thm
    val do_app_type_error : thm
    val do_arith_check_type : thm
    val do_con_check_build_conv : thm
    val do_conversion_check_type : thm
    val do_opapp_cases : thm
    val do_shift_def : thm
    val do_shift_ind : thm
    val exc_rel_def : thm
    val exc_rel_ind : thm
    val exc_rel_raise1 : thm
    val exc_rel_raise2 : thm
    val exc_rel_refl : thm
    val exc_rel_trans : thm
    val exc_rel_type_error1 : thm
    val exc_rel_type_error2 : thm
    val extend_dec_env_assoc : thm
    val find_recfun_ALOOKUP : thm
    val find_recfun_el : thm
    val is_Refv_def : thm
    val is_Refv_ind : thm
    val lit_same_type_refl : thm
    val lit_same_type_sym : thm
    val map_error_result_I : thm
    val map_error_result_Rtype_error : thm
    val map_match_def : thm
    val map_match_ind : thm
    val map_result_Rerr : thm
    val map_result_Rval : thm
    val map_sv_compose : thm
    val nat_to_v_11 : thm
    val pat_bindings_accum : thm
    val pmatch_acc : thm
    val pmatch_append : thm
    val pmatch_extend : thm
    val pmatch_nsAppend : thm
    val pmatch_nsAppend_Match : thm
    val pmatch_nsAppend_No_match : thm
    val prim_type_cases : thm
    val result_rel_Rerr1 : thm
    val result_rel_Rerr2 : thm
    val result_rel_Rval : thm
    val result_rel_def : thm
    val result_rel_ind : thm
    val result_rel_refl : thm
    val result_rel_trans : thm
    val sv_every_def : thm
    val sv_every_ind : thm
    val sv_rel_O : thm
    val sv_rel_cases : thm
    val sv_rel_def : thm
    val sv_rel_ind : thm
    val sv_rel_mono : thm
    val sv_rel_refl : thm
    val sv_rel_trans : thm
    val unchanged_env : thm
    val with_same_clock : thm
    val with_same_v : thm
(*
   [namespaceProps] Parent theory of "semanticPrimitivesProps"
   
   [semanticPrimitives] Parent theory of "semanticPrimitivesProps"
   
   [FV_dec_def]  Definition
      
      ⊢ (∀locs p e. FV_dec (Dlet locs p e) = FV (Mat e [(p,Lit ARB)])) ∧
        (∀locs defs.
           FV_dec (Dletrec locs defs) = FV (Letrec defs (Lit ARB))) ∧
        (∀v0 v1. FV_dec (Dtype v0 v1) = ∅) ∧
        (∀v2 v3 v4 v5. FV_dec (Dtabbrev v2 v3 v4 v5) = ∅) ∧
        ∀v6 v7 v8. FV_dec (Dexn v6 v7 v8) = ∅
   
   [FV_def_UNION_extract0]  Definition
      
      ⊢ ∀x. FV x = FV_def_UNION (INL x)
   
   [FV_def_UNION_extract1]  Definition
      
      ⊢ ∀x. FV_list x = FV_def_UNION (INR (INL x))
   
   [FV_def_UNION_extract2]  Definition
      
      ⊢ ∀x. FV_pes x = FV_def_UNION (INR (INR (INL x)))
   
   [FV_def_UNION_extract3]  Definition
      
      ⊢ ∀x. FV_defs x = FV_def_UNION (INR (INR (INR x)))
   
   [FV_def_UNION_primitive]  Definition
      
      ⊢ FV_def_UNION =
        WFREC
          (@R. WF R ∧ (∀e. R (INL e) (INL (Raise e))) ∧
               (∀e pes. R (INR (INR (INL pes))) (INL (Handle e pes))) ∧
               (∀pes e. R (INL e) (INL (Handle e pes))) ∧
               (∀v1 ls. R (INR (INL ls)) (INL (Con v1 ls))) ∧
               (∀x e. R (INL e) (INL (Fun x e))) ∧
               (∀v2 es. R (INR (INL es)) (INL (App v2 es))) ∧
               (∀e1 v3 e2. R (INL e2) (INL (Log v3 e1 e2))) ∧
               (∀e2 v3 e1. R (INL e1) (INL (Log v3 e1 e2))) ∧
               (∀e2 e1 e3. R (INL e3) (INL (If e1 e2 e3))) ∧
               (∀e3 e1 e2. R (INL e2) (INL (If e1 e2 e3))) ∧
               (∀e3 e2 e1. R (INL e1) (INL (If e1 e2 e3))) ∧
               (∀e pes. R (INR (INR (INL pes))) (INL (Mat e pes))) ∧
               (∀pes e. R (INL e) (INL (Mat e pes))) ∧
               (∀b xo e. R (INL e) (INL (Let xo e b))) ∧
               (∀e xo b. R (INL b) (INL (Let xo e b))) ∧
               (∀b defs. R (INR (INR (INR defs))) (INL (Letrec defs b))) ∧
               (∀defs b. R (INL b) (INL (Letrec defs b))) ∧
               (∀t e. R (INL e) (INL (Tannot e t))) ∧
               (∀l e. R (INL e) (INL (Lannot e l))) ∧
               (∀e es. R (INR (INL es)) (INR (INL (e::es)))) ∧
               (∀es e. R (INL e) (INR (INL (e::es)))) ∧
               (∀e p pes.
                  R (INR (INR (INL pes))) (INR (INR (INL ((p,e)::pes))))) ∧
               (∀pes p e. R (INL e) (INR (INR (INL ((p,e)::pes))))) ∧
               (∀defs x v4 e. R (INL e) (INR (INR (INR ((v4,x,e)::defs))))) ∧
               ∀e x v4 defs.
                 R (INR (INR (INR defs)))
                   (INR (INR (INR ((v4,x,e)::defs)))))
          (λFV_def_UNION a.
               case a of
                 INL (Raise e) => I (FV_def_UNION (INL e))
               | INL (Handle e' pes) =>
                 I
                   (FV_def_UNION (INL e') ∪
                    FV_def_UNION (INR (INR (INL pes))))
               | INL (Lit v0) => I ∅
               | INL (Con v1 ls) => I (FV_def_UNION (INR (INL ls)))
               | INL (Var id) => I {id}
               | INL (Fun x e'') =>
                 I (FV_def_UNION (INL e'') DIFF {Short x})
               | INL (App v2 es) => I (FV_def_UNION (INR (INL es)))
               | INL (Log v3 e1 e2) =>
                 I (FV_def_UNION (INL e1) ∪ FV_def_UNION (INL e2))
               | INL (If e1' e2' e3) =>
                 I
                   (FV_def_UNION (INL e1') ∪ FV_def_UNION (INL e2') ∪
                    FV_def_UNION (INL e3))
               | INL (Mat e'³' pes') =>
                 I
                   (FV_def_UNION (INL e'³') ∪
                    FV_def_UNION (INR (INR (INL pes'))))
               | INL (Let xo e'⁴' b) =>
                 I
                   (FV_def_UNION (INL e'⁴') ∪
                    (FV_def_UNION (INL b) DIFF
                     case xo of NONE => ∅ | SOME x => {Short x}))
               | INL (Letrec defs b') =>
                 I
                   (FV_def_UNION (INR (INR (INR defs))) ∪
                    FV_def_UNION (INL b') DIFF set (MAP (Short ∘ FST) defs))
               | INL (Tannot e'⁵' t) => I (FV_def_UNION (INL e'⁵'))
               | INL (Lannot e'⁶' l) => I (FV_def_UNION (INL e'⁶'))
               | INR (INL []) => I ∅
               | INR (INL (e'⁷'::es')) =>
                 I (FV_def_UNION (INL e'⁷') ∪ FV_def_UNION (INR (INL es')))
               | INR (INR (INL [])) => I ∅
               | INR (INR (INL ((p,e'⁸')::pes''))) =>
                 I
                   (FV_def_UNION (INL e'⁸') DIFF
                    IMAGE Short (set (pat_bindings p [])) ∪
                    FV_def_UNION (INR (INR (INL pes''))))
               | INR (INR (INR [])) => I ∅
               | INR (INR (INR ((v4,x',e'⁹')::defs'))) =>
                 I
                   (FV_def_UNION (INL e'⁹') DIFF {Short x'} ∪
                    FV_def_UNION (INR (INR (INR defs')))))
   
   [ctors_of_dec_def_primitive]  Definition
      
      ⊢ ctors_of_dec =
        WFREC (@R. WF R)
          (λctors_of_dec a.
               case a of
                 Dlet v20 v21 v22 => I []
               | Dletrec v23 v24 => I []
               | Dtype locs tds => I (FLAT (MAP ctors_of_tdef tds))
               | Dtabbrev v27 v28 v29 v30 => I []
               | Dexn locs' s v0 => I [s]
               | Dmod v34 v35 => I []
               | Dlocal v36 v37 => I []
               | Denv v38 => I [])
   
   [ctors_of_tdef_def]  Definition
      
      ⊢ ∀v0 v1 condefs. ctors_of_tdef (v0,v1,condefs) = MAP FST condefs
   
   [dest_Refv_def]  Definition
      
      ⊢ ∀v. dest_Refv (Refv v) = v
   
   [every_error_result_def]  Definition
      
      ⊢ (∀P e. every_error_result P (Rraise e) ⇔ P e) ∧
        ∀P a. every_error_result P (Rabort a) ⇔ T
   
   [every_result_def]  Definition
      
      ⊢ (∀P1 P2 v. every_result P1 P2 (Rval v) ⇔ P1 v) ∧
        ∀P1 P2 e. every_result P1 P2 (Rerr e) ⇔ every_error_result P2 e
   
   [is_Refv_def_primitive]  Definition
      
      ⊢ is_Refv =
        WFREC (@R. WF R)
          (λis_Refv a.
               case a of
                 Refv v0 => I T
               | W8array v7 => I F
               | Varray v8 => I F
               | Thunk v9 v10 => I F)
   
   [map_error_result_def]  Definition
      
      ⊢ (∀f e. map_error_result f (Rraise e) = Rraise (f e)) ∧
        ∀f a. map_error_result f (Rabort a) = Rabort a
   
   [map_result_def]  Definition
      
      ⊢ (∀f1 f2 v. map_result f1 f2 (Rval v) = Rval (f1 v)) ∧
        ∀f1 f2 e. map_result f1 f2 (Rerr e) = Rerr (map_error_result f2 e)
   
   [map_sv_def]  Definition
      
      ⊢ (∀f v. map_sv f (Refv v) = Refv (f v)) ∧
        (∀v0 w. map_sv v0 (W8array w) = W8array w) ∧
        (∀f vs. map_sv f (Varray vs) = Varray (MAP f vs)) ∧
        ∀f m v. map_sv f (Thunk m v) = Thunk m (f v)
   
   [shift_lookup_def]  Definition
      
      ⊢ shift_lookup Lsl = $<< ∧ shift_lookup Lsr = $>>> ∧
        shift_lookup Asr = $>> ∧ shift_lookup Ror = $#>>
   
   [store_v_vs_def]  Definition
      
      ⊢ (∀v. store_v_vs (Refv v) = [v]) ∧
        (∀vs. store_v_vs (Varray vs) = vs) ∧
        (∀v0. store_v_vs (W8array v0) = []) ∧
        ∀v1 v. store_v_vs (Thunk v1 v) = [v]
   
   [store_vs_def]  Definition
      
      ⊢ ∀s. store_vs s = FLAT (MAP store_v_vs s)
   
   [Boolv_11]  Theorem
      
      ⊢ Boolv b1 = Boolv b2 ⇔ (b1 ⇔ b2)
   
   [EVERY_store_vs_intro]  Theorem
      
      ⊢ ∀P ls. EVERY (sv_every P) ls ⇒ EVERY P (store_vs ls)
   
   [EVERY_sv_every_EVERY_store_vs]  Theorem
      
      ⊢ ∀P ls. EVERY (sv_every P) ls ⇔ EVERY P (store_vs ls)
   
   [EVERY_sv_every_MAP_map_sv]  Theorem
      
      ⊢ ∀P f ls.
          EVERY P (MAP f (store_vs ls)) ⇒
          EVERY (sv_every P) (MAP (map_sv f) ls)
   
   [FV_def]  Theorem
      
      ⊢ (∀e. FV (Raise e) = FV e) ∧
        (∀pes e. FV (Handle e pes) = FV e ∪ FV_pes pes) ∧
        (∀v0. FV (Lit v0) = ∅) ∧ (∀v1 ls. FV (Con v1 ls) = FV_list ls) ∧
        (∀id. FV (Var id) = {id}) ∧
        (∀x e. FV (Fun x e) = FV e DIFF {Short x}) ∧
        (∀v2 es. FV (App v2 es) = FV_list es) ∧
        (∀v3 e2 e1. FV (Log v3 e1 e2) = FV e1 ∪ FV e2) ∧
        (∀e3 e2 e1. FV (If e1 e2 e3) = FV e1 ∪ FV e2 ∪ FV e3) ∧
        (∀pes e. FV (Mat e pes) = FV e ∪ FV_pes pes) ∧
        (∀xo e b.
           FV (Let xo e b) =
           FV e ∪ (FV b DIFF case xo of NONE => ∅ | SOME x => {Short x})) ∧
        (∀defs b.
           FV (Letrec defs b) =
           FV_defs defs ∪ FV b DIFF set (MAP (Short ∘ FST) defs)) ∧
        (∀t e. FV (Tannot e t) = FV e) ∧ (∀l e. FV (Lannot e l) = FV e) ∧
        FV_list [] = ∅ ∧ (∀es e. FV_list (e::es) = FV e ∪ FV_list es) ∧
        FV_pes [] = ∅ ∧
        (∀pes p e.
           FV_pes ((p,e)::pes) =
           FV e DIFF IMAGE Short (set (pat_bindings p [])) ∪ FV_pes pes) ∧
        FV_defs [] = ∅ ∧
        ∀x v4 e defs.
          FV_defs ((v4,x,e)::defs) = FV e DIFF {Short x} ∪ FV_defs defs
   
   [FV_defs_MAP]  Theorem
      
      ⊢ ∀ls.
          FV_defs ls =
          BIGUNION (IMAGE (λ(f,x,e). FV e DIFF {Short x}) (set ls))
   
   [FV_ind]  Theorem
      
      ⊢ ∀P0 P1 P2 P3.
          (∀e. P0 e ⇒ P0 (Raise e)) ∧
          (∀e pes. P0 e ∧ P2 pes ⇒ P0 (Handle e pes)) ∧
          (∀v0. P0 (Lit v0)) ∧ (∀v1 ls. P1 ls ⇒ P0 (Con v1 ls)) ∧
          (∀id. P0 (Var id)) ∧ (∀x e. P0 e ⇒ P0 (Fun x e)) ∧
          (∀v2 es. P1 es ⇒ P0 (App v2 es)) ∧
          (∀v3 e1 e2. P0 e1 ∧ P0 e2 ⇒ P0 (Log v3 e1 e2)) ∧
          (∀e1 e2 e3. P0 e1 ∧ P0 e2 ∧ P0 e3 ⇒ P0 (If e1 e2 e3)) ∧
          (∀e pes. P0 e ∧ P2 pes ⇒ P0 (Mat e pes)) ∧
          (∀xo e b. P0 b ∧ P0 e ⇒ P0 (Let xo e b)) ∧
          (∀defs b. P0 b ∧ P3 defs ⇒ P0 (Letrec defs b)) ∧
          (∀e t. P0 e ⇒ P0 (Tannot e t)) ∧ (∀e l. P0 e ⇒ P0 (Lannot e l)) ∧
          P1 [] ∧ (∀e es. P0 e ∧ P1 es ⇒ P1 (e::es)) ∧ P2 [] ∧
          (∀p e pes. P0 e ∧ P2 pes ⇒ P2 ((p,e)::pes)) ∧ P3 [] ∧
          (∀v4 x e defs. P0 e ∧ P3 defs ⇒ P3 ((v4,x,e)::defs)) ⇒
          (∀v0. P0 v0) ∧ (∀v0. P1 v0) ∧ (∀v0. P2 v0) ∧ ∀v0. P3 v0
   
   [FV_pes_MAP]  Theorem
      
      ⊢ FV_pes pes =
        BIGUNION
          (IMAGE (λ(p,e). FV e DIFF IMAGE Short (set (pat_bindings p [])))
             (set pes))
   
   [LIST_REL_store_vs_intro]  Theorem
      
      ⊢ ∀P l1 l2.
          LIST_REL (sv_rel P) l1 l2 ⇒
          LIST_REL P (store_vs l1) (store_vs l2)
   
   [build_rec_env_merge]  Theorem
      
      ⊢ ∀funs funs' env env'.
          build_rec_env funs env env' =
          nsAppend
            (alist_to_ns (MAP (λ(f,n,e). (f,Recclosure env funs f)) funs))
            env'
   
   [concrete_v_list]  Theorem
      
      ⊢ ∀xs. concrete_v_list xs ⇔ EVERY concrete_v xs
   
   [concrete_v_simps]  Theorem
      
      ⊢ (concrete_v (Litv l) ⇔ T) ∧ (concrete_v (Loc b n) ⇔ T) ∧
        (concrete_v (Conv stmp xs) ⇔ EVERY concrete_v xs) ∧
        (concrete_v (Vectorv xs) ⇔ EVERY concrete_v xs) ∧
        (concrete_v (Env id e) ⇔ F) ∧ (concrete_v (Closure e2 nm x) ⇔ F) ∧
        (concrete_v (Recclosure e3 funs nm2) ⇔ F)
   
   [ctors_of_dec_def]  Theorem
      
      ⊢ ctors_of_dec (Dtype locs tds) = FLAT (MAP ctors_of_tdef tds) ∧
        ctors_of_dec (Dexn locs s v0) = [s] ∧
        ctors_of_dec (Dlet v v2 v3) = [] ∧
        ctors_of_dec (Dletrec v4 v5) = [] ∧
        ctors_of_dec (Dtabbrev v8 v9 v10 v11) = [] ∧
        ctors_of_dec (Dmod v15 v16) = [] ∧
        ctors_of_dec (Dlocal v17 v18) = [] ∧ ctors_of_dec (Denv v19) = []
   
   [ctors_of_dec_ind]  Theorem
      
      ⊢ ∀P. (∀locs tds. P (Dtype locs tds)) ∧
            (∀locs s v0. P (Dexn locs s v0)) ∧
            (∀v v2 v3. P (Dlet v v2 v3)) ∧ (∀v4 v5. P (Dletrec v4 v5)) ∧
            (∀v8 v9 v10 v11. P (Dtabbrev v8 v9 v10 v11)) ∧
            (∀v15 v16. P (Dmod v15 v16)) ∧ (∀v17 v18. P (Dlocal v17 v18)) ∧
            (∀v19. P (Denv v19)) ⇒
            ∀v. P v
   
   [do_app_NONE_ffi]  Theorem
      
      ⊢ do_app (refs,ffi) op args = NONE ⇒
        do_app (refs,ffi') op args = NONE
   
   [do_app_SOME_ffi_same]  Theorem
      
      ⊢ do_app (refs,ffi) op args = SOME ((refs',ffi),r) ∧
        (∀outcome. r ≠ Rerr (Rabort (Rffi_error outcome))) ⇒
        do_app (refs,ffi') op args = SOME ((refs',ffi'),r)
   
   [do_app_cases]  Theorem
      
      ⊢ do_app (s,t) op vs = SOME (st',v) ⇔
        (∃a ty v'.
           op = Arith a ty ∧ EVERY (check_type ty) vs ∧
           do_arith a ty vs = SOME v' ∧
           (case v' of
              INL exn => SOME ((s,t),Rerr (Rraise exn))
            | INR res => SOME ((s,t),Rval res)) = SOME (st',v)) ∨
        (∃ty1 ty2 v'⁸' l.
           op = FromTo ty1 ty2 ∧ vs = v'⁸'::l ∧
           (¬check_type ty1 v'⁸' ∨
            ∃v'.
              l = [] ∧ do_conversion v'⁸' ty1 ty2 = SOME v' ∧
              (case v' of
                 INL exn => SOME ((s,t),Rerr (Rraise exn))
               | INR res => SOME ((s,t),Rval res)) = SOME (st',v)) ∧
           check_type ty1 v'⁸') ∨
        (∃v50 op' n v83.
           op = Shift v50 op' n ∧ vs = [Litv v83] ∧
           ((∃w. v50 = W8 ∧ v83 = Word8 w ∧ (s,t) = st' ∧
                 Rval (Litv (Word8 (shift8_lookup op' w n))) = v) ∨
            ∃w'.
              v50 = W64 ∧ v83 = Word64 w' ∧ (s,t) = st' ∧
              Rval (Litv (Word64 (shift64_lookup op' w' n))) = v)) ∨
        (∃v1 v2 b.
           op = Equality ∧ vs = [v1; v2] ∧ do_eq v1 v2 = Eq_val b ∧
           (s,t) = st' ∧ Rval (Boolv b) = v) ∨
        (∃test test_ty v1' v2' b.
           op = Test test test_ty ∧ vs = [v1'; v2'] ∧
           do_test test test_ty v1' v2' = Eq_val b ∧ (s,t) = st' ∧
           Rval (Boolv b) = v) ∨
        (∃b lnum v' s'.
           op = Opassign ∧ vs = [Loc b lnum; v'] ∧
           store_assign lnum (Refv v') s = SOME s' ∧ (s',t) = st' ∧
           v = Rval (Conv NONE [])) ∨
        (∃v' s' n.
           op = Opref ∧ vs = [v'] ∧ store_alloc (Refv v') s = (s',n) ∧
           (s',t) = st' ∧ Rval (Loc T n) = v) ∨
        (∃b' n' v'.
           op = Opderef ∧ vs = [Loc b' n'] ∧
           store_lookup n' s = SOME (Refv v') ∧ (s,t) = st' ∧ Rval v' = v) ∨
        (∃v240 w'' n''.
           op = Aw8alloc ∧ vs = Litv (IntLit n'')::Litv (Word8 w'')::v240 ∧
           (¬(n'' < 0) ∨
            v240 = [] ∧ (s,t) = st' ∧ v = Rerr (Rraise sub_exn_v)) ∧
           (n'' < 0 ∨
            ∃s' lnum.
              v240 = [] ∧
              store_alloc (W8array (REPLICATE (Num (ABS n'')) w'')) s =
              (s',lnum) ∧ (s',t) = st' ∧ Rval (Loc T lnum) = v)) ∨
        (∃v352 lnum' v360 i.
           op = Aw8sub ∧ vs = Loc v352 lnum'::Litv (IntLit i)::v360 ∧
           (¬(i < 0) ∨
            ∃ws.
              v360 = [] ∧ store_lookup lnum' s = SOME (W8array ws) ∧
              (s,t) = st' ∧ v = Rerr (Rraise sub_exn_v)) ∧
           (i < 0 ∨
            ∃ws.
              v360 = [] ∧ store_lookup lnum' s = SOME (W8array ws) ∧
              (¬(Num (ABS i) ≥ LENGTH ws) ∨
               (s,t) = st' ∧ v = Rerr (Rraise sub_exn_v)) ∧
              (Num (ABS i) ≥ LENGTH ws ∨
               (s,t) = st' ∧ Rval (Litv (Word8 ws❲Num (ABS i)❳)) = v))) ∨
        (∃v432 n'³' ws.
           op = Aw8length ∧ vs = [Loc v432 n'³'] ∧
           store_lookup n'³' s = SOME (W8array ws) ∧ (s,t) = st' ∧
           Rval (Litv (IntLit (&LENGTH ws))) = v) ∨
        (∃v468 lnum'³' v480 w'³' i''.
           op = Aw8update ∧
           vs =
           Loc v468 lnum'³'::Litv (IntLit i'')::Litv (Word8 w'³')::v480 ∧
           (¬(i'' < 0) ∨
            ∃ws.
              v480 = [] ∧ store_lookup lnum'³' s = SOME (W8array ws) ∧
              (s,t) = st' ∧ v = Rerr (Rraise sub_exn_v)) ∧
           (i'' < 0 ∨
            ∃ws.
              v480 = [] ∧ store_lookup lnum'³' s = SOME (W8array ws) ∧
              (¬(Num (ABS i'') ≥ LENGTH ws) ∨
               (s,t) = st' ∧ v = Rerr (Rraise sub_exn_v)) ∧
              (Num (ABS i'') ≥ LENGTH ws ∨
               ∃s'.
                 store_assign lnum'³'
                   (W8array (LUPDATE w'³' (Num (ABS i'')) ws)) s = SOME s' ∧
                 (s',t) = st' ∧ v = Rval (Conv NONE [])))) ∨
        (∃len off strng.
           op = CopyStrStr ∧
           vs = [Litv (StrLit strng); Litv (IntLit off); Litv (IntLit len)] ∧
           (s,t) = st' ∧
           (copy_array (explode strng,off) len NONE = NONE ∧
            v = Rerr (Rraise sub_exn_v) ∨
            ∃cs.
              copy_array (explode strng,off) len NONE = SOME cs ∧
              Rval (Litv (StrLit (implode cs))) = v)) ∨
        (∃v740 dst dstoff len' off' strng' ws.
           op = CopyStrAw8 ∧
           vs =
           [Litv (StrLit strng'); Litv (IntLit off'); Litv (IntLit len');
            Loc v740 dst; Litv (IntLit dstoff)] ∧
           store_lookup dst s = SOME (W8array ws) ∧
           (copy_array (explode strng',off') len'
              (SOME (ws_to_chars ws,dstoff)) = NONE ∧ (s,t) = st' ∧
            v = Rerr (Rraise sub_exn_v) ∨
            ∃cs s'.
              copy_array (explode strng',off') len'
                (SOME (ws_to_chars ws,dstoff)) = SOME cs ∧
              store_assign dst (W8array (chars_to_ws cs)) s = SOME s' ∧
              (s',t) = st' ∧ v = Rval (Conv NONE []))) ∨
        (∃v940 src len'' off'' ws.
           op = CopyAw8Str ∧
           vs = [Loc v940 src; Litv (IntLit off''); Litv (IntLit len'')] ∧
           store_lookup src s = SOME (W8array ws) ∧ (s,t) = st' ∧
           (copy_array (ws,off'') len'' NONE = NONE ∧
            v = Rerr (Rraise sub_exn_v) ∨
            ∃ws'.
              copy_array (ws,off'') len'' NONE = SOME ws' ∧
              Rval (Litv (StrLit (implode (ws_to_chars ws')))) = v)) ∨
        (∃v1064 src' v1104 dst' dstoff' len'³' off'³' ws ds.
           op = CopyAw8Aw8 ∧
           vs =
           [Loc v1064 src'; Litv (IntLit off'³'); Litv (IntLit len'³');
            Loc v1104 dst'; Litv (IntLit dstoff')] ∧
           store_lookup src' s = SOME (W8array ws) ∧
           store_lookup dst' s = SOME (W8array ds) ∧
           (copy_array (ws,off'³') len'³' (SOME (ds,dstoff')) = NONE ∧
            (s,t) = st' ∧ v = Rerr (Rraise sub_exn_v) ∨
            ∃ws' s'.
              copy_array (ws,off'³') len'³' (SOME (ds,dstoff')) = SOME ws' ∧
              store_assign dst' (W8array ws') s = SOME s' ∧ (s',t) = st' ∧
              v = Rval (Conv NONE []))) ∨
        (∃v1264 dst'' str_arg bs new_bs s'.
           op = XorAw8Str_unsafe ∧
           vs = [Loc v1264 dst''; Litv (StrLit str_arg)] ∧
           store_lookup dst'' s = SOME (W8array bs) ∧
           xor_bytes (MAP (n2w ∘ ORD) (explode str_arg)) bs = SOME new_bs ∧
           store_assign dst'' (W8array new_bs) s = SOME s' ∧ (s',t) = st' ∧
           v = Rval (Conv NONE [])) ∨
        (∃v'' ls.
           op = Implode ∧ vs = [v''] ∧ v_to_char_list v'' = SOME ls ∧
           (s,t) = st' ∧ Rval (Litv (StrLit (implode ls))) = v) ∨
        (∃strng.
           op = Explode ∧ vs = [Litv (StrLit strng)] ∧ (s,t) = st' ∧
           Rval (list_to_v (MAP (λc. Litv (Char c)) (explode strng))) = v) ∨
        (∃v1335 v1340 i'⁴'.
           op = Strsub ∧ vs = v1335::Litv (IntLit i'⁴')::v1340 ∧
           (¬(i'⁴' < 0) ∨
            ∃strng''.
              v1335 = Litv (StrLit strng'') ∧ v1340 = [] ∧ (s,t) = st' ∧
              v = Rerr (Rraise sub_exn_v)) ∧
           (i'⁴' < 0 ∨
            ∃strng''.
              v1335 = Litv (StrLit strng'') ∧ v1340 = [] ∧
              (¬(Num (ABS i'⁴') ≥ strlen strng'') ∨
               (s,t) = st' ∧ v = Rerr (Rraise sub_exn_v)) ∧
              (Num (ABS i'⁴') ≥ strlen strng'' ∨
               (s,t) = st' ∧
               Rval (Litv (Char (explode strng'')❲Num (ABS i'⁴')❳)) = v))) ∨
        (∃strng'³'.
           op = Strlen ∧ vs = [Litv (StrLit strng'³')] ∧ (s,t) = st' ∧
           Rval (Litv (IntLit (&strlen strng'³'))) = v) ∨
        (∃v'³' vs' strng.
           op = Strcat ∧ vs = [v'³'] ∧ v_to_list v'³' = SOME vs' ∧
           vs_to_string vs' = SOME strng ∧ (s,t) = st' ∧
           Rval (Litv (StrLit strng)) = v) ∨
        (∃v'⁴' vs'.
           op = VfromList ∧ vs = [v'⁴'] ∧ v_to_list v'⁴' = SOME vs' ∧
           (s,t) = st' ∧ Rval (Vectorv vs') = v) ∨
        (∃v1491 v1496 i'⁶'.
           op = Vsub ∧ vs = v1491::Litv (IntLit i'⁶')::v1496 ∧
           (¬(i'⁶' < 0) ∨
            ∃vs'.
              v1491 = Vectorv vs' ∧ v1496 = [] ∧ (s,t) = st' ∧
              v = Rerr (Rraise sub_exn_v)) ∧
           (i'⁶' < 0 ∨
            ∃vs'.
              v1491 = Vectorv vs' ∧ v1496 = [] ∧
              (¬(Num (ABS i'⁶') ≥ LENGTH vs') ∨
               (s,t) = st' ∧ v = Rerr (Rraise sub_exn_v)) ∧
              (Num (ABS i'⁶') ≥ LENGTH vs' ∨
               (s,t) = st' ∧ Rval vs'❲Num (ABS i'⁶')❳ = v))) ∨
        (∃vs''.
           op = Vlength ∧ vs = [Vectorv vs''] ∧ (s,t) = st' ∧
           Rval (Litv (IntLit (&LENGTH vs''))) = v) ∨
        (∃v'⁵' v1612 n'⁴'.
           op = Aalloc ∧ vs = Litv (IntLit n'⁴')::v'⁵'::v1612 ∧
           (¬(n'⁴' < 0) ∨
            v1612 = [] ∧ (s,t) = st' ∧ v = Rerr (Rraise sub_exn_v)) ∧
           (n'⁴' < 0 ∨
            ∃s' lnum.
              v1612 = [] ∧
              store_alloc (Varray (REPLICATE (Num (ABS n'⁴')) v'⁵')) s =
              (s',lnum) ∧ (s',t) = st' ∧ Rval (Loc T lnum) = v)) ∨
        (∃s' lnum.
           op = AallocEmpty ∧ vs = [Conv NONE []] ∧
           store_alloc (Varray []) s = (s',lnum) ∧ (s',t) = st' ∧
           Rval (Loc T lnum) = v) ∨
        (∃s' lnum.
           op = AallocFixed ∧ store_alloc (Varray vs) s = (s',lnum) ∧
           (s',t) = st' ∧ Rval (Loc T lnum) = v) ∨
        (∃v1726 lnum'⁵' v1734 i'⁷'.
           op = Asub ∧ vs = Loc v1726 lnum'⁵'::Litv (IntLit i'⁷')::v1734 ∧
           (¬(i'⁷' < 0) ∨
            ∃vs.
              v1734 = [] ∧ store_lookup lnum'⁵' s = SOME (Varray vs) ∧
              (s,t) = st' ∧ v = Rerr (Rraise sub_exn_v)) ∧
           (i'⁷' < 0 ∨
            ∃vs.
              v1734 = [] ∧ store_lookup lnum'⁵' s = SOME (Varray vs) ∧
              (¬(Num (ABS i'⁷') ≥ LENGTH vs) ∨
               (s,t) = st' ∧ v = Rerr (Rraise sub_exn_v)) ∧
              (Num (ABS i'⁷') ≥ LENGTH vs ∨
               (s,t) = st' ∧ Rval vs❲Num (ABS i'⁷')❳ = v))) ∨
        (∃v1806 n'⁵' ws.
           op = Alength ∧ vs = [Loc v1806 n'⁵'] ∧
           store_lookup n'⁵' s = SOME (Varray ws) ∧ (s,t) = st' ∧
           Rval (Litv (IntLit (&LENGTH ws))) = v) ∨
        (∃v1842 lnum'⁷' v'⁶' v1854 i'⁹'.
           op = Aupdate ∧
           vs = Loc v1842 lnum'⁷'::Litv (IntLit i'⁹')::v'⁶'::v1854 ∧
           (¬(i'⁹' < 0) ∨
            ∃vs.
              v1854 = [] ∧ store_lookup lnum'⁷' s = SOME (Varray vs) ∧
              (s,t) = st' ∧ v = Rerr (Rraise sub_exn_v)) ∧
           (i'⁹' < 0 ∨
            ∃vs.
              v1854 = [] ∧ store_lookup lnum'⁷' s = SOME (Varray vs) ∧
              (¬(Num (ABS i'⁹') ≥ LENGTH vs) ∨
               (s,t) = st' ∧ v = Rerr (Rraise sub_exn_v)) ∧
              (Num (ABS i'⁹') ≥ LENGTH vs ∨
               ∃s'.
                 store_assign lnum'⁷'
                   (Varray (LUPDATE v'⁶' (Num (ABS i'⁹')) vs)) s = SOME s' ∧
                 (s',t) = st' ∧ v = Rval (Conv NONE [])))) ∨
        (∃v1906 i'⁵' vs'.
           op = Vsub_unsafe ∧ vs = Vectorv vs'::Litv (IntLit i'⁵')::v1906 ∧
           ((¬(0 ≤ i'⁵') ∨ ¬(Num i'⁵' < LENGTH vs')) ∨
            v1906 = [] ∧ (s,t) = st' ∧ Rval vs'❲Num i'⁵'❳ = v) ∧ 0 ≤ i'⁵' ∧
           Num i'⁵' < LENGTH vs') ∨
        (∃v2006 lnum'⁶' v2014 i'⁸'.
           op = Asub_unsafe ∧
           vs = Loc v2006 lnum'⁶'::Litv (IntLit i'⁸')::v2014 ∧
           ¬(i'⁸' < 0) ∧
           (i'⁸' < 0 ∨
            ∃vs.
              v2014 = [] ∧ store_lookup lnum'⁶' s = SOME (Varray vs) ∧
              ¬(Num (ABS i'⁸') ≥ LENGTH vs) ∧
              (Num (ABS i'⁸') ≥ LENGTH vs ∨
               (s,t) = st' ∧ Rval vs❲Num (ABS i'⁸')❳ = v))) ∨
        (∃v2086 lnum'⁸' v'⁷' v2098 i'¹⁰'.
           op = Aupdate_unsafe ∧
           vs = Loc v2086 lnum'⁸'::Litv (IntLit i'¹⁰')::v'⁷'::v2098 ∧
           ¬(i'¹⁰' < 0) ∧
           (i'¹⁰' < 0 ∨
            ∃vs.
              v2098 = [] ∧ store_lookup lnum'⁸' s = SOME (Varray vs) ∧
              ¬(Num (ABS i'¹⁰') ≥ LENGTH vs) ∧
              (Num (ABS i'¹⁰') ≥ LENGTH vs ∨
               ∃s'.
                 store_assign lnum'⁸'
                   (Varray (LUPDATE v'⁷' (Num (ABS i'¹⁰')) vs)) s = SOME s' ∧
                 (s',t) = st' ∧ v = Rval (Conv NONE [])))) ∨
        (∃v2170 lnum'' v2178 i'.
           op = Aw8sub_unsafe ∧
           vs = Loc v2170 lnum''::Litv (IntLit i')::v2178 ∧ ¬(i' < 0) ∧
           (i' < 0 ∨
            ∃ws.
              v2178 = [] ∧ store_lookup lnum'' s = SOME (W8array ws) ∧
              ¬(Num (ABS i') ≥ LENGTH ws) ∧
              (Num (ABS i') ≥ LENGTH ws ∨
               (s,t) = st' ∧ Rval (Litv (Word8 ws❲Num (ABS i')❳)) = v))) ∨
        (∃v2250 lnum'⁴' v2262 w'⁴' i'³'.
           op = Aw8update_unsafe ∧
           vs =
           Loc v2250 lnum'⁴'::Litv (IntLit i'³')::Litv (Word8 w'⁴')::v2262 ∧
           ¬(i'³' < 0) ∧
           (i'³' < 0 ∨
            ∃ws.
              v2262 = [] ∧ store_lookup lnum'⁴' s = SOME (W8array ws) ∧
              ¬(Num (ABS i'³') ≥ LENGTH ws) ∧
              (Num (ABS i'³') ≥ LENGTH ws ∨
               ∃s'.
                 store_assign lnum'⁴'
                   (W8array (LUPDATE w'⁴' (Num (ABS i'³')) ws)) s = SOME s' ∧
                 (s',t) = st' ∧ v = Rval (Conv NONE [])))) ∨
        (∃th_op.
           op = ThunkOp th_op ∧ thunk_op (s,t) th_op vs = SOME (st',v)) ∨
        (∃x1 x2 xs ys.
           op = ListAppend ∧ vs = [x1; x2] ∧ v_to_list x1 = SOME xs ∧
           v_to_list x2 = SOME ys ∧ (s,t) = st' ∧
           Rval (list_to_v (xs ++ ys)) = v) ∨
        (∃j i'¹¹'.
           op = ConfigGC ∧ vs = [Litv (IntLit i'¹¹'); Litv (IntLit j)] ∧
           (s,t) = st' ∧ v = Rval (Conv NONE [])) ∨
        (∃n'⁶' v2482 lnum'⁹' conf ws.
           op = FFI n'⁶' ∧ vs = [Litv (StrLit conf); Loc v2482 lnum'⁹'] ∧
           store_lookup lnum'⁹' s = SOME (W8array ws) ∧
           (case
              call_FFI t (ExtCall n'⁶') (MAP (n2w ∘ ORD) (explode conf)) ws
            of
              FFI_return t' ws' =>
                (case store_assign lnum'⁹' (W8array ws') s of
                   NONE => NONE
                 | SOME s' => SOME ((s',t'),Rval (Conv NONE [])))
            | FFI_final outcome =>
              SOME ((s,t),Rerr (Rabort (Rffi_error outcome)))) =
           SOME (st',v)) ∨
        ∃v2533.
          op = Env_id ∧ vs = [v2533] ∧
          ((∃gen' id'.
              v2533 = Conv NONE [gen'; id'] ∧ (s,t) = st' ∧
              Rval (Conv NONE [gen'; id']) = v) ∨
           ∃env gen id.
             v2533 = Env env (gen,id) ∧ (s,t) = st' ∧
             Rval (Conv NONE [nat_to_v gen; nat_to_v id]) = v)
   
   [do_app_ffi_changed]  Theorem
      
      ⊢ do_app (st,ffi) op vs = SOME ((st',ffi'),res) ∧ ffi ≠ ffi' ⇒
        ∃s conf lnum ws ffi_st ws' b.
          op = FFI s ∧ vs = [Litv (StrLit conf); Loc b lnum] ∧
          store_lookup lnum st = SOME (W8array ws) ∧ s ≠ «» ∧
          ffi.oracle (ExtCall s) ffi.ffi_state
            (MAP (λc. n2w (ORD c)) (explode conf)) ws =
          Oracle_return ffi_st ws' ∧ LENGTH ws = LENGTH ws' ∧
          st' = LUPDATE (W8array ws') lnum st ∧ ffi'.oracle = ffi.oracle ∧
          ffi'.ffi_state = ffi_st ∧
          ffi'.io_events =
          ffi.io_events ++
          [IO_event (ExtCall s) (MAP (λc. n2w (ORD c)) (explode conf))
             (ZIP (ws,ws'))]
   
   [do_app_ffi_unchanged]  Theorem
      
      ⊢ ∀st ffi op vs st' ffi' res.
          (∀s. op ≠ FFI s) ∧ do_app (st,ffi) op vs = SOME ((st',ffi'),res) ⇒
          ffi = ffi'
   
   [do_app_not_timeout]  Theorem
      
      ⊢ do_app s op vs = SOME (s',Rerr (Rabort a)) ⇒ a ≠ Rtimeout_error
   
   [do_app_type_error]  Theorem
      
      ⊢ do_app s op es = SOME (x,Rerr (Rabort a)) ⇒ x = s
   
   [do_arith_check_type]  Theorem
      
      ⊢ do_arith a ty vs = SOME (INR res) ⇒ check_type ty res
   
   [do_con_check_build_conv]  Theorem
      
      ⊢ ∀tenvC cn vs l.
          do_con_check tenvC cn l ⇒ ∃v. build_conv tenvC cn vs = SOME v
   
   [do_conversion_check_type]  Theorem
      
      ⊢ do_conversion v ty1 ty2 = SOME (INR res) ⇒ check_type ty2 res
   
   [do_opapp_cases]  Theorem
      
      ⊢ ∀env' vs v.
          do_opapp vs = SOME (env',v) ⇔
          (∃v2 env'' n e.
             vs = [Closure env'' n e; v2] ∧
             env' = env'' with v := nsBind n v2 env''.v ∧ v = e) ∨
          ∃v2 env'' funs n' n'' e.
            vs = [Recclosure env'' funs n'; v2] ∧
            find_recfun n' funs = SOME (n'',e) ∧
            ALL_DISTINCT (MAP (λ(f,x,e). f) funs) ∧
            env' =
            env'' with
            v := nsBind n'' v2 (build_rec_env funs env'' env''.v) ∧ v = e
   
   [do_shift_def]  Theorem
      
      ⊢ do_shift sh n W8 (Word8 w') = SOME (Word8 (shift_lookup sh w' n)) ∧
        do_shift sh n W64 (Word64 w) = SOME (Word64 (shift_lookup sh w n)) ∧
        do_shift v0 v1 v2 (IntLit v9) = NONE ∧
        do_shift v0 v1 v2 (Char v10) = NONE ∧
        do_shift v0 v1 v2 (StrLit v11) = NONE ∧
        do_shift v0 v1 W64 (Word8 v12) = NONE ∧
        do_shift v0 v1 W8 (Word64 v13) = NONE ∧
        do_shift v0 v1 v2 (Float64 v14) = NONE
   
   [do_shift_ind]  Theorem
      
      ⊢ ∀P. (∀sh n w. P sh n W8 (Word8 w)) ∧
            (∀sh n w. P sh n W64 (Word64 w)) ∧
            (∀v0 v1 v2 v9. P v0 v1 v2 (IntLit v9)) ∧
            (∀v0 v1 v2 v10. P v0 v1 v2 (Char v10)) ∧
            (∀v0 v1 v2 v11. P v0 v1 v2 (StrLit v11)) ∧
            (∀v0 v1 v12. P v0 v1 W64 (Word8 v12)) ∧
            (∀v0 v1 v13. P v0 v1 W8 (Word64 v13)) ∧
            (∀v0 v1 v2 v14. P v0 v1 v2 (Float64 v14)) ⇒
            ∀v v1 v2 v3. P v v1 v2 v3
   
   [exc_rel_def]  Theorem
      
      ⊢ (exc_rel R (Rraise v1) (Rraise v2) ⇔ R v1 v2) ∧
        (exc_rel v0 (Rabort a1) (Rabort a2) ⇔ a1 = a2) ∧
        (exc_rel v3 (Rraise v9) (Rabort v14) ⇔ F) ∧
        (exc_rel v3 (Rabort v10) (Rraise v17) ⇔ F)
   
   [exc_rel_ind]  Theorem
      
      ⊢ ∀P. (∀R v1 v2. P R (Rraise v1) (Rraise v2)) ∧
            (∀v0 a1 a2. P v0 (Rabort a1) (Rabort a2)) ∧
            (∀v3 v9 v14. P v3 (Rraise v9) (Rabort v14)) ∧
            (∀v3 v10 v17. P v3 (Rabort v10) (Rraise v17)) ⇒
            ∀v v1 v2. P v v1 v2
   
   [exc_rel_raise1]  Theorem
      
      ⊢ exc_rel R (Rraise v) e ⇔ ∃v'. e = Rraise v' ∧ R v v'
   
   [exc_rel_raise2]  Theorem
      
      ⊢ exc_rel R e (Rraise v) ⇔ ∃v'. e = Rraise v' ∧ R v' v
   
   [exc_rel_refl]  Theorem
      
      ⊢ (∀x. R x x) ⇒ ∀x. exc_rel R x x
   
   [exc_rel_trans]  Theorem
      
      ⊢ (∀x y z. R x y ∧ R y z ⇒ R x z) ⇒
        ∀x y z. exc_rel R x y ∧ exc_rel R y z ⇒ exc_rel R x z
   
   [exc_rel_type_error1]  Theorem
      
      ⊢ exc_rel R (Rabort a) e ⇔ e = Rabort a
   
   [exc_rel_type_error2]  Theorem
      
      ⊢ exc_rel R e (Rabort a) ⇔ e = Rabort a
   
   [extend_dec_env_assoc]  Theorem
      
      ⊢ ∀env1 env2 env3. env1 +++ (env2 +++ env3) = env1 +++ env2 +++ env3
   
   [find_recfun_ALOOKUP]  Theorem
      
      ⊢ ∀funs n. find_recfun n funs = ALOOKUP funs n
   
   [find_recfun_el]  Theorem
      
      ⊢ ∀f funs x e n.
          ALL_DISTINCT (MAP (λ(f,x,e). f) funs) ∧ n < LENGTH funs ∧
          funs❲n❳ = (f,x,e) ⇒
          find_recfun f funs = SOME (x,e)
   
   [is_Refv_def]  Theorem
      
      ⊢ (is_Refv (Refv v0) ⇔ T) ∧ (is_Refv (W8array v2) ⇔ F) ∧
        (is_Refv (Varray v3) ⇔ F) ∧ (is_Refv (Thunk v4 v5) ⇔ F)
   
   [is_Refv_ind]  Theorem
      
      ⊢ ∀P. (∀v0. P (Refv v0)) ∧ (∀v2. P (W8array v2)) ∧
            (∀v3. P (Varray v3)) ∧ (∀v4 v5. P (Thunk v4 v5)) ⇒
            ∀v. P v
   
   [lit_same_type_refl]  Theorem
      
      ⊢ ∀l. lit_same_type l l
   
   [lit_same_type_sym]  Theorem
      
      ⊢ ∀l1 l2. lit_same_type l1 l2 ⇒ lit_same_type l2 l1
   
   [map_error_result_I]  Theorem
      
      ⊢ map_error_result I e = e
   
   [map_error_result_Rtype_error]  Theorem
      
      ⊢ map_error_result f e = Rabort a ⇔ e = Rabort a
   
   [map_match_def]  Theorem
      
      ⊢ map_match f (Match env) = Match (f env) ∧
        map_match f No_match = No_match ∧
        map_match f Match_type_error = Match_type_error
   
   [map_match_ind]  Theorem
      
      ⊢ ∀P. (∀f env. P f (Match env)) ∧ (∀f. P f No_match) ∧
            (∀f. P f Match_type_error) ⇒
            ∀v v1. P v v1
   
   [map_result_Rerr]  Theorem
      
      ⊢ map_result f1 f2 e = Rerr e' ⇔
        ∃a. e = Rerr a ∧ map_error_result f2 a = e'
   
   [map_result_Rval]  Theorem
      
      ⊢ map_result f1 f2 e = Rval x ⇔ ∃y. e = Rval y ∧ x = f1 y
   
   [map_sv_compose]  Theorem
      
      ⊢ map_sv f (map_sv g x) = map_sv (f ∘ g) x
   
   [nat_to_v_11]  Theorem
      
      ⊢ ∀i j. nat_to_v i = nat_to_v j ⇔ i = j
   
   [pat_bindings_accum]  Theorem
      
      ⊢ (∀p acc. pat_bindings p acc = pat_bindings p [] ++ acc) ∧
        ∀ps acc. pats_bindings ps acc = pats_bindings ps [] ++ acc
   
   [pmatch_acc]  Theorem
      
      ⊢ (∀envc store p v env env' env2.
           (pmatch envc store p v env = Match env' ⇔
            pmatch envc store p v (env ++ env2) = Match (env' ++ env2)) ∧
           (pmatch envc store p v env = No_match ⇔
            pmatch envc store p v (env ++ env2) = No_match) ∧
           (pmatch envc store p v env = Match_type_error ⇔
            pmatch envc store p v (env ++ env2) = Match_type_error)) ∧
        ∀envc store ps vs env env' env2.
          (pmatch_list envc store ps vs env = Match env' ⇔
           pmatch_list envc store ps vs (env ++ env2) =
           Match (env' ++ env2)) ∧
          (pmatch_list envc store ps vs env = No_match ⇔
           pmatch_list envc store ps vs (env ++ env2) = No_match) ∧
          (pmatch_list envc store ps vs env = Match_type_error ⇔
           pmatch_list envc store ps vs (env ++ env2) = Match_type_error)
   
   [pmatch_append]  Theorem
      
      ⊢ (∀cenv st p v env env' env''.
           pmatch cenv st p v env = Match env' ⇒
           pmatch cenv st p v (env ++ env'') = Match (env' ++ env'')) ∧
        ∀cenv st ps v env env' env''.
          pmatch_list cenv st ps v env = Match env' ⇒
          pmatch_list cenv st ps v (env ++ env'') = Match (env' ++ env'')
   
   [pmatch_extend]  Theorem
      
      ⊢ (∀cenv s p v env env' env''.
           pmatch cenv s p v env = Match env' ⇒
           ∃env''. env' = env'' ++ env ∧ MAP FST env'' = pat_bindings p []) ∧
        ∀cenv s ps vs env env' env''.
          pmatch_list cenv s ps vs env = Match env' ⇒
          ∃env''. env' = env'' ++ env ∧ MAP FST env'' = pats_bindings ps []
   
   [pmatch_nsAppend]  Theorem
      
      ⊢ (∀ns st pat v env m ns'.
           (pmatch ns st pat v env = No_match ⇒
            pmatch (nsAppend ns ns') st pat v env = No_match) ∧
           (pmatch ns st pat v env = Match m ⇒
            pmatch (nsAppend ns ns') st pat v env = Match m)) ∧
        ∀ns st pats vs env m ns'.
          (pmatch_list ns st pats vs env = No_match ⇒
           pmatch_list (nsAppend ns ns') st pats vs env = No_match) ∧
          (pmatch_list ns st pats vs env = Match m ⇒
           pmatch_list (nsAppend ns ns') st pats vs env = Match m)
   
   [pmatch_nsAppend_Match]  Theorem
      
      ⊢ ∀ns st pat v env m ns'.
          pmatch ns st pat v env = Match m ⇒
          pmatch (nsAppend ns ns') st pat v env = Match m
   
   [pmatch_nsAppend_No_match]  Theorem
      
      ⊢ ∀ns st pat v env m ns'.
          pmatch ns st pat v env = No_match ⇒
          pmatch (nsAppend ns ns') st pat v env = No_match
   
   [prim_type_cases]  Theorem
      
      ⊢ ∀ty.
          ty = BoolT ∨ ty = IntT ∨ ty = CharT ∨ ty = StrT ∨ ty = WordT W8 ∨
          ty = WordT W64 ∨ ty = Float64T
   
   [result_rel_Rerr1]  Theorem
      
      ⊢ result_rel R1 R2 (Rerr e) r ⇔ ∃e'. r = Rerr e' ∧ exc_rel R2 e e'
   
   [result_rel_Rerr2]  Theorem
      
      ⊢ result_rel R1 R2 r (Rerr e) ⇔ ∃e'. r = Rerr e' ∧ exc_rel R2 e' e
   
   [result_rel_Rval]  Theorem
      
      ⊢ result_rel R1 R2 (Rval v) r ⇔ ∃v'. r = Rval v' ∧ R1 v v'
   
   [result_rel_def]  Theorem
      
      ⊢ (result_rel R1 v0 (Rval v1) (Rval v2) ⇔ R1 v1 v2) ∧
        (result_rel v3 R2 (Rerr e1) (Rerr e2) ⇔ exc_rel R2 e1 e2) ∧
        (result_rel v4 v5 (Rval v13) (Rerr v18) ⇔ F) ∧
        (result_rel v4 v5 (Rerr v14) (Rval v21) ⇔ F)
   
   [result_rel_ind]  Theorem
      
      ⊢ ∀P. (∀R1 v0 v1 v2. P R1 v0 (Rval v1) (Rval v2)) ∧
            (∀v3 R2 e1 e2. P v3 R2 (Rerr e1) (Rerr e2)) ∧
            (∀v4 v5 v13 v18. P v4 v5 (Rval v13) (Rerr v18)) ∧
            (∀v4 v5 v14 v21. P v4 v5 (Rerr v14) (Rval v21)) ⇒
            ∀v v1 v2 v3. P v v1 v2 v3
   
   [result_rel_refl]  Theorem
      
      ⊢ (∀x. R1 x x) ∧ (∀x. R2 x x) ⇒ ∀x. result_rel R1 R2 x x
   
   [result_rel_trans]  Theorem
      
      ⊢ (∀x y z. R1 x y ∧ R1 y z ⇒ R1 x z) ∧
        (∀x y z. R2 x y ∧ R2 y z ⇒ R2 x z) ⇒
        ∀x y z.
          result_rel R1 R2 x y ∧ result_rel R1 R2 y z ⇒
          result_rel R1 R2 x z
   
   [sv_every_def]  Theorem
      
      ⊢ (sv_every P (Refv v) ⇔ P v) ∧
        (sv_every P (Varray vs) ⇔ EVERY P vs) ∧
        (sv_every P (Thunk m v) ⇔ P v) ∧ (sv_every P (W8array v4) ⇔ T)
   
   [sv_every_ind]  Theorem
      
      ⊢ ∀P'.
          (∀P v. P' P (Refv v)) ∧ (∀P vs. P' P (Varray vs)) ∧
          (∀P m v. P' P (Thunk m v)) ∧ (∀P v4. P' P (W8array v4)) ⇒
          ∀v v1. P' v v1
   
   [sv_rel_O]  Theorem
      
      ⊢ ∀R1 R2. sv_rel (R1 ∘ᵣ R2) = sv_rel R1 ∘ᵣ sv_rel R2
   
   [sv_rel_cases]  Theorem
      
      ⊢ ∀x y.
          sv_rel R x y ⇔
          (∃v1 v2. x = Refv v1 ∧ y = Refv v2 ∧ R v1 v2) ∨
          (∃w. x = W8array w ∧ y = W8array w) ∨
          (∃m v1 v2. x = Thunk m v1 ∧ y = Thunk m v2 ∧ R v1 v2) ∨
          ∃vs1 vs2. x = Varray vs1 ∧ y = Varray vs2 ∧ LIST_REL R vs1 vs2
   
   [sv_rel_def]  Theorem
      
      ⊢ (sv_rel R (Refv v1) (Refv v2) ⇔ R v1 v2) ∧
        (sv_rel R (W8array w1) (W8array w2) ⇔ w1 = w2) ∧
        (sv_rel R (Varray vs1) (Varray vs2) ⇔ LIST_REL R vs1 vs2) ∧
        (sv_rel R (Thunk m1 v1) (Thunk m2 v2) ⇔ m1 = m2 ∧ R v1 v2) ∧
        (sv_rel R (Refv v7) (W8array v18) ⇔ F) ∧
        (sv_rel R (Refv v7) (Varray v19) ⇔ F) ∧
        (sv_rel R (Refv v7) (Thunk v20 v21) ⇔ F) ∧
        (sv_rel R (W8array v8) (Refv v27) ⇔ F) ∧
        (sv_rel R (W8array v8) (Varray v29) ⇔ F) ∧
        (sv_rel R (W8array v8) (Thunk v30 v31) ⇔ F) ∧
        (sv_rel R (Varray v9) (Refv v37) ⇔ F) ∧
        (sv_rel R (Varray v9) (W8array v38) ⇔ F) ∧
        (sv_rel R (Varray v9) (Thunk v40 v41) ⇔ F) ∧
        (sv_rel R (Thunk v10 v11) (Refv v47) ⇔ F) ∧
        (sv_rel R (Thunk v10 v11) (W8array v48) ⇔ F) ∧
        (sv_rel R (Thunk v10 v11) (Varray v49) ⇔ F)
   
   [sv_rel_ind]  Theorem
      
      ⊢ ∀P. (∀R v1 v2. P R (Refv v1) (Refv v2)) ∧
            (∀R w1 w2. P R (W8array w1) (W8array w2)) ∧
            (∀R vs1 vs2. P R (Varray vs1) (Varray vs2)) ∧
            (∀R m1 v1 m2 v2. P R (Thunk m1 v1) (Thunk m2 v2)) ∧
            (∀R v7 v18. P R (Refv v7) (W8array v18)) ∧
            (∀R v7 v19. P R (Refv v7) (Varray v19)) ∧
            (∀R v7 v20 v21. P R (Refv v7) (Thunk v20 v21)) ∧
            (∀R v8 v27. P R (W8array v8) (Refv v27)) ∧
            (∀R v8 v29. P R (W8array v8) (Varray v29)) ∧
            (∀R v8 v30 v31. P R (W8array v8) (Thunk v30 v31)) ∧
            (∀R v9 v37. P R (Varray v9) (Refv v37)) ∧
            (∀R v9 v38. P R (Varray v9) (W8array v38)) ∧
            (∀R v9 v40 v41. P R (Varray v9) (Thunk v40 v41)) ∧
            (∀R v10 v11 v47. P R (Thunk v10 v11) (Refv v47)) ∧
            (∀R v10 v11 v48. P R (Thunk v10 v11) (W8array v48)) ∧
            (∀R v10 v11 v49. P R (Thunk v10 v11) (Varray v49)) ⇒
            ∀v v1 v2. P v v1 v2
   
   [sv_rel_mono]  Theorem
      
      ⊢ (∀x y. P x y ⇒ Q x y) ⇒ sv_rel P x y ⇒ sv_rel Q x y
   
   [sv_rel_refl]  Theorem
      
      ⊢ ∀R x. (∀x. R x x) ⇒ sv_rel R x x
   
   [sv_rel_trans]  Theorem
      
      ⊢ ∀R. (∀x y z. R x y ∧ R y z ⇒ R x z) ⇒
            ∀x y z. sv_rel R x y ∧ sv_rel R y z ⇒ sv_rel R x z
   
   [unchanged_env]  Theorem
      
      ⊢ ∀env. <|v := env.v; c := env.c|> = env
   
   [with_same_clock]  Theorem
      
      ⊢ st with clock := st.clock = st
   
   [with_same_v]  Theorem
      
      ⊢ env with v := env.v = env
   
   
*)
end
