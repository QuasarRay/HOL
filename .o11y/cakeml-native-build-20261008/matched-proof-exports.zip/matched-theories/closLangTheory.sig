signature closLangTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val assign_get_code_label_def_primitive : thm
    val block_op_TY_DEF : thm
    val block_op_case_def : thm
    val block_op_size_def : thm
    val const_TY_DEF : thm
    val const_case_def : thm
    val const_part_TY_DEF : thm
    val const_part_case_def : thm
    val const_part_size_def : thm
    val const_size_def : thm
    val exp_TY_DEF : thm
    val exp_case_def : thm
    val exp_size_def : thm
    val glob_op_TY_DEF : thm
    val glob_op_case_def : thm
    val glob_op_size_def : thm
    val has_install_def_UNION_extract0 : thm
    val has_install_def_UNION_extract1 : thm
    val has_install_def_UNION_primitive : thm
    val int_op_TY_DEF : thm
    val int_op_case_def : thm
    val int_op_size_def : thm
    val mem_op_TY_DEF : thm
    val mem_op_case_def : thm
    val mem_op_size_def : thm
    val op_TY_DEF : thm
    val op_case_def : thm
    val op_size_def : thm
    val pure_def_primitive : thm
    val pure_op_def : thm
    val word_op_TY_DEF : thm
    val word_op_case_def : thm
    val word_op_size_def : thm
  
  (*  Theorems  *)
    val assign_get_code_label_def : thm
    val assign_get_code_label_ind : thm
    val block_op_11 : thm
    val block_op_Axiom : thm
    val block_op_case_cong : thm
    val block_op_case_eq : thm
    val block_op_distinct : thm
    val block_op_induction : thm
    val block_op_nchotomy : thm
    val const_11 : thm
    val const_Axiom : thm
    val const_case_cong : thm
    val const_case_eq : thm
    val const_distinct : thm
    val const_induction : thm
    val const_nchotomy : thm
    val const_part_11 : thm
    val const_part_Axiom : thm
    val const_part_case_cong : thm
    val const_part_case_eq : thm
    val const_part_distinct : thm
    val const_part_induction : thm
    val const_part_nchotomy : thm
    val datatype_block_op : thm
    val datatype_const : thm
    val datatype_const_part : thm
    val datatype_exp : thm
    val datatype_glob_op : thm
    val datatype_int_op : thm
    val datatype_mem_op : thm
    val datatype_op : thm
    val datatype_word_op : thm
    val exp1_size_lemma : thm
    val exp_11 : thm
    val exp_Axiom : thm
    val exp_case_cong : thm
    val exp_case_eq : thm
    val exp_distinct : thm
    val exp_induction : thm
    val exp_nchotomy : thm
    val glob_op_11 : thm
    val glob_op_Axiom : thm
    val glob_op_case_cong : thm
    val glob_op_case_eq : thm
    val glob_op_distinct : thm
    val glob_op_induction : thm
    val glob_op_nchotomy : thm
    val has_install_def : thm
    val has_install_ind : thm
    val int_op_11 : thm
    val int_op_Axiom : thm
    val int_op_case_cong : thm
    val int_op_case_eq : thm
    val int_op_distinct : thm
    val int_op_induction : thm
    val int_op_nchotomy : thm
    val mem_op_11 : thm
    val mem_op_Axiom : thm
    val mem_op_case_cong : thm
    val mem_op_case_eq : thm
    val mem_op_distinct : thm
    val mem_op_induction : thm
    val mem_op_nchotomy : thm
    val op_11 : thm
    val op_Axiom : thm
    val op_case_cong : thm
    val op_case_eq : thm
    val op_distinct : thm
    val op_induction : thm
    val op_nchotomy : thm
    val pure_def : thm
    val pure_ind : thm
    val word_op_11 : thm
    val word_op_Axiom : thm
    val word_op_case_cong : thm
    val word_op_case_eq : thm
    val word_op_distinct : thm
    val word_op_induction : thm
    val word_op_nchotomy : thm
(*
   [backend_common] Parent theory of "closLang"
   
   [fpSem] Parent theory of "closLang"
   
   [assign_get_code_label_def_primitive]  Definition
      
      ⊢ assign_get_code_label =
        WFREC (@R. WF R)
          (λassign_get_code_label a.
               case a of
                 Label x => I {x}
               | FFI v9 => I ∅
               | IntOp v10 => I ∅
               | WordOp v11 => I ∅
               | BlockOp v12 => I ∅
               | GlobOp v13 => I ∅
               | MemOp v14 => I ∅
               | Install => I ∅
               | ThunkOp v15 => I ∅)
   
   [block_op_TY_DEF]  Definition
      
      ⊢ ∃rep.
          TYPE_DEFINITION
            (λa0'.
                 ∀ $var$('block_op').
                   (∀a0'.
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR 0 (a,ARB,ARB,ARB,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR (SUC 0)
                                  (a,ARB,ARB,ARB,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      (∃a0 a1.
                         a0' =
                         (λa0 a1.
                              ind_type$CONSTR (SUC (SUC 0))
                                (a0,a1,ARB,ARB,ARB,ARB)
                                (λn. ind_type$BOTTOM)) a0 a1) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR (SUC (SUC (SUC 0)))
                                  (a,ARB,ARB,ARB,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR (SUC (SUC (SUC (SUC 0))))
                                  (a,ARB,ARB,ARB,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      a0' =
                      ind_type$CONSTR (SUC (SUC (SUC (SUC (SUC 0)))))
                        (ARB,ARB,ARB,ARB,ARB,ARB) (λn. ind_type$BOTTOM) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR
                                  (SUC (SUC (SUC (SUC (SUC (SUC 0))))))
                                  (ARB,ARB,a,ARB,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      a0' =
                      ind_type$CONSTR
                        (SUC (SUC (SUC (SUC (SUC (SUC (SUC 0)))))))
                        (ARB,ARB,ARB,ARB,ARB,ARB) (λn. ind_type$BOTTOM) ∨
                      a0' =
                      ind_type$CONSTR
                        (SUC (SUC (SUC (SUC (SUC (SUC (SUC (SUC 0))))))))
                        (ARB,ARB,ARB,ARB,ARB,ARB) (λn. ind_type$BOTTOM) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR
                                  (SUC
                                     (SUC
                                        (SUC
                                           (SUC
                                              (SUC
                                                 (SUC (SUC (SUC (SUC 0)))))))))
                                  (a,ARB,ARB,ARB,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR
                                  (SUC
                                     (SUC
                                        (SUC
                                           (SUC
                                              (SUC
                                                 (SUC
                                                    (SUC
                                                       (SUC (SUC (SUC 0))))))))))
                                  (a,ARB,ARB,ARB,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      a0' =
                      ind_type$CONSTR
                        (SUC
                           (SUC
                              (SUC
                                 (SUC
                                    (SUC
                                       (SUC (SUC (SUC (SUC (SUC (SUC 0)))))))))))
                        (ARB,ARB,ARB,ARB,ARB,ARB) (λn. ind_type$BOTTOM) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR
                                  (SUC
                                     (SUC
                                        (SUC
                                           (SUC
                                              (SUC
                                                 (SUC
                                                    (SUC
                                                       (SUC
                                                          (SUC
                                                             (SUC
                                                                (SUC
                                                                   (SUC 0))))))))))))
                                  (ARB,ARB,ARB,a,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      a0' =
                      ind_type$CONSTR
                        (SUC
                           (SUC
                              (SUC
                                 (SUC
                                    (SUC
                                       (SUC
                                          (SUC
                                             (SUC
                                                (SUC
                                                   (SUC (SUC (SUC (SUC 0)))))))))))))
                        (ARB,ARB,ARB,ARB,ARB,ARB) (λn. ind_type$BOTTOM) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR
                                  (SUC
                                     (SUC
                                        (SUC
                                           (SUC
                                              (SUC
                                                 (SUC
                                                    (SUC
                                                       (SUC
                                                          (SUC
                                                             (SUC
                                                                (SUC
                                                                   (SUC
                                                                      (SUC
                                                                         (SUC
                                                                            0))))))))))))))
                                  (ARB,ARB,ARB,ARB,a,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR
                                  (SUC
                                     (SUC
                                        (SUC
                                           (SUC
                                              (SUC
                                                 (SUC
                                                    (SUC
                                                       (SUC
                                                          (SUC
                                                             (SUC
                                                                (SUC
                                                                   (SUC
                                                                      (SUC
                                                                         (SUC
                                                                            (SUC
                                                                               0)))))))))))))))
                                  (ARB,ARB,ARB,ARB,ARB,a)
                                  (λn. ind_type$BOTTOM)) a) ⇒
                      $var$('block_op') a0') ⇒
                   $var$('block_op') a0') rep
   
   [block_op_case_def]  Definition
      
      ⊢ (∀a f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10.
           block_op_CASE (Cons a) f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4
             f9 f10 = f a) ∧
        (∀a f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10.
           block_op_CASE (ElemAt a) f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4
             f9 f10 = f1 a) ∧
        (∀a0 a1 f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10.
           block_op_CASE (TagLenEq a0 a1) f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3
             f8 v4 f9 f10 = f2 a0 a1) ∧
        (∀a f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10.
           block_op_CASE (LenEq a) f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4
             f9 f10 = f3 a) ∧
        (∀a f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10.
           block_op_CASE (TagEq a) f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4
             f9 f10 = f4 a) ∧
        (∀f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10.
           block_op_CASE LengthBlock f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8
             v4 f9 f10 = v) ∧
        (∀a f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10.
           block_op_CASE (BoolTest a) f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8
             v4 f9 f10 = f5 a) ∧
        (∀f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10.
           block_op_CASE BoolNot f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9
             f10 = v1) ∧
        (∀f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10.
           block_op_CASE BoundsCheckBlock f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3
             f8 v4 f9 f10 = v2) ∧
        (∀a f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10.
           block_op_CASE (ConsExtend a) f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3
             f8 v4 f9 f10 = f6 a) ∧
        (∀a f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10.
           block_op_CASE (FromList a) f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8
             v4 f9 f10 = f7 a) ∧
        (∀f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10.
           block_op_CASE ListAppend f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4
             f9 f10 = v3) ∧
        (∀a f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10.
           block_op_CASE (Constant a) f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8
             v4 f9 f10 = f8 a) ∧
        (∀f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10.
           block_op_CASE Equal f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9
             f10 = v4) ∧
        (∀a f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10.
           block_op_CASE (EqualConst a) f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3
             f8 v4 f9 f10 = f9 a) ∧
        ∀a f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10.
          block_op_CASE (Build a) f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4
            f9 f10 = f10 a
   
   [block_op_size_def]  Definition
      
      ⊢ (∀a. block_op_size (Cons a) = 1 + a) ∧
        (∀a. block_op_size (ElemAt a) = 1 + a) ∧
        (∀a0 a1. block_op_size (TagLenEq a0 a1) = 1 + (a0 + a1)) ∧
        (∀a. block_op_size (LenEq a) = 1 + a) ∧
        (∀a. block_op_size (TagEq a) = 1 + a) ∧
        block_op_size LengthBlock = 0 ∧
        (∀a. block_op_size (BoolTest a) = 1 + test_size a) ∧
        block_op_size BoolNot = 0 ∧ block_op_size BoundsCheckBlock = 0 ∧
        (∀a. block_op_size (ConsExtend a) = 1 + a) ∧
        (∀a. block_op_size (FromList a) = 1 + a) ∧
        block_op_size ListAppend = 0 ∧
        (∀a. block_op_size (Constant a) = 1 + const_size a) ∧
        block_op_size Equal = 0 ∧
        (∀a. block_op_size (EqualConst a) = 1 + const_part_size a) ∧
        ∀a. block_op_size (Build a) = 1 + list_size const_part_size a
   
   [const_TY_DEF]  Definition
      
      ⊢ ∃rep.
          TYPE_DEFINITION
            (λa0'.
                 ∀ $var$('const') $var$('@temp@ind_typeclosLang0list').
                   (∀a0'.
                      (∃a0 a1.
                         a0' =
                         (λa0 a1.
                              ind_type$CONSTR 0 (a0,ARB,ARB,ARB)
                                (ind_type$FCONS a1 (λn. ind_type$BOTTOM)))
                           a0 a1 ∧ $var$('@temp@ind_typeclosLang0list') a1) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR (SUC 0) (ARB,a,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR (SUC (SUC 0))
                                  (ARB,ARB,a,ARB) (λn. ind_type$BOTTOM)) a) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR (SUC (SUC (SUC 0)))
                                  (ARB,ARB,ARB,a) (λn. ind_type$BOTTOM)) a) ⇒
                      $var$('const') a0') ∧
                   (∀a1'.
                      a1' =
                      ind_type$CONSTR (SUC (SUC (SUC (SUC 0))))
                        (ARB,ARB,ARB,ARB) (λn. ind_type$BOTTOM) ∨
                      (∃a0 a1.
                         a1' =
                         (λa0 a1.
                              ind_type$CONSTR
                                (SUC (SUC (SUC (SUC (SUC 0)))))
                                (ARB,ARB,ARB,ARB)
                                (ind_type$FCONS a0
                                   (ind_type$FCONS a1 (λn. ind_type$BOTTOM))))
                           a0 a1 ∧ $var$('const') a0 ∧
                         $var$('@temp@ind_typeclosLang0list') a1) ⇒
                      $var$('@temp@ind_typeclosLang0list') a1') ⇒
                   $var$('const') a0') rep
   
   [const_case_def]  Definition
      
      ⊢ (∀a0 a1 f f1 f2 f3.
           const_CASE (ConstCons a0 a1) f f1 f2 f3 = f a0 a1) ∧
        (∀a f f1 f2 f3. const_CASE (ConstInt a) f f1 f2 f3 = f1 a) ∧
        (∀a f f1 f2 f3. const_CASE (ConstStr a) f f1 f2 f3 = f2 a) ∧
        ∀a f f1 f2 f3. const_CASE (ConstWord64 a) f f1 f2 f3 = f3 a
   
   [const_part_TY_DEF]  Definition
      
      ⊢ ∃rep.
          TYPE_DEFINITION
            (λa0'.
                 ∀ $var$('const_part').
                   (∀a0'.
                      (∃a0 a1.
                         a0' =
                         (λa0 a1.
                              ind_type$CONSTR 0 (a0,a1,ARB,ARB,ARB)
                                (λn. ind_type$BOTTOM)) a0 a1) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR (SUC 0) (ARB,ARB,a,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR (SUC (SUC 0))
                                  (ARB,ARB,ARB,a,ARB) (λn. ind_type$BOTTOM))
                             a) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR (SUC (SUC (SUC 0)))
                                  (ARB,ARB,ARB,ARB,a) (λn. ind_type$BOTTOM))
                             a) ⇒
                      $var$('const_part') a0') ⇒
                   $var$('const_part') a0') rep
   
   [const_part_case_def]  Definition
      
      ⊢ (∀a0 a1 f f1 f2 f3.
           const_part_CASE (Con a0 a1) f f1 f2 f3 = f a0 a1) ∧
        (∀a f f1 f2 f3. const_part_CASE (Int a) f f1 f2 f3 = f1 a) ∧
        (∀a f f1 f2 f3. const_part_CASE (Str a) f f1 f2 f3 = f2 a) ∧
        ∀a f f1 f2 f3. const_part_CASE (W64 a) f f1 f2 f3 = f3 a
   
   [const_part_size_def]  Definition
      
      ⊢ (∀a0 a1.
           const_part_size (Con a0 a1) = 1 + (a0 + list_size (λx. x) a1)) ∧
        (∀a. const_part_size (Int a) = 1) ∧
        (∀a. const_part_size (Str a) = 1 + mlstring_size a) ∧
        ∀a. const_part_size (W64 a) = 1 + w2n a
   
   [const_size_def]  Definition
      
      ⊢ (∀a0 a1. const_size (ConstCons a0 a1) = 1 + (a0 + const1_size a1)) ∧
        (∀a. const_size (ConstInt a) = 1) ∧
        (∀a. const_size (ConstStr a) = 1 + mlstring_size a) ∧
        (∀a. const_size (ConstWord64 a) = 1 + w2n a) ∧ const1_size [] = 0 ∧
        ∀a0 a1. const1_size (a0::a1) = 1 + (const_size a0 + const1_size a1)
   
   [exp_TY_DEF]  Definition
      
      ⊢ ∃rep.
          TYPE_DEFINITION
            (λa0'.
                 ∀ $var$('exp') $var$('@temp@ind_typeclosLang100list')
                     $var$('@temp@ind_typeclosLang101prod')
                     $var$('@temp@ind_typeclosLang102list').
                   (∀a0'.
                      (∃a0 a1.
                         a0' =
                         (λa0 a1.
                              ind_type$CONSTR 0
                                (a0,a1,ARB,ARB,ARB,ARB,ARB,ARB)
                                (λn. ind_type$BOTTOM)) a0 a1) ∨
                      (∃a0 a1 a2 a3.
                         a0' =
                         (λa0 a1 a2 a3.
                              ind_type$CONSTR (SUC 0)
                                (a0,ARB,ARB,ARB,ARB,ARB,ARB,ARB)
                                (ind_type$FCONS a1
                                   (ind_type$FCONS a2
                                      (ind_type$FCONS a3
                                         (λn. ind_type$BOTTOM))))) a0 a1 a2
                           a3 ∧ $var$('exp') a1 ∧ $var$('exp') a2 ∧
                         $var$('exp') a3) ∨
                      (∃a0 a1 a2.
                         a0' =
                         (λa0 a1 a2.
                              ind_type$CONSTR (SUC (SUC 0))
                                (a0,ARB,ARB,ARB,ARB,ARB,ARB,ARB)
                                (ind_type$FCONS a1
                                   (ind_type$FCONS a2 (λn. ind_type$BOTTOM))))
                           a0 a1 a2 ∧
                         $var$('@temp@ind_typeclosLang102list') a1 ∧
                         $var$('exp') a2) ∨
                      (∃a0 a1.
                         a0' =
                         (λa0 a1.
                              ind_type$CONSTR (SUC (SUC (SUC 0)))
                                (a0,ARB,ARB,ARB,ARB,ARB,ARB,ARB)
                                (ind_type$FCONS a1 (λn. ind_type$BOTTOM)))
                           a0 a1 ∧ $var$('exp') a1) ∨
                      (∃a0 a1 a2.
                         a0' =
                         (λa0 a1 a2.
                              ind_type$CONSTR (SUC (SUC (SUC (SUC 0))))
                                (a0,ARB,ARB,ARB,ARB,ARB,ARB,ARB)
                                (ind_type$FCONS a1
                                   (ind_type$FCONS a2 (λn. ind_type$BOTTOM))))
                           a0 a1 a2 ∧ $var$('exp') a1 ∧ $var$('exp') a2) ∨
                      (∃a0 a1.
                         a0' =
                         (λa0 a1.
                              ind_type$CONSTR
                                (SUC (SUC (SUC (SUC (SUC 0)))))
                                (a0,ARB,ARB,ARB,ARB,ARB,ARB,ARB)
                                (ind_type$FCONS a1 (λn. ind_type$BOTTOM)))
                           a0 a1 ∧ $var$('exp') a1) ∨
                      (∃a0 a1 a2 a3.
                         a0' =
                         (λa0 a1 a2 a3.
                              ind_type$CONSTR
                                (SUC (SUC (SUC (SUC (SUC (SUC 0))))))
                                (a0,a1,a2,ARB,ARB,ARB,ARB,ARB)
                                (ind_type$FCONS a3 (λn. ind_type$BOTTOM)))
                           a0 a1 a2 a3 ∧
                         $var$('@temp@ind_typeclosLang102list') a3) ∨
                      (∃a0 a1 a2 a3.
                         a0' =
                         (λa0 a1 a2 a3.
                              ind_type$CONSTR
                                (SUC (SUC (SUC (SUC (SUC (SUC (SUC 0)))))))
                                (a0,ARB,ARB,a1,ARB,ARB,ARB,ARB)
                                (ind_type$FCONS a2
                                   (ind_type$FCONS a3 (λn. ind_type$BOTTOM))))
                           a0 a1 a2 a3 ∧ $var$('exp') a2 ∧
                         $var$('@temp@ind_typeclosLang102list') a3) ∨
                      (∃a0 a1 a2 a3 a4.
                         a0' =
                         (λa0 a1 a2 a3 a4.
                              ind_type$CONSTR
                                (SUC
                                   (SUC
                                      (SUC (SUC (SUC (SUC (SUC (SUC 0))))))))
                                (ARB,a3,ARB,a1,a0,a2,ARB,ARB)
                                (ind_type$FCONS a4 (λn. ind_type$BOTTOM)))
                           a0 a1 a2 a3 a4 ∧ $var$('exp') a4) ∨
                      (∃a0 a1 a2 a3 a4.
                         a0' =
                         (λa0 a1 a2 a3 a4.
                              ind_type$CONSTR
                                (SUC
                                   (SUC
                                      (SUC
                                         (SUC
                                            (SUC (SUC (SUC (SUC (SUC 0)))))))))
                                (ARB,ARB,ARB,a1,ARB,a2,a0,ARB)
                                (ind_type$FCONS a3
                                   (ind_type$FCONS a4 (λn. ind_type$BOTTOM))))
                           a0 a1 a2 a3 a4 ∧
                         $var$('@temp@ind_typeclosLang100list') a3 ∧
                         $var$('exp') a4) ∨
                      (∃a0 a1 a2.
                         a0' =
                         (λa0 a1 a2.
                              ind_type$CONSTR
                                (SUC
                                   (SUC
                                      (SUC
                                         (SUC
                                            (SUC
                                               (SUC
                                                  (SUC (SUC (SUC (SUC 0))))))))))
                                (a0,ARB,ARB,ARB,ARB,ARB,ARB,a1)
                                (ind_type$FCONS a2 (λn. ind_type$BOTTOM)))
                           a0 a1 a2 ∧
                         $var$('@temp@ind_typeclosLang102list') a2) ⇒
                      $var$('exp') a0') ∧
                   (∀a1'.
                      a1' =
                      ind_type$CONSTR
                        (SUC
                           (SUC
                              (SUC
                                 (SUC
                                    (SUC
                                       (SUC (SUC (SUC (SUC (SUC (SUC 0)))))))))))
                        (ARB,ARB,ARB,ARB,ARB,ARB,ARB,ARB)
                        (λn. ind_type$BOTTOM) ∨
                      (∃a0 a1.
                         a1' =
                         (λa0 a1.
                              ind_type$CONSTR
                                (SUC
                                   (SUC
                                      (SUC
                                         (SUC
                                            (SUC
                                               (SUC
                                                  (SUC
                                                     (SUC
                                                        (SUC
                                                           (SUC
                                                              (SUC (SUC 0))))))))))))
                                (ARB,ARB,ARB,ARB,ARB,ARB,ARB,ARB)
                                (ind_type$FCONS a0
                                   (ind_type$FCONS a1 (λn. ind_type$BOTTOM))))
                           a0 a1 ∧
                         $var$('@temp@ind_typeclosLang101prod') a0 ∧
                         $var$('@temp@ind_typeclosLang100list') a1) ⇒
                      $var$('@temp@ind_typeclosLang100list') a1') ∧
                   (∀a2'.
                      (∃a0 a1.
                         a2' =
                         (λa0 a1.
                              ind_type$CONSTR
                                (SUC
                                   (SUC
                                      (SUC
                                         (SUC
                                            (SUC
                                               (SUC
                                                  (SUC
                                                     (SUC
                                                        (SUC
                                                           (SUC
                                                              (SUC
                                                                 (SUC
                                                                    (SUC 0)))))))))))))
                                (ARB,a0,ARB,ARB,ARB,ARB,ARB,ARB)
                                (ind_type$FCONS a1 (λn. ind_type$BOTTOM)))
                           a0 a1 ∧ $var$('exp') a1) ⇒
                      $var$('@temp@ind_typeclosLang101prod') a2') ∧
                   (∀a3'.
                      a3' =
                      ind_type$CONSTR
                        (SUC
                           (SUC
                              (SUC
                                 (SUC
                                    (SUC
                                       (SUC
                                          (SUC
                                             (SUC
                                                (SUC
                                                   (SUC
                                                      (SUC
                                                         (SUC (SUC (SUC 0))))))))))))))
                        (ARB,ARB,ARB,ARB,ARB,ARB,ARB,ARB)
                        (λn. ind_type$BOTTOM) ∨
                      (∃a0 a1.
                         a3' =
                         (λa0 a1.
                              ind_type$CONSTR
                                (SUC
                                   (SUC
                                      (SUC
                                         (SUC
                                            (SUC
                                               (SUC
                                                  (SUC
                                                     (SUC
                                                        (SUC
                                                           (SUC
                                                              (SUC
                                                                 (SUC
                                                                    (SUC
                                                                       (SUC
                                                                          (SUC
                                                                             0)))))))))))))))
                                (ARB,ARB,ARB,ARB,ARB,ARB,ARB,ARB)
                                (ind_type$FCONS a0
                                   (ind_type$FCONS a1 (λn. ind_type$BOTTOM))))
                           a0 a1 ∧ $var$('exp') a0 ∧
                         $var$('@temp@ind_typeclosLang102list') a1) ⇒
                      $var$('@temp@ind_typeclosLang102list') a3') ⇒
                   $var$('exp') a0') rep
   
   [exp_case_def]  Definition
      
      ⊢ (∀a0 a1 f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10.
           exp_CASE (Var a0 a1) f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 = f a0 a1) ∧
        (∀a0 a1 a2 a3 f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10.
           exp_CASE (If a0 a1 a2 a3) f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 =
           f1 a0 a1 a2 a3) ∧
        (∀a0 a1 a2 f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10.
           exp_CASE (Let a0 a1 a2) f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 =
           f2 a0 a1 a2) ∧
        (∀a0 a1 f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10.
           exp_CASE (Raise a0 a1) f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 =
           f3 a0 a1) ∧
        (∀a0 a1 a2 f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10.
           exp_CASE (Handle a0 a1 a2) f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 =
           f4 a0 a1 a2) ∧
        (∀a0 a1 f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10.
           exp_CASE (Tick a0 a1) f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 =
           f5 a0 a1) ∧
        (∀a0 a1 a2 a3 f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10.
           exp_CASE (Call a0 a1 a2 a3) f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 =
           f6 a0 a1 a2 a3) ∧
        (∀a0 a1 a2 a3 f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10.
           exp_CASE (App a0 a1 a2 a3) f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 =
           f7 a0 a1 a2 a3) ∧
        (∀a0 a1 a2 a3 a4 f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10.
           exp_CASE (Fn a0 a1 a2 a3 a4) f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 =
           f8 a0 a1 a2 a3 a4) ∧
        (∀a0 a1 a2 a3 a4 f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10.
           exp_CASE (Letrec a0 a1 a2 a3 a4) f f1 f2 f3 f4 f5 f6 f7 f8 f9
             f10 = f9 a0 a1 a2 a3 a4) ∧
        ∀a0 a1 a2 f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10.
          exp_CASE (Op a0 a1 a2) f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 =
          f10 a0 a1 a2
   
   [exp_size_def]  Definition
      
      ⊢ (∀a0 a1. exp_size (Var a0 a1) = 1 + (tra_size a0 + a1)) ∧
        (∀a0 a1 a2 a3.
           exp_size (If a0 a1 a2 a3) =
           1 + (tra_size a0 + (exp_size a1 + (exp_size a2 + exp_size a3)))) ∧
        (∀a0 a1 a2.
           exp_size (Let a0 a1 a2) =
           1 + (tra_size a0 + (exp3_size a1 + exp_size a2))) ∧
        (∀a0 a1. exp_size (Raise a0 a1) = 1 + (tra_size a0 + exp_size a1)) ∧
        (∀a0 a1 a2.
           exp_size (Handle a0 a1 a2) =
           1 + (tra_size a0 + (exp_size a1 + exp_size a2))) ∧
        (∀a0 a1. exp_size (Tick a0 a1) = 1 + (tra_size a0 + exp_size a1)) ∧
        (∀a0 a1 a2 a3.
           exp_size (Call a0 a1 a2 a3) =
           1 + (tra_size a0 + (a1 + (a2 + exp3_size a3)))) ∧
        (∀a0 a1 a2 a3.
           exp_size (App a0 a1 a2 a3) =
           1 +
           (tra_size a0 +
            (option_size (λx. x) a1 + (exp_size a2 + exp3_size a3)))) ∧
        (∀a0 a1 a2 a3 a4.
           exp_size (Fn a0 a1 a2 a3 a4) =
           1 +
           (mlstring_size a0 +
            (option_size (λx. x) a1 +
             (option_size (list_size (λx. x)) a2 + (a3 + exp_size a4))))) ∧
        (∀a0 a1 a2 a3 a4.
           exp_size (Letrec a0 a1 a2 a3 a4) =
           1 +
           (list_size mlstring_size a0 +
            (option_size (λx. x) a1 +
             (option_size (list_size (λx. x)) a2 +
              (exp1_size a3 + exp_size a4))))) ∧
        (∀a0 a1 a2.
           exp_size (Op a0 a1 a2) =
           1 + (tra_size a0 + (op_size a1 + exp3_size a2))) ∧
        exp1_size [] = 0 ∧
        (∀a0 a1. exp1_size (a0::a1) = 1 + (exp2_size a0 + exp1_size a1)) ∧
        (∀a0 a1. exp2_size (a0,a1) = 1 + (a0 + exp_size a1)) ∧
        exp3_size [] = 0 ∧
        ∀a0 a1. exp3_size (a0::a1) = 1 + (exp_size a0 + exp3_size a1)
   
   [glob_op_TY_DEF]  Definition
      
      ⊢ ∃rep.
          TYPE_DEFINITION
            (λa0.
                 ∀ $var$('glob_op').
                   (∀a0.
                      (∃a. a0 =
                           (λa. ind_type$CONSTR 0 a (λn. ind_type$BOTTOM))
                             a) ∨
                      (∃a. a0 =
                           (λa.
                                ind_type$CONSTR (SUC 0) a
                                  (λn. ind_type$BOTTOM)) a) ∨
                      a0 =
                      ind_type$CONSTR (SUC (SUC 0)) ARB
                        (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR (SUC (SUC (SUC 0))) ARB
                        (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR (SUC (SUC (SUC (SUC 0)))) ARB
                        (λn. ind_type$BOTTOM) ⇒
                      $var$('glob_op') a0) ⇒
                   $var$('glob_op') a0) rep
   
   [glob_op_case_def]  Definition
      
      ⊢ (∀a f f1 v v1 v2. glob_op_CASE (Global a) f f1 v v1 v2 = f a) ∧
        (∀a f f1 v v1 v2. glob_op_CASE (SetGlobal a) f f1 v v1 v2 = f1 a) ∧
        (∀f f1 v v1 v2. glob_op_CASE AllocGlobal f f1 v v1 v2 = v) ∧
        (∀f f1 v v1 v2. glob_op_CASE GlobalsPtr f f1 v v1 v2 = v1) ∧
        ∀f f1 v v1 v2. glob_op_CASE SetGlobalsPtr f f1 v v1 v2 = v2
   
   [glob_op_size_def]  Definition
      
      ⊢ (∀a. glob_op_size (Global a) = 1 + a) ∧
        (∀a. glob_op_size (SetGlobal a) = 1 + a) ∧
        glob_op_size AllocGlobal = 0 ∧ glob_op_size GlobalsPtr = 0 ∧
        glob_op_size SetGlobalsPtr = 0
   
   [has_install_def_UNION_extract0]  Definition
      
      ⊢ ∀x. has_install x ⇔ has_install_def_UNION (INL x)
   
   [has_install_def_UNION_extract1]  Definition
      
      ⊢ ∀x. has_install_list x ⇔ has_install_def_UNION (INR x)
   
   [has_install_def_UNION_primitive]  Definition
      
      ⊢ has_install_def_UNION =
        WFREC
          (@R. WF R ∧ (∀e2 e1 t e3. R (INL e3) (INL (If t e1 e2 e3))) ∧
               (∀e3 e1 t e2. R (INL e2) (INL (If t e1 e2 e3))) ∧
               (∀e3 e2 t e1. R (INL e1) (INL (If t e1 e2 e3))) ∧
               (∀e t es. R (INR es) (INL (Let t es e))) ∧
               (∀es t e. R (INL e) (INL (Let t es e))) ∧
               (∀p t es. R (INR es) (INL (Op t p es))) ∧
               (∀t e. R (INL e) (INL (Raise t e))) ∧
               (∀t e. R (INL e) (INL (Tick t e))) ∧
               (∀v3 v2 v1 v0 e. R (INL e) (INL (Fn v0 v1 v2 v3 e))) ∧
               (∀e1 t e2. R (INL e2) (INL (Handle t e1 e2))) ∧
               (∀e2 t e1. R (INL e1) (INL (Handle t e1 e2))) ∧
               (∀v6 v5 v4 es. R (INR es) (INL (Call v4 v5 v6 es))) ∧
               (∀e v8 v7 es. R (INR es) (INL (App v7 v8 e es))) ∧
               (∀es v8 v7 e. R (INL e) (INL (App v7 v8 e es))) ∧
               (∀e v11 v10 v9 fns.
                  R (INR (MAP SND fns)) (INL (Letrec v9 v10 v11 fns e))) ∧
               (∀fns v11 v10 v9 e.
                  R (INL e) (INL (Letrec v9 v10 v11 fns e))) ∧
               (∀xs x. R (INL x) (INR (x::xs))) ∧
               ∀x xs. R (INR xs) (INR (x::xs)))
          (λhas_install_def_UNION a.
               case a of
                 INL (Var t n) => I F
               | INL (If t' e1 e2 e3) =>
                 I
                   (has_install_def_UNION (INL e1) ∨
                    has_install_def_UNION (INL e2) ∨
                    has_install_def_UNION (INL e3))
               | INL (Let t'' es e) =>
                 I
                   (has_install_def_UNION (INL e) ∨
                    has_install_def_UNION (INR es))
               | INL (Raise t'⁴' e') => I (has_install_def_UNION (INL e'))
               | INL (Handle t'⁶' e1' e2') =>
                 I
                   (has_install_def_UNION (INL e1') ∨
                    has_install_def_UNION (INL e2'))
               | INL (Tick t'⁵' e'') => I (has_install_def_UNION (INL e''))
               | INL (Call v4 v5 v6 es'') =>
                 I (has_install_def_UNION (INR es''))
               | INL (App v7 v8 e'⁴' es'³') =>
                 I
                   (has_install_def_UNION (INL e'⁴') ∨
                    has_install_def_UNION (INR es'³'))
               | INL (Fn v0 v1 v2 v3 e'³') =>
                 I (has_install_def_UNION (INL e'³'))
               | INL (Letrec v9 v10 v11 fns e'⁵') =>
                 I
                   (has_install_def_UNION (INR (MAP SND fns)) ∨
                    has_install_def_UNION (INL e'⁵'))
               | INL (Op t'³' p es') =>
                 I (p = Install ∨ has_install_def_UNION (INR es'))
               | INR [] => I F
               | INR (x::xs) =>
                 I
                   (has_install_def_UNION (INL x) ∨
                    has_install_def_UNION (INR xs)))
   
   [int_op_TY_DEF]  Definition
      
      ⊢ ∃rep.
          TYPE_DEFINITION
            (λa0.
                 ∀ $var$('int_op').
                   (∀a0.
                      (∃a. a0 =
                           (λa.
                                ind_type$CONSTR 0 (a,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      a0 =
                      ind_type$CONSTR (SUC 0) (ARB,ARB)
                        (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR (SUC (SUC 0)) (ARB,ARB)
                        (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR (SUC (SUC (SUC 0))) (ARB,ARB)
                        (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR (SUC (SUC (SUC (SUC 0)))) (ARB,ARB)
                        (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR (SUC (SUC (SUC (SUC (SUC 0)))))
                        (ARB,ARB) (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR (SUC (SUC (SUC (SUC (SUC (SUC 0))))))
                        (ARB,ARB) (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR
                        (SUC (SUC (SUC (SUC (SUC (SUC (SUC 0)))))))
                        (ARB,ARB) (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR
                        (SUC (SUC (SUC (SUC (SUC (SUC (SUC (SUC 0))))))))
                        (ARB,ARB) (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR
                        (SUC
                           (SUC (SUC (SUC (SUC (SUC (SUC (SUC (SUC 0)))))))))
                        (ARB,ARB) (λn. ind_type$BOTTOM) ∨
                      (∃a. a0 =
                           (λa.
                                ind_type$CONSTR
                                  (SUC
                                     (SUC
                                        (SUC
                                           (SUC
                                              (SUC
                                                 (SUC
                                                    (SUC
                                                       (SUC (SUC (SUC 0))))))))))
                                  (ARB,a) (λn. ind_type$BOTTOM)) a) ⇒
                      $var$('int_op') a0) ⇒
                   $var$('int_op') a0) rep
   
   [int_op_case_def]  Definition
      
      ⊢ (∀a f v v1 v2 v3 v4 v5 v6 v7 v8 f1.
           int_op_CASE (Const a) f v v1 v2 v3 v4 v5 v6 v7 v8 f1 = f a) ∧
        (∀f v v1 v2 v3 v4 v5 v6 v7 v8 f1.
           int_op_CASE Add f v v1 v2 v3 v4 v5 v6 v7 v8 f1 = v) ∧
        (∀f v v1 v2 v3 v4 v5 v6 v7 v8 f1.
           int_op_CASE Sub f v v1 v2 v3 v4 v5 v6 v7 v8 f1 = v1) ∧
        (∀f v v1 v2 v3 v4 v5 v6 v7 v8 f1.
           int_op_CASE Mult f v v1 v2 v3 v4 v5 v6 v7 v8 f1 = v2) ∧
        (∀f v v1 v2 v3 v4 v5 v6 v7 v8 f1.
           int_op_CASE Div f v v1 v2 v3 v4 v5 v6 v7 v8 f1 = v3) ∧
        (∀f v v1 v2 v3 v4 v5 v6 v7 v8 f1.
           int_op_CASE Mod f v v1 v2 v3 v4 v5 v6 v7 v8 f1 = v4) ∧
        (∀f v v1 v2 v3 v4 v5 v6 v7 v8 f1.
           int_op_CASE Less f v v1 v2 v3 v4 v5 v6 v7 v8 f1 = v5) ∧
        (∀f v v1 v2 v3 v4 v5 v6 v7 v8 f1.
           int_op_CASE LessEq f v v1 v2 v3 v4 v5 v6 v7 v8 f1 = v6) ∧
        (∀f v v1 v2 v3 v4 v5 v6 v7 v8 f1.
           int_op_CASE Greater f v v1 v2 v3 v4 v5 v6 v7 v8 f1 = v7) ∧
        (∀f v v1 v2 v3 v4 v5 v6 v7 v8 f1.
           int_op_CASE GreaterEq f v v1 v2 v3 v4 v5 v6 v7 v8 f1 = v8) ∧
        ∀a f v v1 v2 v3 v4 v5 v6 v7 v8 f1.
          int_op_CASE (LessConstSmall a) f v v1 v2 v3 v4 v5 v6 v7 v8 f1 =
          f1 a
   
   [int_op_size_def]  Definition
      
      ⊢ (∀a. int_op_size (Const a) = 1) ∧ int_op_size Add = 0 ∧
        int_op_size Sub = 0 ∧ int_op_size Mult = 0 ∧ int_op_size Div = 0 ∧
        int_op_size Mod = 0 ∧ int_op_size Less = 0 ∧
        int_op_size LessEq = 0 ∧ int_op_size Greater = 0 ∧
        int_op_size GreaterEq = 0 ∧
        ∀a. int_op_size (LessConstSmall a) = 1 + a
   
   [mem_op_TY_DEF]  Definition
      
      ⊢ ∃rep.
          TYPE_DEFINITION
            (λa0.
                 ∀ $var$('mem_op').
                   (∀a0.
                      a0 = ind_type$CONSTR 0 ARB (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR (SUC 0) ARB (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR (SUC (SUC 0)) ARB
                        (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR (SUC (SUC (SUC 0))) ARB
                        (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR (SUC (SUC (SUC (SUC 0)))) ARB
                        (λn. ind_type$BOTTOM) ∨
                      (∃a. a0 =
                           (λa.
                                ind_type$CONSTR
                                  (SUC (SUC (SUC (SUC (SUC 0))))) a
                                  (λn. ind_type$BOTTOM)) a) ∨
                      a0 =
                      ind_type$CONSTR (SUC (SUC (SUC (SUC (SUC (SUC 0))))))
                        ARB (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR
                        (SUC (SUC (SUC (SUC (SUC (SUC (SUC 0))))))) ARB
                        (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR
                        (SUC (SUC (SUC (SUC (SUC (SUC (SUC (SUC 0))))))))
                        ARB (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR
                        (SUC
                           (SUC (SUC (SUC (SUC (SUC (SUC (SUC (SUC 0)))))))))
                        ARB (λn. ind_type$BOTTOM) ∨
                      (∃a. a0 =
                           (λa.
                                ind_type$CONSTR
                                  (SUC
                                     (SUC
                                        (SUC
                                           (SUC
                                              (SUC
                                                 (SUC
                                                    (SUC
                                                       (SUC (SUC (SUC 0))))))))))
                                  a (λn. ind_type$BOTTOM)) a) ∨
                      a0 =
                      ind_type$CONSTR
                        (SUC
                           (SUC
                              (SUC
                                 (SUC
                                    (SUC
                                       (SUC (SUC (SUC (SUC (SUC (SUC 0)))))))))))
                        ARB (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR
                        (SUC
                           (SUC
                              (SUC
                                 (SUC
                                    (SUC
                                       (SUC
                                          (SUC
                                             (SUC (SUC (SUC (SUC (SUC 0))))))))))))
                        ARB (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR
                        (SUC
                           (SUC
                              (SUC
                                 (SUC
                                    (SUC
                                       (SUC
                                          (SUC
                                             (SUC
                                                (SUC
                                                   (SUC (SUC (SUC (SUC 0)))))))))))))
                        ARB (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR
                        (SUC
                           (SUC
                              (SUC
                                 (SUC
                                    (SUC
                                       (SUC
                                          (SUC
                                             (SUC
                                                (SUC
                                                   (SUC
                                                      (SUC
                                                         (SUC (SUC (SUC 0))))))))))))))
                        ARB (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR
                        (SUC
                           (SUC
                              (SUC
                                 (SUC
                                    (SUC
                                       (SUC
                                          (SUC
                                             (SUC
                                                (SUC
                                                   (SUC
                                                      (SUC
                                                         (SUC
                                                            (SUC
                                                               (SUC (SUC 0)))))))))))))))
                        ARB (λn. ind_type$BOTTOM) ∨
                      a0 =
                      ind_type$CONSTR
                        (SUC
                           (SUC
                              (SUC
                                 (SUC
                                    (SUC
                                       (SUC
                                          (SUC
                                             (SUC
                                                (SUC
                                                   (SUC
                                                      (SUC
                                                         (SUC
                                                            (SUC
                                                               (SUC
                                                                  (SUC
                                                                     (SUC 0))))))))))))))))
                        ARB (λn. ind_type$BOTTOM) ∨
                      (∃a. a0 =
                           (λa.
                                ind_type$CONSTR
                                  (SUC
                                     (SUC
                                        (SUC
                                           (SUC
                                              (SUC
                                                 (SUC
                                                    (SUC
                                                       (SUC
                                                          (SUC
                                                             (SUC
                                                                (SUC
                                                                   (SUC
                                                                      (SUC
                                                                         (SUC
                                                                            (SUC
                                                                               (SUC
                                                                                  (SUC
                                                                                     0)))))))))))))))))
                                  a (λn. ind_type$BOTTOM)) a) ∨
                      a0 =
                      ind_type$CONSTR
                        (SUC
                           (SUC
                              (SUC
                                 (SUC
                                    (SUC
                                       (SUC
                                          (SUC
                                             (SUC
                                                (SUC
                                                   (SUC
                                                      (SUC
                                                         (SUC
                                                            (SUC
                                                               (SUC
                                                                  (SUC
                                                                     (SUC
                                                                        (SUC
                                                                           (SUC
                                                                              0))))))))))))))))))
                        ARB (λn. ind_type$BOTTOM) ⇒
                      $var$('mem_op') a0) ⇒
                   $var$('mem_op') a0) rep
   
   [mem_op_case_def]  Definition
      
      ⊢ (∀v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
           mem_op_CASE Ref v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12
             v13 v14 f2 v15 = v) ∧
        (∀v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
           mem_op_CASE Update v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12
             v13 v14 f2 v15 = v1) ∧
        (∀v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
           mem_op_CASE El v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13
             v14 f2 v15 = v2) ∧
        (∀v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
           mem_op_CASE Length v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12
             v13 v14 f2 v15 = v3) ∧
        (∀v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
           mem_op_CASE LengthByte v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11
             v12 v13 v14 f2 v15 = v4) ∧
        (∀a v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
           mem_op_CASE (RefByte a) v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10
             v11 v12 v13 v14 f2 v15 = f a) ∧
        (∀v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
           mem_op_CASE RefArray v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11
             v12 v13 v14 f2 v15 = v5) ∧
        (∀v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
           mem_op_CASE DerefByte v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11
             v12 v13 v14 f2 v15 = v6) ∧
        (∀v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
           mem_op_CASE UpdateByte v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11
             v12 v13 v14 f2 v15 = v7) ∧
        (∀v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
           mem_op_CASE ConcatByteVec v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10
             v11 v12 v13 v14 f2 v15 = v8) ∧
        (∀a v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
           mem_op_CASE (CopyByte a) v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10
             v11 v12 v13 v14 f2 v15 = f1 a) ∧
        (∀v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
           mem_op_CASE FromListByte v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10
             v11 v12 v13 v14 f2 v15 = v9) ∧
        (∀v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
           mem_op_CASE ToListByte v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11
             v12 v13 v14 f2 v15 = v10) ∧
        (∀v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
           mem_op_CASE LengthByteVec v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10
             v11 v12 v13 v14 f2 v15 = v11) ∧
        (∀v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
           mem_op_CASE DerefByteVec v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10
             v11 v12 v13 v14 f2 v15 = v12) ∧
        (∀v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
           mem_op_CASE XorByte v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11
             v12 v13 v14 f2 v15 = v13) ∧
        (∀v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
           mem_op_CASE BoundsCheckArray v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9
             v10 v11 v12 v13 v14 f2 v15 = v14) ∧
        (∀a v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
           mem_op_CASE (BoundsCheckByte a) v v1 v2 v3 v4 f v5 v6 v7 v8 f1
             v9 v10 v11 v12 v13 v14 f2 v15 = f2 a) ∧
        ∀v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
          mem_op_CASE ConfigGC v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11
            v12 v13 v14 f2 v15 = v15
   
   [mem_op_size_def]  Definition
      
      ⊢ mem_op_size Ref = 0 ∧ mem_op_size Update = 0 ∧ mem_op_size El = 0 ∧
        mem_op_size Length = 0 ∧ mem_op_size LengthByte = 0 ∧
        (∀a. mem_op_size (RefByte a) = 1 + bool_size a) ∧
        mem_op_size RefArray = 0 ∧ mem_op_size DerefByte = 0 ∧
        mem_op_size UpdateByte = 0 ∧ mem_op_size ConcatByteVec = 0 ∧
        (∀a. mem_op_size (CopyByte a) = 1 + bool_size a) ∧
        mem_op_size FromListByte = 0 ∧ mem_op_size ToListByte = 0 ∧
        mem_op_size LengthByteVec = 0 ∧ mem_op_size DerefByteVec = 0 ∧
        mem_op_size XorByte = 0 ∧ mem_op_size BoundsCheckArray = 0 ∧
        (∀a. mem_op_size (BoundsCheckByte a) = 1 + bool_size a) ∧
        mem_op_size ConfigGC = 0
   
   [op_TY_DEF]  Definition
      
      ⊢ ∃rep.
          TYPE_DEFINITION
            (λa0.
                 ∀ $var$('op').
                   (∀a0.
                      (∃a. a0 =
                           (λa.
                                ind_type$CONSTR 0
                                  (a,ARB,ARB,ARB,ARB,ARB,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      (∃a. a0 =
                           (λa.
                                ind_type$CONSTR (SUC 0)
                                  (ARB,a,ARB,ARB,ARB,ARB,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      (∃a. a0 =
                           (λa.
                                ind_type$CONSTR (SUC (SUC 0))
                                  (ARB,ARB,a,ARB,ARB,ARB,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      (∃a. a0 =
                           (λa.
                                ind_type$CONSTR (SUC (SUC (SUC 0)))
                                  (ARB,ARB,ARB,a,ARB,ARB,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      (∃a. a0 =
                           (λa.
                                ind_type$CONSTR (SUC (SUC (SUC (SUC 0))))
                                  (ARB,ARB,ARB,ARB,a,ARB,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      (∃a. a0 =
                           (λa.
                                ind_type$CONSTR
                                  (SUC (SUC (SUC (SUC (SUC 0)))))
                                  (ARB,ARB,ARB,ARB,ARB,a,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      (∃a. a0 =
                           (λa.
                                ind_type$CONSTR
                                  (SUC (SUC (SUC (SUC (SUC (SUC 0))))))
                                  (ARB,ARB,ARB,ARB,ARB,ARB,a,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      a0 =
                      ind_type$CONSTR
                        (SUC (SUC (SUC (SUC (SUC (SUC (SUC 0)))))))
                        (ARB,ARB,ARB,ARB,ARB,ARB,ARB,ARB)
                        (λn. ind_type$BOTTOM) ∨
                      (∃a. a0 =
                           (λa.
                                ind_type$CONSTR
                                  (SUC
                                     (SUC
                                        (SUC
                                           (SUC (SUC (SUC (SUC (SUC 0))))))))
                                  (ARB,ARB,ARB,ARB,ARB,ARB,ARB,a)
                                  (λn. ind_type$BOTTOM)) a) ⇒
                      $var$('op') a0) ⇒
                   $var$('op') a0) rep
   
   [op_case_def]  Definition
      
      ⊢ (∀a f f1 f2 f3 f4 f5 f6 v f7.
           op_CASE (Label a) f f1 f2 f3 f4 f5 f6 v f7 = f a) ∧
        (∀a f f1 f2 f3 f4 f5 f6 v f7.
           op_CASE (FFI a) f f1 f2 f3 f4 f5 f6 v f7 = f1 a) ∧
        (∀a f f1 f2 f3 f4 f5 f6 v f7.
           op_CASE (IntOp a) f f1 f2 f3 f4 f5 f6 v f7 = f2 a) ∧
        (∀a f f1 f2 f3 f4 f5 f6 v f7.
           op_CASE (WordOp a) f f1 f2 f3 f4 f5 f6 v f7 = f3 a) ∧
        (∀a f f1 f2 f3 f4 f5 f6 v f7.
           op_CASE (BlockOp a) f f1 f2 f3 f4 f5 f6 v f7 = f4 a) ∧
        (∀a f f1 f2 f3 f4 f5 f6 v f7.
           op_CASE (GlobOp a) f f1 f2 f3 f4 f5 f6 v f7 = f5 a) ∧
        (∀a f f1 f2 f3 f4 f5 f6 v f7.
           op_CASE (MemOp a) f f1 f2 f3 f4 f5 f6 v f7 = f6 a) ∧
        (∀f f1 f2 f3 f4 f5 f6 v f7.
           op_CASE Install f f1 f2 f3 f4 f5 f6 v f7 = v) ∧
        ∀a f f1 f2 f3 f4 f5 f6 v f7.
          op_CASE (ThunkOp a) f f1 f2 f3 f4 f5 f6 v f7 = f7 a
   
   [op_size_def]  Definition
      
      ⊢ (∀a. op_size (Label a) = 1 + a) ∧
        (∀a. op_size (FFI a) = 1 + mlstring_size a) ∧
        (∀a. op_size (IntOp a) = 1 + int_op_size a) ∧
        (∀a. op_size (WordOp a) = 1 + word_op_size a) ∧
        (∀a. op_size (BlockOp a) = 1 + block_op_size a) ∧
        (∀a. op_size (GlobOp a) = 1 + glob_op_size a) ∧
        (∀a. op_size (MemOp a) = 1 + mem_op_size a) ∧ op_size Install = 0 ∧
        ∀a. op_size (ThunkOp a) = 1 + thunk_op_size a
   
   [pure_def_primitive]  Definition
      
      ⊢ pure =
        WFREC
          (@R. WF R ∧ (∀e2 e1 v2 e3. R e3 (If v2 e1 e2 e3)) ∧
               (∀e3 e1 v2 e2. R e2 (If v2 e1 e2 e3)) ∧
               (∀e3 e2 v2 e1. R e1 (If v2 e1 e2 e3)) ∧
               (∀es v3 e2. R e2 (Let v3 es e2)) ∧
               (∀e2 v3 es a. MEM a es ⇒ R a (Let v3 es e2)) ∧
               (∀e2 v6 e1. R e1 (Handle v6 e1 e2)) ∧
               (∀v25 v24 v23 v22 x. R x (Letrec v22 v23 v24 v25 x)) ∧
               ∀opn v26 es a. MEM a es ⇒ R a (Op v26 opn es))
          (λpure a'.
               case a' of
                 Var v0 v1 => I T
               | If v2 e1 e2 e3 => I (pure e1 ∧ pure e2 ∧ pure e3)
               | Let v3 es e2' => I (EVERY (λa. pure a) es ∧ pure e2')
               | Raise v4 v5 => I F
               | Handle v6 e1' e2'' => I (pure e1')
               | Tick v7 v8 => I F
               | Call v9 v10 v11 v12 => I F
               | App v13 v14 v15 v16 => I F
               | Fn v17 v18 v19 v20 v21 => I T
               | Letrec v22 v23 v24 v25 x => I (pure x)
               | Op v26 opn es' => I (EVERY (λa. pure a) es' ∧ pure_op opn))
   
   [pure_op_def]  Definition
      
      ⊢ ∀op.
          pure_op op ⇔
          case op of
            Label v8 => T
          | FFI v9 => F
          | IntOp v10 => T
          | WordOp v11 => T
          | BlockOp v12 => T
          | GlobOp (Global v18) => T
          | GlobOp (SetGlobal v19) => F
          | GlobOp AllocGlobal => F
          | GlobOp GlobalsPtr => T
          | GlobOp SetGlobalsPtr => T
          | MemOp Ref => F
          | MemOp Update => F
          | MemOp El => T
          | MemOp Length => T
          | MemOp LengthByte => T
          | MemOp (RefByte v23) => F
          | MemOp RefArray => F
          | MemOp DerefByte => T
          | MemOp UpdateByte => F
          | MemOp ConcatByteVec => T
          | MemOp (CopyByte T) => T
          | MemOp (CopyByte F) => F
          | MemOp FromListByte => T
          | MemOp ToListByte => T
          | MemOp LengthByteVec => T
          | MemOp DerefByteVec => T
          | MemOp XorByte => F
          | MemOp BoundsCheckArray => T
          | MemOp (BoundsCheckByte v25) => T
          | MemOp ConfigGC => T
          | Install => F
          | ThunkOp v15 => F
   
   [word_op_TY_DEF]  Definition
      
      ⊢ ∃rep.
          TYPE_DEFINITION
            (λa0'.
                 ∀ $var$('word_op').
                   (∀a0'.
                      (∃a0 a1.
                         a0' =
                         (λa0 a1.
                              ind_type$CONSTR 0
                                (a0,a1,ARB,ARB,ARB,ARB,ARB,ARB,ARB,ARB)
                                (λn. ind_type$BOTTOM)) a0 a1) ∨
                      (∃a0 a1 a2.
                         a0' =
                         (λa0 a1 a2.
                              ind_type$CONSTR (SUC 0)
                                (a0,ARB,a1,a2,ARB,ARB,ARB,ARB,ARB,ARB)
                                (λn. ind_type$BOTTOM)) a0 a1 a2) ∨
                      (∃a0 a1.
                         a0' =
                         (λa0 a1.
                              ind_type$CONSTR (SUC (SUC 0))
                                (a0,ARB,ARB,ARB,a1,ARB,ARB,ARB,ARB,ARB)
                                (λn. ind_type$BOTTOM)) a0 a1) ∨
                      a0' =
                      ind_type$CONSTR (SUC (SUC (SUC 0)))
                        (ARB,ARB,ARB,ARB,ARB,ARB,ARB,ARB,ARB,ARB)
                        (λn. ind_type$BOTTOM) ∨
                      a0' =
                      ind_type$CONSTR (SUC (SUC (SUC (SUC 0))))
                        (ARB,ARB,ARB,ARB,ARB,ARB,ARB,ARB,ARB,ARB)
                        (λn. ind_type$BOTTOM) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR
                                  (SUC (SUC (SUC (SUC (SUC 0)))))
                                  (ARB,ARB,ARB,ARB,ARB,a,ARB,ARB,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR
                                  (SUC (SUC (SUC (SUC (SUC (SUC 0))))))
                                  (ARB,ARB,ARB,ARB,ARB,ARB,a,ARB,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR
                                  (SUC
                                     (SUC (SUC (SUC (SUC (SUC (SUC 0)))))))
                                  (ARB,ARB,ARB,ARB,ARB,ARB,ARB,a,ARB,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR
                                  (SUC
                                     (SUC
                                        (SUC
                                           (SUC (SUC (SUC (SUC (SUC 0))))))))
                                  (ARB,ARB,ARB,ARB,ARB,ARB,ARB,ARB,a,ARB)
                                  (λn. ind_type$BOTTOM)) a) ∨
                      (∃a. a0' =
                           (λa.
                                ind_type$CONSTR
                                  (SUC
                                     (SUC
                                        (SUC
                                           (SUC
                                              (SUC
                                                 (SUC (SUC (SUC (SUC 0)))))))))
                                  (ARB,ARB,ARB,ARB,ARB,ARB,ARB,ARB,ARB,a)
                                  (λn. ind_type$BOTTOM)) a) ⇒
                      $var$('word_op') a0') ⇒
                   $var$('word_op') a0') rep
   
   [word_op_case_def]  Definition
      
      ⊢ (∀a0 a1 f f1 f2 v v1 f3 f4 f5 f6 f7.
           word_op_CASE (WordOpw a0 a1) f f1 f2 v v1 f3 f4 f5 f6 f7 =
           f a0 a1) ∧
        (∀a0 a1 a2 f f1 f2 v v1 f3 f4 f5 f6 f7.
           word_op_CASE (WordShift a0 a1 a2) f f1 f2 v v1 f3 f4 f5 f6 f7 =
           f1 a0 a1 a2) ∧
        (∀a0 a1 f f1 f2 v v1 f3 f4 f5 f6 f7.
           word_op_CASE (WordTest a0 a1) f f1 f2 v v1 f3 f4 f5 f6 f7 =
           f2 a0 a1) ∧
        (∀f f1 f2 v v1 f3 f4 f5 f6 f7.
           word_op_CASE WordFromInt f f1 f2 v v1 f3 f4 f5 f6 f7 = v) ∧
        (∀f f1 f2 v v1 f3 f4 f5 f6 f7.
           word_op_CASE WordToInt f f1 f2 v v1 f3 f4 f5 f6 f7 = v1) ∧
        (∀a f f1 f2 v v1 f3 f4 f5 f6 f7.
           word_op_CASE (WordFromWord a) f f1 f2 v v1 f3 f4 f5 f6 f7 = f3 a) ∧
        (∀a f f1 f2 v v1 f3 f4 f5 f6 f7.
           word_op_CASE (FP_cmp a) f f1 f2 v v1 f3 f4 f5 f6 f7 = f4 a) ∧
        (∀a f f1 f2 v v1 f3 f4 f5 f6 f7.
           word_op_CASE (FP_uop a) f f1 f2 v v1 f3 f4 f5 f6 f7 = f5 a) ∧
        (∀a f f1 f2 v v1 f3 f4 f5 f6 f7.
           word_op_CASE (FP_bop a) f f1 f2 v v1 f3 f4 f5 f6 f7 = f6 a) ∧
        ∀a f f1 f2 v v1 f3 f4 f5 f6 f7.
          word_op_CASE (FP_top a) f f1 f2 v v1 f3 f4 f5 f6 f7 = f7 a
   
   [word_op_size_def]  Definition
      
      ⊢ (∀a0 a1.
           word_op_size (WordOpw a0 a1) =
           1 + (word_size_size a0 + opw_size a1)) ∧
        (∀a0 a1 a2.
           word_op_size (WordShift a0 a1 a2) =
           1 + (word_size_size a0 + (shift_size a1 + a2))) ∧
        (∀a0 a1.
           word_op_size (WordTest a0 a1) =
           1 + (word_size_size a0 + test_size a1)) ∧
        word_op_size WordFromInt = 0 ∧ word_op_size WordToInt = 0 ∧
        (∀a. word_op_size (WordFromWord a) = 1 + bool_size a) ∧
        (∀a. word_op_size (FP_cmp a) = 1 + fp_cmp_size a) ∧
        (∀a. word_op_size (FP_uop a) = 1 + fp_uop_size a) ∧
        (∀a. word_op_size (FP_bop a) = 1 + fp_bop_size a) ∧
        ∀a. word_op_size (FP_top a) = 1 + fp_top_size a
   
   [assign_get_code_label_def]  Theorem
      
      ⊢ assign_get_code_label (Label x) = {x} ∧
        assign_get_code_label (FFI v1) = ∅ ∧
        assign_get_code_label (IntOp v2) = ∅ ∧
        assign_get_code_label (WordOp v3) = ∅ ∧
        assign_get_code_label (BlockOp v4) = ∅ ∧
        assign_get_code_label (GlobOp v5) = ∅ ∧
        assign_get_code_label (MemOp v6) = ∅ ∧
        assign_get_code_label Install = ∅ ∧
        assign_get_code_label (ThunkOp v7) = ∅
   
   [assign_get_code_label_ind]  Theorem
      
      ⊢ ∀P. (∀x. P (Label x)) ∧ (∀v1. P (FFI v1)) ∧ (∀v2. P (IntOp v2)) ∧
            (∀v3. P (WordOp v3)) ∧ (∀v4. P (BlockOp v4)) ∧
            (∀v5. P (GlobOp v5)) ∧ (∀v6. P (MemOp v6)) ∧ P Install ∧
            (∀v7. P (ThunkOp v7)) ⇒
            ∀v. P v
   
   [block_op_11]  Theorem
      
      ⊢ (∀a a'. Cons a = Cons a' ⇔ a = a') ∧
        (∀a a'. ElemAt a = ElemAt a' ⇔ a = a') ∧
        (∀a0 a1 a0' a1'.
           TagLenEq a0 a1 = TagLenEq a0' a1' ⇔ a0 = a0' ∧ a1 = a1') ∧
        (∀a a'. LenEq a = LenEq a' ⇔ a = a') ∧
        (∀a a'. TagEq a = TagEq a' ⇔ a = a') ∧
        (∀a a'. BoolTest a = BoolTest a' ⇔ a = a') ∧
        (∀a a'. ConsExtend a = ConsExtend a' ⇔ a = a') ∧
        (∀a a'. FromList a = FromList a' ⇔ a = a') ∧
        (∀a a'. Constant a = Constant a' ⇔ a = a') ∧
        (∀a a'. EqualConst a = EqualConst a' ⇔ a = a') ∧
        ∀a a'. Build a = Build a' ⇔ a = a'
   
   [block_op_Axiom]  Theorem
      
      ⊢ ∀f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15. ∃fn.
          (∀a. fn (Cons a) = f0 a) ∧ (∀a. fn (ElemAt a) = f1 a) ∧
          (∀a0 a1. fn (TagLenEq a0 a1) = f2 a0 a1) ∧
          (∀a. fn (LenEq a) = f3 a) ∧ (∀a. fn (TagEq a) = f4 a) ∧
          fn LengthBlock = f5 ∧ (∀a. fn (BoolTest a) = f6 a) ∧
          fn BoolNot = f7 ∧ fn BoundsCheckBlock = f8 ∧
          (∀a. fn (ConsExtend a) = f9 a) ∧ (∀a. fn (FromList a) = f10 a) ∧
          fn ListAppend = f11 ∧ (∀a. fn (Constant a) = f12 a) ∧
          fn Equal = f13 ∧ (∀a. fn (EqualConst a) = f14 a) ∧
          ∀a. fn (Build a) = f15 a
   
   [block_op_case_cong]  Theorem
      
      ⊢ ∀M M' f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10.
          M = M' ∧ (∀a. M' = Cons a ⇒ f a = f' a) ∧
          (∀a. M' = ElemAt a ⇒ f1 a = f1' a) ∧
          (∀a0 a1. M' = TagLenEq a0 a1 ⇒ f2 a0 a1 = f2' a0 a1) ∧
          (∀a. M' = LenEq a ⇒ f3 a = f3' a) ∧
          (∀a. M' = TagEq a ⇒ f4 a = f4' a) ∧ (M' = LengthBlock ⇒ v = v') ∧
          (∀a. M' = BoolTest a ⇒ f5 a = f5' a) ∧
          (M' = BoolNot ⇒ v1 = v1') ∧ (M' = BoundsCheckBlock ⇒ v2 = v2') ∧
          (∀a. M' = ConsExtend a ⇒ f6 a = f6' a) ∧
          (∀a. M' = FromList a ⇒ f7 a = f7' a) ∧
          (M' = ListAppend ⇒ v3 = v3') ∧
          (∀a. M' = Constant a ⇒ f8 a = f8' a) ∧ (M' = Equal ⇒ v4 = v4') ∧
          (∀a. M' = EqualConst a ⇒ f9 a = f9' a) ∧
          (∀a. M' = Build a ⇒ f10 a = f10' a) ⇒
          block_op_CASE M f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10 =
          block_op_CASE M' f' f1' f2' f3' f4' v' f5' v1' v2' f6' f7' v3'
            f8' v4' f9' f10'
   
   [block_op_case_eq]  Theorem
      
      ⊢ block_op_CASE x f f1 f2 f3 f4 v f5 v1 v2 f6 f7 v3 f8 v4 f9 f10 = v' ⇔
        (∃n. x = Cons n ∧ f n = v') ∨ (∃n. x = ElemAt n ∧ f1 n = v') ∨
        (∃n n0. x = TagLenEq n n0 ∧ f2 n n0 = v') ∨
        (∃n. x = LenEq n ∧ f3 n = v') ∨ (∃n. x = TagEq n ∧ f4 n = v') ∨
        x = LengthBlock ∧ v = v' ∨ (∃t. x = BoolTest t ∧ f5 t = v') ∨
        x = BoolNot ∧ v1 = v' ∨ x = BoundsCheckBlock ∧ v2 = v' ∨
        (∃n. x = ConsExtend n ∧ f6 n = v') ∨
        (∃n. x = FromList n ∧ f7 n = v') ∨ x = ListAppend ∧ v3 = v' ∨
        (∃c. x = Constant c ∧ f8 c = v') ∨ x = Equal ∧ v4 = v' ∨
        (∃c. x = EqualConst c ∧ f9 c = v') ∨ ∃l. x = Build l ∧ f10 l = v'
   
   [block_op_distinct]  Theorem
      
      ⊢ (∀a' a. Cons a ≠ ElemAt a') ∧ (∀a1 a0 a. Cons a ≠ TagLenEq a0 a1) ∧
        (∀a' a. Cons a ≠ LenEq a') ∧ (∀a' a. Cons a ≠ TagEq a') ∧
        (∀a. Cons a ≠ LengthBlock) ∧ (∀a' a. Cons a ≠ BoolTest a') ∧
        (∀a. Cons a ≠ BoolNot) ∧ (∀a. Cons a ≠ BoundsCheckBlock) ∧
        (∀a' a. Cons a ≠ ConsExtend a') ∧ (∀a' a. Cons a ≠ FromList a') ∧
        (∀a. Cons a ≠ ListAppend) ∧ (∀a' a. Cons a ≠ Constant a') ∧
        (∀a. Cons a ≠ Equal) ∧ (∀a' a. Cons a ≠ EqualConst a') ∧
        (∀a' a. Cons a ≠ Build a') ∧
        (∀a1 a0 a. ElemAt a ≠ TagLenEq a0 a1) ∧
        (∀a' a. ElemAt a ≠ LenEq a') ∧ (∀a' a. ElemAt a ≠ TagEq a') ∧
        (∀a. ElemAt a ≠ LengthBlock) ∧ (∀a' a. ElemAt a ≠ BoolTest a') ∧
        (∀a. ElemAt a ≠ BoolNot) ∧ (∀a. ElemAt a ≠ BoundsCheckBlock) ∧
        (∀a' a. ElemAt a ≠ ConsExtend a') ∧
        (∀a' a. ElemAt a ≠ FromList a') ∧ (∀a. ElemAt a ≠ ListAppend) ∧
        (∀a' a. ElemAt a ≠ Constant a') ∧ (∀a. ElemAt a ≠ Equal) ∧
        (∀a' a. ElemAt a ≠ EqualConst a') ∧ (∀a' a. ElemAt a ≠ Build a') ∧
        (∀a1 a0 a. TagLenEq a0 a1 ≠ LenEq a) ∧
        (∀a1 a0 a. TagLenEq a0 a1 ≠ TagEq a) ∧
        (∀a1 a0. TagLenEq a0 a1 ≠ LengthBlock) ∧
        (∀a1 a0 a. TagLenEq a0 a1 ≠ BoolTest a) ∧
        (∀a1 a0. TagLenEq a0 a1 ≠ BoolNot) ∧
        (∀a1 a0. TagLenEq a0 a1 ≠ BoundsCheckBlock) ∧
        (∀a1 a0 a. TagLenEq a0 a1 ≠ ConsExtend a) ∧
        (∀a1 a0 a. TagLenEq a0 a1 ≠ FromList a) ∧
        (∀a1 a0. TagLenEq a0 a1 ≠ ListAppend) ∧
        (∀a1 a0 a. TagLenEq a0 a1 ≠ Constant a) ∧
        (∀a1 a0. TagLenEq a0 a1 ≠ Equal) ∧
        (∀a1 a0 a. TagLenEq a0 a1 ≠ EqualConst a) ∧
        (∀a1 a0 a. TagLenEq a0 a1 ≠ Build a) ∧
        (∀a' a. LenEq a ≠ TagEq a') ∧ (∀a. LenEq a ≠ LengthBlock) ∧
        (∀a' a. LenEq a ≠ BoolTest a') ∧ (∀a. LenEq a ≠ BoolNot) ∧
        (∀a. LenEq a ≠ BoundsCheckBlock) ∧
        (∀a' a. LenEq a ≠ ConsExtend a') ∧ (∀a' a. LenEq a ≠ FromList a') ∧
        (∀a. LenEq a ≠ ListAppend) ∧ (∀a' a. LenEq a ≠ Constant a') ∧
        (∀a. LenEq a ≠ Equal) ∧ (∀a' a. LenEq a ≠ EqualConst a') ∧
        (∀a' a. LenEq a ≠ Build a') ∧ (∀a. TagEq a ≠ LengthBlock) ∧
        (∀a' a. TagEq a ≠ BoolTest a') ∧ (∀a. TagEq a ≠ BoolNot) ∧
        (∀a. TagEq a ≠ BoundsCheckBlock) ∧
        (∀a' a. TagEq a ≠ ConsExtend a') ∧ (∀a' a. TagEq a ≠ FromList a') ∧
        (∀a. TagEq a ≠ ListAppend) ∧ (∀a' a. TagEq a ≠ Constant a') ∧
        (∀a. TagEq a ≠ Equal) ∧ (∀a' a. TagEq a ≠ EqualConst a') ∧
        (∀a' a. TagEq a ≠ Build a') ∧ (∀a. LengthBlock ≠ BoolTest a) ∧
        LengthBlock ≠ BoolNot ∧ LengthBlock ≠ BoundsCheckBlock ∧
        (∀a. LengthBlock ≠ ConsExtend a) ∧ (∀a. LengthBlock ≠ FromList a) ∧
        LengthBlock ≠ ListAppend ∧ (∀a. LengthBlock ≠ Constant a) ∧
        LengthBlock ≠ Equal ∧ (∀a. LengthBlock ≠ EqualConst a) ∧
        (∀a. LengthBlock ≠ Build a) ∧ (∀a. BoolTest a ≠ BoolNot) ∧
        (∀a. BoolTest a ≠ BoundsCheckBlock) ∧
        (∀a' a. BoolTest a ≠ ConsExtend a') ∧
        (∀a' a. BoolTest a ≠ FromList a') ∧ (∀a. BoolTest a ≠ ListAppend) ∧
        (∀a' a. BoolTest a ≠ Constant a') ∧ (∀a. BoolTest a ≠ Equal) ∧
        (∀a' a. BoolTest a ≠ EqualConst a') ∧
        (∀a' a. BoolTest a ≠ Build a') ∧ BoolNot ≠ BoundsCheckBlock ∧
        (∀a. BoolNot ≠ ConsExtend a) ∧ (∀a. BoolNot ≠ FromList a) ∧
        BoolNot ≠ ListAppend ∧ (∀a. BoolNot ≠ Constant a) ∧
        BoolNot ≠ Equal ∧ (∀a. BoolNot ≠ EqualConst a) ∧
        (∀a. BoolNot ≠ Build a) ∧ (∀a. BoundsCheckBlock ≠ ConsExtend a) ∧
        (∀a. BoundsCheckBlock ≠ FromList a) ∧
        BoundsCheckBlock ≠ ListAppend ∧
        (∀a. BoundsCheckBlock ≠ Constant a) ∧ BoundsCheckBlock ≠ Equal ∧
        (∀a. BoundsCheckBlock ≠ EqualConst a) ∧
        (∀a. BoundsCheckBlock ≠ Build a) ∧
        (∀a' a. ConsExtend a ≠ FromList a') ∧
        (∀a. ConsExtend a ≠ ListAppend) ∧
        (∀a' a. ConsExtend a ≠ Constant a') ∧ (∀a. ConsExtend a ≠ Equal) ∧
        (∀a' a. ConsExtend a ≠ EqualConst a') ∧
        (∀a' a. ConsExtend a ≠ Build a') ∧ (∀a. FromList a ≠ ListAppend) ∧
        (∀a' a. FromList a ≠ Constant a') ∧ (∀a. FromList a ≠ Equal) ∧
        (∀a' a. FromList a ≠ EqualConst a') ∧
        (∀a' a. FromList a ≠ Build a') ∧ (∀a. ListAppend ≠ Constant a) ∧
        ListAppend ≠ Equal ∧ (∀a. ListAppend ≠ EqualConst a) ∧
        (∀a. ListAppend ≠ Build a) ∧ (∀a. Constant a ≠ Equal) ∧
        (∀a' a. Constant a ≠ EqualConst a') ∧
        (∀a' a. Constant a ≠ Build a') ∧ (∀a. Equal ≠ EqualConst a) ∧
        (∀a. Equal ≠ Build a) ∧ ∀a' a. EqualConst a ≠ Build a'
   
   [block_op_induction]  Theorem
      
      ⊢ ∀P. (∀n. P (Cons n)) ∧ (∀n. P (ElemAt n)) ∧
            (∀n n0. P (TagLenEq n n0)) ∧ (∀n. P (LenEq n)) ∧
            (∀n. P (TagEq n)) ∧ P LengthBlock ∧ (∀t. P (BoolTest t)) ∧
            P BoolNot ∧ P BoundsCheckBlock ∧ (∀n. P (ConsExtend n)) ∧
            (∀n. P (FromList n)) ∧ P ListAppend ∧ (∀c. P (Constant c)) ∧
            P Equal ∧ (∀c. P (EqualConst c)) ∧ (∀l. P (Build l)) ⇒
            ∀b. P b
   
   [block_op_nchotomy]  Theorem
      
      ⊢ ∀bb.
          (∃n. bb = Cons n) ∨ (∃n. bb = ElemAt n) ∨
          (∃n n0. bb = TagLenEq n n0) ∨ (∃n. bb = LenEq n) ∨
          (∃n. bb = TagEq n) ∨ bb = LengthBlock ∨ (∃t. bb = BoolTest t) ∨
          bb = BoolNot ∨ bb = BoundsCheckBlock ∨ (∃n. bb = ConsExtend n) ∨
          (∃n. bb = FromList n) ∨ bb = ListAppend ∨ (∃c. bb = Constant c) ∨
          bb = Equal ∨ (∃c. bb = EqualConst c) ∨ ∃l. bb = Build l
   
   [const_11]  Theorem
      
      ⊢ (∀a0 a1 a0' a1'.
           ConstCons a0 a1 = ConstCons a0' a1' ⇔ a0 = a0' ∧ a1 = a1') ∧
        (∀a a'. ConstInt a = ConstInt a' ⇔ a = a') ∧
        (∀a a'. ConstStr a = ConstStr a' ⇔ a = a') ∧
        ∀a a'. ConstWord64 a = ConstWord64 a' ⇔ a = a'
   
   [const_Axiom]  Theorem
      
      ⊢ ∀f0 f1 f2 f3 f4 f5. ∃fn0 fn1.
          (∀a0 a1. fn0 (ConstCons a0 a1) = f0 a0 a1 (fn1 a1)) ∧
          (∀a. fn0 (ConstInt a) = f1 a) ∧ (∀a. fn0 (ConstStr a) = f2 a) ∧
          (∀a. fn0 (ConstWord64 a) = f3 a) ∧ fn1 [] = f4 ∧
          ∀a0 a1. fn1 (a0::a1) = f5 a0 a1 (fn0 a0) (fn1 a1)
   
   [const_case_cong]  Theorem
      
      ⊢ ∀M M' f f1 f2 f3.
          M = M' ∧ (∀a0 a1. M' = ConstCons a0 a1 ⇒ f a0 a1 = f' a0 a1) ∧
          (∀a. M' = ConstInt a ⇒ f1 a = f1' a) ∧
          (∀a. M' = ConstStr a ⇒ f2 a = f2' a) ∧
          (∀a. M' = ConstWord64 a ⇒ f3 a = f3' a) ⇒
          const_CASE M f f1 f2 f3 = const_CASE M' f' f1' f2' f3'
   
   [const_case_eq]  Theorem
      
      ⊢ const_CASE x f f1 f2 f3 = v ⇔
        (∃n l. x = ConstCons n l ∧ f n l = v) ∨
        (∃i. x = ConstInt i ∧ f1 i = v) ∨ (∃m. x = ConstStr m ∧ f2 m = v) ∨
        ∃c. x = ConstWord64 c ∧ f3 c = v
   
   [const_distinct]  Theorem
      
      ⊢ (∀a1 a0 a. ConstCons a0 a1 ≠ ConstInt a) ∧
        (∀a1 a0 a. ConstCons a0 a1 ≠ ConstStr a) ∧
        (∀a1 a0 a. ConstCons a0 a1 ≠ ConstWord64 a) ∧
        (∀a' a. ConstInt a ≠ ConstStr a') ∧
        (∀a' a. ConstInt a ≠ ConstWord64 a') ∧
        ∀a' a. ConstStr a ≠ ConstWord64 a'
   
   [const_induction]  Theorem
      
      ⊢ ∀P0 P1.
          (∀l. P1 l ⇒ ∀n. P0 (ConstCons n l)) ∧ (∀i. P0 (ConstInt i)) ∧
          (∀m. P0 (ConstStr m)) ∧ (∀c. P0 (ConstWord64 c)) ∧ P1 [] ∧
          (∀c l. P0 c ∧ P1 l ⇒ P1 (c::l)) ⇒
          (∀c. P0 c) ∧ ∀l. P1 l
   
   [const_nchotomy]  Theorem
      
      ⊢ ∀cc.
          (∃n l. cc = ConstCons n l) ∨ (∃i. cc = ConstInt i) ∨
          (∃m. cc = ConstStr m) ∨ ∃c. cc = ConstWord64 c
   
   [const_part_11]  Theorem
      
      ⊢ (∀a0 a1 a0' a1'. Con a0 a1 = Con a0' a1' ⇔ a0 = a0' ∧ a1 = a1') ∧
        (∀a a'. Int a = Int a' ⇔ a = a') ∧
        (∀a a'. Str a = Str a' ⇔ a = a') ∧ ∀a a'. W64 a = W64 a' ⇔ a = a'
   
   [const_part_Axiom]  Theorem
      
      ⊢ ∀f0 f1 f2 f3. ∃fn.
          (∀a0 a1. fn (Con a0 a1) = f0 a0 a1) ∧ (∀a. fn (Int a) = f1 a) ∧
          (∀a. fn (Str a) = f2 a) ∧ ∀a. fn (W64 a) = f3 a
   
   [const_part_case_cong]  Theorem
      
      ⊢ ∀M M' f f1 f2 f3.
          M = M' ∧ (∀a0 a1. M' = Con a0 a1 ⇒ f a0 a1 = f' a0 a1) ∧
          (∀a. M' = Int a ⇒ f1 a = f1' a) ∧
          (∀a. M' = Str a ⇒ f2 a = f2' a) ∧ (∀a. M' = W64 a ⇒ f3 a = f3' a) ⇒
          const_part_CASE M f f1 f2 f3 = const_part_CASE M' f' f1' f2' f3'
   
   [const_part_case_eq]  Theorem
      
      ⊢ const_part_CASE x f f1 f2 f3 = v ⇔
        (∃n l. x = Con n l ∧ f n l = v) ∨ (∃i. x = Int i ∧ f1 i = v) ∨
        (∃m. x = Str m ∧ f2 m = v) ∨ ∃c. x = W64 c ∧ f3 c = v
   
   [const_part_distinct]  Theorem
      
      ⊢ (∀a1 a0 a. Con a0 a1 ≠ Int a) ∧ (∀a1 a0 a. Con a0 a1 ≠ Str a) ∧
        (∀a1 a0 a. Con a0 a1 ≠ W64 a) ∧ (∀a' a. Int a ≠ Str a') ∧
        (∀a' a. Int a ≠ W64 a') ∧ ∀a' a. Str a ≠ W64 a'
   
   [const_part_induction]  Theorem
      
      ⊢ ∀P. (∀n l. P (Con n l)) ∧ (∀i. P (Int i)) ∧ (∀m. P (Str m)) ∧
            (∀c. P (W64 c)) ⇒
            ∀c. P c
   
   [const_part_nchotomy]  Theorem
      
      ⊢ ∀cc.
          (∃n l. cc = Con n l) ∨ (∃i. cc = Int i) ∨ (∃m. cc = Str m) ∨
          ∃c. cc = W64 c
   
   [datatype_block_op]  Theorem
      
      ⊢ DATATYPE
          (block_op Cons ElemAt TagLenEq LenEq TagEq LengthBlock BoolTest
             BoolNot BoundsCheckBlock ConsExtend FromList ListAppend
             Constant Equal EqualConst Build)
   
   [datatype_const]  Theorem
      
      ⊢ DATATYPE (const ConstCons ConstInt ConstStr ConstWord64)
   
   [datatype_const_part]  Theorem
      
      ⊢ DATATYPE (const_part Con Int Str W64)
   
   [datatype_exp]  Theorem
      
      ⊢ DATATYPE (exp Var If Let Raise Handle Tick Call App Fn Letrec Op)
   
   [datatype_glob_op]  Theorem
      
      ⊢ DATATYPE
          (glob_op Global SetGlobal AllocGlobal GlobalsPtr SetGlobalsPtr)
   
   [datatype_int_op]  Theorem
      
      ⊢ DATATYPE
          (int_op Const Add Sub Mult Div Mod Less LessEq Greater GreaterEq
             LessConstSmall)
   
   [datatype_mem_op]  Theorem
      
      ⊢ DATATYPE
          (mem_op Ref Update El Length LengthByte RefByte RefArray
             DerefByte UpdateByte ConcatByteVec CopyByte FromListByte
             ToListByte LengthByteVec DerefByteVec XorByte BoundsCheckArray
             BoundsCheckByte ConfigGC)
   
   [datatype_op]  Theorem
      
      ⊢ DATATYPE
          (op Label FFI IntOp WordOp BlockOp GlobOp MemOp Install ThunkOp)
   
   [datatype_word_op]  Theorem
      
      ⊢ DATATYPE
          (word_op WordOpw WordShift WordTest WordFromInt WordToInt
             WordFromWord FP_cmp FP_uop FP_bop FP_top)
   
   [exp1_size_lemma]  Theorem
      
      ⊢ ∀fns n x. MEM (n,x) fns ⇒ exp_size x < exp1_size fns
   
   [exp_11]  Theorem
      
      ⊢ (∀a0 a1 a0' a1'. Var a0 a1 = Var a0' a1' ⇔ a0 = a0' ∧ a1 = a1') ∧
        (∀a0 a1 a2 a3 a0' a1' a2' a3'.
           If a0 a1 a2 a3 = If a0' a1' a2' a3' ⇔
           a0 = a0' ∧ a1 = a1' ∧ a2 = a2' ∧ a3 = a3') ∧
        (∀a0 a1 a2 a0' a1' a2'.
           Let a0 a1 a2 = Let a0' a1' a2' ⇔ a0 = a0' ∧ a1 = a1' ∧ a2 = a2') ∧
        (∀a0 a1 a0' a1'. Raise a0 a1 = Raise a0' a1' ⇔ a0 = a0' ∧ a1 = a1') ∧
        (∀a0 a1 a2 a0' a1' a2'.
           Handle a0 a1 a2 = Handle a0' a1' a2' ⇔
           a0 = a0' ∧ a1 = a1' ∧ a2 = a2') ∧
        (∀a0 a1 a0' a1'. Tick a0 a1 = Tick a0' a1' ⇔ a0 = a0' ∧ a1 = a1') ∧
        (∀a0 a1 a2 a3 a0' a1' a2' a3'.
           Call a0 a1 a2 a3 = Call a0' a1' a2' a3' ⇔
           a0 = a0' ∧ a1 = a1' ∧ a2 = a2' ∧ a3 = a3') ∧
        (∀a0 a1 a2 a3 a0' a1' a2' a3'.
           App a0 a1 a2 a3 = App a0' a1' a2' a3' ⇔
           a0 = a0' ∧ a1 = a1' ∧ a2 = a2' ∧ a3 = a3') ∧
        (∀a0 a1 a2 a3 a4 a0' a1' a2' a3' a4'.
           Fn a0 a1 a2 a3 a4 = Fn a0' a1' a2' a3' a4' ⇔
           a0 = a0' ∧ a1 = a1' ∧ a2 = a2' ∧ a3 = a3' ∧ a4 = a4') ∧
        (∀a0 a1 a2 a3 a4 a0' a1' a2' a3' a4'.
           Letrec a0 a1 a2 a3 a4 = Letrec a0' a1' a2' a3' a4' ⇔
           a0 = a0' ∧ a1 = a1' ∧ a2 = a2' ∧ a3 = a3' ∧ a4 = a4') ∧
        ∀a0 a1 a2 a0' a1' a2'.
          Op a0 a1 a2 = Op a0' a1' a2' ⇔ a0 = a0' ∧ a1 = a1' ∧ a2 = a2'
   
   [exp_Axiom]  Theorem
      
      ⊢ ∀f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15.
            ∃fn0 fn1 fn2 fn3.
          (∀a0 a1. fn0 (Var a0 a1) = f0 a0 a1) ∧
          (∀a0 a1 a2 a3.
             fn0 (If a0 a1 a2 a3) =
             f1 a0 a1 a2 a3 (fn0 a1) (fn0 a2) (fn0 a3)) ∧
          (∀a0 a1 a2. fn0 (Let a0 a1 a2) = f2 a0 a1 a2 (fn3 a1) (fn0 a2)) ∧
          (∀a0 a1. fn0 (Raise a0 a1) = f3 a0 a1 (fn0 a1)) ∧
          (∀a0 a1 a2. fn0 (Handle a0 a1 a2) = f4 a0 a1 a2 (fn0 a1) (fn0 a2)) ∧
          (∀a0 a1. fn0 (Tick a0 a1) = f5 a0 a1 (fn0 a1)) ∧
          (∀a0 a1 a2 a3. fn0 (Call a0 a1 a2 a3) = f6 a0 a1 a2 a3 (fn3 a3)) ∧
          (∀a0 a1 a2 a3.
             fn0 (App a0 a1 a2 a3) = f7 a0 a1 a2 a3 (fn0 a2) (fn3 a3)) ∧
          (∀a0 a1 a2 a3 a4.
             fn0 (Fn a0 a1 a2 a3 a4) = f8 a0 a1 a2 a3 a4 (fn0 a4)) ∧
          (∀a0 a1 a2 a3 a4.
             fn0 (Letrec a0 a1 a2 a3 a4) =
             f9 a0 a1 a2 a3 a4 (fn1 a3) (fn0 a4)) ∧
          (∀a0 a1 a2. fn0 (Op a0 a1 a2) = f10 a0 a1 a2 (fn3 a2)) ∧
          fn1 [] = f11 ∧
          (∀a0 a1. fn1 (a0::a1) = f12 a0 a1 (fn2 a0) (fn1 a1)) ∧
          (∀a0 a1. fn2 (a0,a1) = f13 a0 a1 (fn0 a1)) ∧ fn3 [] = f14 ∧
          ∀a0 a1. fn3 (a0::a1) = f15 a0 a1 (fn0 a0) (fn3 a1)
   
   [exp_case_cong]  Theorem
      
      ⊢ ∀M M' f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10.
          M = M' ∧ (∀a0 a1. M' = Var a0 a1 ⇒ f a0 a1 = f' a0 a1) ∧
          (∀a0 a1 a2 a3.
             M' = If a0 a1 a2 a3 ⇒ f1 a0 a1 a2 a3 = f1' a0 a1 a2 a3) ∧
          (∀a0 a1 a2. M' = Let a0 a1 a2 ⇒ f2 a0 a1 a2 = f2' a0 a1 a2) ∧
          (∀a0 a1. M' = Raise a0 a1 ⇒ f3 a0 a1 = f3' a0 a1) ∧
          (∀a0 a1 a2. M' = Handle a0 a1 a2 ⇒ f4 a0 a1 a2 = f4' a0 a1 a2) ∧
          (∀a0 a1. M' = Tick a0 a1 ⇒ f5 a0 a1 = f5' a0 a1) ∧
          (∀a0 a1 a2 a3.
             M' = Call a0 a1 a2 a3 ⇒ f6 a0 a1 a2 a3 = f6' a0 a1 a2 a3) ∧
          (∀a0 a1 a2 a3.
             M' = App a0 a1 a2 a3 ⇒ f7 a0 a1 a2 a3 = f7' a0 a1 a2 a3) ∧
          (∀a0 a1 a2 a3 a4.
             M' = Fn a0 a1 a2 a3 a4 ⇒
             f8 a0 a1 a2 a3 a4 = f8' a0 a1 a2 a3 a4) ∧
          (∀a0 a1 a2 a3 a4.
             M' = Letrec a0 a1 a2 a3 a4 ⇒
             f9 a0 a1 a2 a3 a4 = f9' a0 a1 a2 a3 a4) ∧
          (∀a0 a1 a2. M' = Op a0 a1 a2 ⇒ f10 a0 a1 a2 = f10' a0 a1 a2) ⇒
          exp_CASE M f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 =
          exp_CASE M' f' f1' f2' f3' f4' f5' f6' f7' f8' f9' f10'
   
   [exp_case_eq]  Theorem
      
      ⊢ exp_CASE x f f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 = v ⇔
        (∃t n. x = Var t n ∧ f t n = v) ∨
        (∃t e e0 e1. x = If t e e0 e1 ∧ f1 t e e0 e1 = v) ∨
        (∃t l e. x = Let t l e ∧ f2 t l e = v) ∨
        (∃t e. x = Raise t e ∧ f3 t e = v) ∨
        (∃t e e0. x = Handle t e e0 ∧ f4 t e e0 = v) ∨
        (∃t e. x = Tick t e ∧ f5 t e = v) ∨
        (∃t n0 n l. x = Call t n0 n l ∧ f6 t n0 n l = v) ∨
        (∃t o' e l. x = App t o' e l ∧ f7 t o' e l = v) ∨
        (∃m o0 o' n e. x = Fn m o0 o' n e ∧ f8 m o0 o' n e = v) ∨
        (∃l0 o0 o' l e. x = Letrec l0 o0 o' l e ∧ f9 l0 o0 o' l e = v) ∨
        ∃t o' l. x = Op t o' l ∧ f10 t o' l = v
   
   [exp_distinct]  Theorem
      
      ⊢ (∀a3 a2 a1' a1 a0' a0. Var a0 a1 ≠ If a0' a1' a2 a3) ∧
        (∀a2 a1' a1 a0' a0. Var a0 a1 ≠ Let a0' a1' a2) ∧
        (∀a1' a1 a0' a0. Var a0 a1 ≠ Raise a0' a1') ∧
        (∀a2 a1' a1 a0' a0. Var a0 a1 ≠ Handle a0' a1' a2) ∧
        (∀a1' a1 a0' a0. Var a0 a1 ≠ Tick a0' a1') ∧
        (∀a3 a2 a1' a1 a0' a0. Var a0 a1 ≠ Call a0' a1' a2 a3) ∧
        (∀a3 a2 a1' a1 a0' a0. Var a0 a1 ≠ App a0' a1' a2 a3) ∧
        (∀a4 a3 a2 a1' a1 a0' a0. Var a0 a1 ≠ Fn a0' a1' a2 a3 a4) ∧
        (∀a4 a3 a2 a1' a1 a0' a0. Var a0 a1 ≠ Letrec a0' a1' a2 a3 a4) ∧
        (∀a2 a1' a1 a0' a0. Var a0 a1 ≠ Op a0' a1' a2) ∧
        (∀a3 a2' a2 a1' a1 a0' a0. If a0 a1 a2 a3 ≠ Let a0' a1' a2') ∧
        (∀a3 a2 a1' a1 a0' a0. If a0 a1 a2 a3 ≠ Raise a0' a1') ∧
        (∀a3 a2' a2 a1' a1 a0' a0. If a0 a1 a2 a3 ≠ Handle a0' a1' a2') ∧
        (∀a3 a2 a1' a1 a0' a0. If a0 a1 a2 a3 ≠ Tick a0' a1') ∧
        (∀a3' a3 a2' a2 a1' a1 a0' a0.
           If a0 a1 a2 a3 ≠ Call a0' a1' a2' a3') ∧
        (∀a3' a3 a2' a2 a1' a1 a0' a0. If a0 a1 a2 a3 ≠ App a0' a1' a2' a3') ∧
        (∀a4 a3' a3 a2' a2 a1' a1 a0' a0.
           If a0 a1 a2 a3 ≠ Fn a0' a1' a2' a3' a4) ∧
        (∀a4 a3' a3 a2' a2 a1' a1 a0' a0.
           If a0 a1 a2 a3 ≠ Letrec a0' a1' a2' a3' a4) ∧
        (∀a3 a2' a2 a1' a1 a0' a0. If a0 a1 a2 a3 ≠ Op a0' a1' a2') ∧
        (∀a2 a1' a1 a0' a0. Let a0 a1 a2 ≠ Raise a0' a1') ∧
        (∀a2' a2 a1' a1 a0' a0. Let a0 a1 a2 ≠ Handle a0' a1' a2') ∧
        (∀a2 a1' a1 a0' a0. Let a0 a1 a2 ≠ Tick a0' a1') ∧
        (∀a3 a2' a2 a1' a1 a0' a0. Let a0 a1 a2 ≠ Call a0' a1' a2' a3) ∧
        (∀a3 a2' a2 a1' a1 a0' a0. Let a0 a1 a2 ≠ App a0' a1' a2' a3) ∧
        (∀a4 a3 a2' a2 a1' a1 a0' a0. Let a0 a1 a2 ≠ Fn a0' a1' a2' a3 a4) ∧
        (∀a4 a3 a2' a2 a1' a1 a0' a0.
           Let a0 a1 a2 ≠ Letrec a0' a1' a2' a3 a4) ∧
        (∀a2' a2 a1' a1 a0' a0. Let a0 a1 a2 ≠ Op a0' a1' a2') ∧
        (∀a2 a1' a1 a0' a0. Raise a0 a1 ≠ Handle a0' a1' a2) ∧
        (∀a1' a1 a0' a0. Raise a0 a1 ≠ Tick a0' a1') ∧
        (∀a3 a2 a1' a1 a0' a0. Raise a0 a1 ≠ Call a0' a1' a2 a3) ∧
        (∀a3 a2 a1' a1 a0' a0. Raise a0 a1 ≠ App a0' a1' a2 a3) ∧
        (∀a4 a3 a2 a1' a1 a0' a0. Raise a0 a1 ≠ Fn a0' a1' a2 a3 a4) ∧
        (∀a4 a3 a2 a1' a1 a0' a0. Raise a0 a1 ≠ Letrec a0' a1' a2 a3 a4) ∧
        (∀a2 a1' a1 a0' a0. Raise a0 a1 ≠ Op a0' a1' a2) ∧
        (∀a2 a1' a1 a0' a0. Handle a0 a1 a2 ≠ Tick a0' a1') ∧
        (∀a3 a2' a2 a1' a1 a0' a0. Handle a0 a1 a2 ≠ Call a0' a1' a2' a3) ∧
        (∀a3 a2' a2 a1' a1 a0' a0. Handle a0 a1 a2 ≠ App a0' a1' a2' a3) ∧
        (∀a4 a3 a2' a2 a1' a1 a0' a0.
           Handle a0 a1 a2 ≠ Fn a0' a1' a2' a3 a4) ∧
        (∀a4 a3 a2' a2 a1' a1 a0' a0.
           Handle a0 a1 a2 ≠ Letrec a0' a1' a2' a3 a4) ∧
        (∀a2' a2 a1' a1 a0' a0. Handle a0 a1 a2 ≠ Op a0' a1' a2') ∧
        (∀a3 a2 a1' a1 a0' a0. Tick a0 a1 ≠ Call a0' a1' a2 a3) ∧
        (∀a3 a2 a1' a1 a0' a0. Tick a0 a1 ≠ App a0' a1' a2 a3) ∧
        (∀a4 a3 a2 a1' a1 a0' a0. Tick a0 a1 ≠ Fn a0' a1' a2 a3 a4) ∧
        (∀a4 a3 a2 a1' a1 a0' a0. Tick a0 a1 ≠ Letrec a0' a1' a2 a3 a4) ∧
        (∀a2 a1' a1 a0' a0. Tick a0 a1 ≠ Op a0' a1' a2) ∧
        (∀a3' a3 a2' a2 a1' a1 a0' a0.
           Call a0 a1 a2 a3 ≠ App a0' a1' a2' a3') ∧
        (∀a4 a3' a3 a2' a2 a1' a1 a0' a0.
           Call a0 a1 a2 a3 ≠ Fn a0' a1' a2' a3' a4) ∧
        (∀a4 a3' a3 a2' a2 a1' a1 a0' a0.
           Call a0 a1 a2 a3 ≠ Letrec a0' a1' a2' a3' a4) ∧
        (∀a3 a2' a2 a1' a1 a0' a0. Call a0 a1 a2 a3 ≠ Op a0' a1' a2') ∧
        (∀a4 a3' a3 a2' a2 a1' a1 a0' a0.
           App a0 a1 a2 a3 ≠ Fn a0' a1' a2' a3' a4) ∧
        (∀a4 a3' a3 a2' a2 a1' a1 a0' a0.
           App a0 a1 a2 a3 ≠ Letrec a0' a1' a2' a3' a4) ∧
        (∀a3 a2' a2 a1' a1 a0' a0. App a0 a1 a2 a3 ≠ Op a0' a1' a2') ∧
        (∀a4' a4 a3' a3 a2' a2 a1' a1 a0' a0.
           Fn a0 a1 a2 a3 a4 ≠ Letrec a0' a1' a2' a3' a4') ∧
        (∀a4 a3 a2' a2 a1' a1 a0' a0. Fn a0 a1 a2 a3 a4 ≠ Op a0' a1' a2') ∧
        ∀a4 a3 a2' a2 a1' a1 a0' a0. Letrec a0 a1 a2 a3 a4 ≠ Op a0' a1' a2'
   
   [exp_induction]  Theorem
      
      ⊢ ∀P0 P1 P2 P3.
          (∀t n. P0 (Var t n)) ∧
          (∀e e0 e1. P0 e ∧ P0 e0 ∧ P0 e1 ⇒ ∀t. P0 (If t e e0 e1)) ∧
          (∀l e. P3 l ∧ P0 e ⇒ ∀t. P0 (Let t l e)) ∧
          (∀e. P0 e ⇒ ∀t. P0 (Raise t e)) ∧
          (∀e e0. P0 e ∧ P0 e0 ⇒ ∀t. P0 (Handle t e e0)) ∧
          (∀e. P0 e ⇒ ∀t. P0 (Tick t e)) ∧
          (∀l. P3 l ⇒ ∀n n0 t. P0 (Call t n0 n l)) ∧
          (∀e l. P0 e ∧ P3 l ⇒ ∀ $o t. P0 (App t $o e l)) ∧
          (∀e. P0 e ⇒ ∀n $o o0 m. P0 (Fn m o0 $o n e)) ∧
          (∀l e. P1 l ∧ P0 e ⇒ ∀ $o o0 l0. P0 (Letrec l0 o0 $o l e)) ∧
          (∀l. P3 l ⇒ ∀ $o t. P0 (Op t $o l)) ∧ P1 [] ∧
          (∀p l. P2 p ∧ P1 l ⇒ P1 (p::l)) ∧ (∀e. P0 e ⇒ ∀n. P2 (n,e)) ∧
          P3 [] ∧ (∀e l. P0 e ∧ P3 l ⇒ P3 (e::l)) ⇒
          (∀e. P0 e) ∧ (∀l. P1 l) ∧ (∀p. P2 p) ∧ ∀l. P3 l
   
   [exp_nchotomy]  Theorem
      
      ⊢ ∀ee.
          (∃t n. ee = Var t n) ∨ (∃t e e0 e1. ee = If t e e0 e1) ∨
          (∃t l e. ee = Let t l e) ∨ (∃t e. ee = Raise t e) ∨
          (∃t e e0. ee = Handle t e e0) ∨ (∃t e. ee = Tick t e) ∨
          (∃t n0 n l. ee = Call t n0 n l) ∨
          (∃t o' e l. ee = App t o' e l) ∨
          (∃m o0 o' n e. ee = Fn m o0 o' n e) ∨
          (∃l0 o0 o' l e. ee = Letrec l0 o0 o' l e) ∨
          ∃t o' l. ee = Op t o' l
   
   [glob_op_11]  Theorem
      
      ⊢ (∀a a'. Global a = Global a' ⇔ a = a') ∧
        ∀a a'. SetGlobal a = SetGlobal a' ⇔ a = a'
   
   [glob_op_Axiom]  Theorem
      
      ⊢ ∀f0 f1 f2 f3 f4. ∃fn.
          (∀a. fn (Global a) = f0 a) ∧ (∀a. fn (SetGlobal a) = f1 a) ∧
          fn AllocGlobal = f2 ∧ fn GlobalsPtr = f3 ∧ fn SetGlobalsPtr = f4
   
   [glob_op_case_cong]  Theorem
      
      ⊢ ∀M M' f f1 v v1 v2.
          M = M' ∧ (∀a. M' = Global a ⇒ f a = f' a) ∧
          (∀a. M' = SetGlobal a ⇒ f1 a = f1' a) ∧
          (M' = AllocGlobal ⇒ v = v') ∧ (M' = GlobalsPtr ⇒ v1 = v1') ∧
          (M' = SetGlobalsPtr ⇒ v2 = v2') ⇒
          glob_op_CASE M f f1 v v1 v2 = glob_op_CASE M' f' f1' v' v1' v2'
   
   [glob_op_case_eq]  Theorem
      
      ⊢ glob_op_CASE x f f1 v v1 v2 = v' ⇔
        (∃n. x = Global n ∧ f n = v') ∨ (∃n. x = SetGlobal n ∧ f1 n = v') ∨
        x = AllocGlobal ∧ v = v' ∨ x = GlobalsPtr ∧ v1 = v' ∨
        x = SetGlobalsPtr ∧ v2 = v'
   
   [glob_op_distinct]  Theorem
      
      ⊢ (∀a' a. Global a ≠ SetGlobal a') ∧ (∀a. Global a ≠ AllocGlobal) ∧
        (∀a. Global a ≠ GlobalsPtr) ∧ (∀a. Global a ≠ SetGlobalsPtr) ∧
        (∀a. SetGlobal a ≠ AllocGlobal) ∧ (∀a. SetGlobal a ≠ GlobalsPtr) ∧
        (∀a. SetGlobal a ≠ SetGlobalsPtr) ∧ AllocGlobal ≠ GlobalsPtr ∧
        AllocGlobal ≠ SetGlobalsPtr ∧ GlobalsPtr ≠ SetGlobalsPtr
   
   [glob_op_induction]  Theorem
      
      ⊢ ∀P. (∀n. P (Global n)) ∧ (∀n. P (SetGlobal n)) ∧ P AllocGlobal ∧
            P GlobalsPtr ∧ P SetGlobalsPtr ⇒
            ∀g. P g
   
   [glob_op_nchotomy]  Theorem
      
      ⊢ ∀gg.
          (∃n. gg = Global n) ∨ (∃n. gg = SetGlobal n) ∨ gg = AllocGlobal ∨
          gg = GlobalsPtr ∨ gg = SetGlobalsPtr
   
   [has_install_def]  Theorem
      
      ⊢ (∀t n. has_install (Var t n) ⇔ F) ∧
        (∀t e3 e2 e1.
           has_install (If t e1 e2 e3) ⇔
           has_install e1 ∨ has_install e2 ∨ has_install e3) ∧
        (∀t es e.
           has_install (Let t es e) ⇔ has_install e ∨ has_install_list es) ∧
        (∀t p es.
           has_install (Op t p es) ⇔ p = Install ∨ has_install_list es) ∧
        (∀t e. has_install (Raise t e) ⇔ has_install e) ∧
        (∀t e. has_install (Tick t e) ⇔ has_install e) ∧
        (∀v3 v2 v1 v0 e. has_install (Fn v0 v1 v2 v3 e) ⇔ has_install e) ∧
        (∀t e2 e1.
           has_install (Handle t e1 e2) ⇔ has_install e1 ∨ has_install e2) ∧
        (∀v6 v5 v4 es. has_install (Call v4 v5 v6 es) ⇔ has_install_list es) ∧
        (∀v8 v7 es e.
           has_install (App v7 v8 e es) ⇔
           has_install e ∨ has_install_list es) ∧
        (∀v9 v11 v10 fns e.
           has_install (Letrec v9 v10 v11 fns e) ⇔
           has_install_list (MAP SND fns) ∨ has_install e) ∧
        (has_install_list [] ⇔ F) ∧
        ∀xs x.
          has_install_list (x::xs) ⇔ has_install x ∨ has_install_list xs
   
   [has_install_ind]  Theorem
      
      ⊢ ∀P0 P1.
          (∀t n. P0 (Var t n)) ∧
          (∀t e1 e2 e3. P0 e1 ∧ P0 e2 ∧ P0 e3 ⇒ P0 (If t e1 e2 e3)) ∧
          (∀t es e. P0 e ∧ P1 es ⇒ P0 (Let t es e)) ∧
          (∀t p es. P1 es ⇒ P0 (Op t p es)) ∧
          (∀t e. P0 e ⇒ P0 (Raise t e)) ∧ (∀t e. P0 e ⇒ P0 (Tick t e)) ∧
          (∀v0 v1 v2 v3 e. P0 e ⇒ P0 (Fn v0 v1 v2 v3 e)) ∧
          (∀t e1 e2. P0 e1 ∧ P0 e2 ⇒ P0 (Handle t e1 e2)) ∧
          (∀v4 v5 v6 es. P1 es ⇒ P0 (Call v4 v5 v6 es)) ∧
          (∀v7 v8 e es. P0 e ∧ P1 es ⇒ P0 (App v7 v8 e es)) ∧
          (∀v9 v10 v11 fns e.
             P0 e ∧ P1 (MAP SND fns) ⇒ P0 (Letrec v9 v10 v11 fns e)) ∧
          P1 [] ∧ (∀x xs. P0 x ∧ P1 xs ⇒ P1 (x::xs)) ⇒
          (∀v0. P0 v0) ∧ ∀v0. P1 v0
   
   [int_op_11]  Theorem
      
      ⊢ (∀a a'. Const a = Const a' ⇔ a = a') ∧
        ∀a a'. LessConstSmall a = LessConstSmall a' ⇔ a = a'
   
   [int_op_Axiom]  Theorem
      
      ⊢ ∀f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10. ∃fn.
          (∀a. fn (Const a) = f0 a) ∧ fn Add = f1 ∧ fn Sub = f2 ∧
          fn Mult = f3 ∧ fn Div = f4 ∧ fn Mod = f5 ∧ fn Less = f6 ∧
          fn LessEq = f7 ∧ fn Greater = f8 ∧ fn GreaterEq = f9 ∧
          ∀a. fn (LessConstSmall a) = f10 a
   
   [int_op_case_cong]  Theorem
      
      ⊢ ∀M M' f v v1 v2 v3 v4 v5 v6 v7 v8 f1.
          M = M' ∧ (∀a. M' = Const a ⇒ f a = f' a) ∧ (M' = Add ⇒ v = v') ∧
          (M' = Sub ⇒ v1 = v1') ∧ (M' = Mult ⇒ v2 = v2') ∧
          (M' = Div ⇒ v3 = v3') ∧ (M' = Mod ⇒ v4 = v4') ∧
          (M' = Less ⇒ v5 = v5') ∧ (M' = LessEq ⇒ v6 = v6') ∧
          (M' = Greater ⇒ v7 = v7') ∧ (M' = GreaterEq ⇒ v8 = v8') ∧
          (∀a. M' = LessConstSmall a ⇒ f1 a = f1' a) ⇒
          int_op_CASE M f v v1 v2 v3 v4 v5 v6 v7 v8 f1 =
          int_op_CASE M' f' v' v1' v2' v3' v4' v5' v6' v7' v8' f1'
   
   [int_op_case_eq]  Theorem
      
      ⊢ int_op_CASE x f v v1 v2 v3 v4 v5 v6 v7 v8 f1 = v' ⇔
        (∃i. x = Const i ∧ f i = v') ∨ x = Add ∧ v = v' ∨
        x = Sub ∧ v1 = v' ∨ x = Mult ∧ v2 = v' ∨ x = Div ∧ v3 = v' ∨
        x = Mod ∧ v4 = v' ∨ x = Less ∧ v5 = v' ∨ x = LessEq ∧ v6 = v' ∨
        x = Greater ∧ v7 = v' ∨ x = GreaterEq ∧ v8 = v' ∨
        ∃n. x = LessConstSmall n ∧ f1 n = v'
   
   [int_op_distinct]  Theorem
      
      ⊢ (∀a. Const a ≠ Add) ∧ (∀a. Const a ≠ Sub) ∧ (∀a. Const a ≠ Mult) ∧
        (∀a. Const a ≠ Div) ∧ (∀a. Const a ≠ Mod) ∧ (∀a. Const a ≠ Less) ∧
        (∀a. Const a ≠ LessEq) ∧ (∀a. Const a ≠ Greater) ∧
        (∀a. Const a ≠ GreaterEq) ∧ (∀a' a. Const a ≠ LessConstSmall a') ∧
        Add ≠ Sub ∧ Add ≠ Mult ∧ Add ≠ Div ∧ Add ≠ Mod ∧ Add ≠ Less ∧
        Add ≠ LessEq ∧ Add ≠ Greater ∧ Add ≠ GreaterEq ∧
        (∀a. Add ≠ LessConstSmall a) ∧ Sub ≠ Mult ∧ Sub ≠ Div ∧ Sub ≠ Mod ∧
        Sub ≠ Less ∧ Sub ≠ LessEq ∧ Sub ≠ Greater ∧ Sub ≠ GreaterEq ∧
        (∀a. Sub ≠ LessConstSmall a) ∧ Mult ≠ Div ∧ Mult ≠ Mod ∧
        Mult ≠ Less ∧ Mult ≠ LessEq ∧ Mult ≠ Greater ∧ Mult ≠ GreaterEq ∧
        (∀a. Mult ≠ LessConstSmall a) ∧ Div ≠ Mod ∧ Div ≠ Less ∧
        Div ≠ LessEq ∧ Div ≠ Greater ∧ Div ≠ GreaterEq ∧
        (∀a. Div ≠ LessConstSmall a) ∧ Mod ≠ Less ∧ Mod ≠ LessEq ∧
        Mod ≠ Greater ∧ Mod ≠ GreaterEq ∧ (∀a. Mod ≠ LessConstSmall a) ∧
        Less ≠ LessEq ∧ Less ≠ Greater ∧ Less ≠ GreaterEq ∧
        (∀a. Less ≠ LessConstSmall a) ∧ LessEq ≠ Greater ∧
        LessEq ≠ GreaterEq ∧ (∀a. LessEq ≠ LessConstSmall a) ∧
        Greater ≠ GreaterEq ∧ (∀a. Greater ≠ LessConstSmall a) ∧
        ∀a. GreaterEq ≠ LessConstSmall a
   
   [int_op_induction]  Theorem
      
      ⊢ ∀P. (∀i. P (Const i)) ∧ P Add ∧ P Sub ∧ P Mult ∧ P Div ∧ P Mod ∧
            P Less ∧ P LessEq ∧ P Greater ∧ P GreaterEq ∧
            (∀n. P (LessConstSmall n)) ⇒
            ∀i. P i
   
   [int_op_nchotomy]  Theorem
      
      ⊢ ∀ii.
          (∃i. ii = Const i) ∨ ii = Add ∨ ii = Sub ∨ ii = Mult ∨ ii = Div ∨
          ii = Mod ∨ ii = Less ∨ ii = LessEq ∨ ii = Greater ∨
          ii = GreaterEq ∨ ∃n. ii = LessConstSmall n
   
   [mem_op_11]  Theorem
      
      ⊢ (∀a a'. RefByte a = RefByte a' ⇔ (a ⇔ a')) ∧
        (∀a a'. CopyByte a = CopyByte a' ⇔ (a ⇔ a')) ∧
        ∀a a'. BoundsCheckByte a = BoundsCheckByte a' ⇔ (a ⇔ a')
   
   [mem_op_Axiom]  Theorem
      
      ⊢ ∀f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18.
            ∃fn.
          fn Ref = f0 ∧ fn Update = f1 ∧ fn El = f2 ∧ fn Length = f3 ∧
          fn LengthByte = f4 ∧ (∀a. fn (RefByte a) = f5 a) ∧
          fn RefArray = f6 ∧ fn DerefByte = f7 ∧ fn UpdateByte = f8 ∧
          fn ConcatByteVec = f9 ∧ (∀a. fn (CopyByte a) = f10 a) ∧
          fn FromListByte = f11 ∧ fn ToListByte = f12 ∧
          fn LengthByteVec = f13 ∧ fn DerefByteVec = f14 ∧
          fn XorByte = f15 ∧ fn BoundsCheckArray = f16 ∧
          (∀a. fn (BoundsCheckByte a) = f17 a) ∧ fn ConfigGC = f18
   
   [mem_op_case_cong]  Theorem
      
      ⊢ ∀M M' v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14 f2 v15.
          M = M' ∧ (M' = Ref ⇒ v = v') ∧ (M' = Update ⇒ v1 = v1') ∧
          (M' = El ⇒ v2 = v2') ∧ (M' = Length ⇒ v3 = v3') ∧
          (M' = LengthByte ⇒ v4 = v4') ∧
          (∀a. M' = RefByte a ⇒ f a = f' a) ∧ (M' = RefArray ⇒ v5 = v5') ∧
          (M' = DerefByte ⇒ v6 = v6') ∧ (M' = UpdateByte ⇒ v7 = v7') ∧
          (M' = ConcatByteVec ⇒ v8 = v8') ∧
          (∀a. M' = CopyByte a ⇒ f1 a = f1' a) ∧
          (M' = FromListByte ⇒ v9 = v9') ∧ (M' = ToListByte ⇒ v10 = v10') ∧
          (M' = LengthByteVec ⇒ v11 = v11') ∧
          (M' = DerefByteVec ⇒ v12 = v12') ∧ (M' = XorByte ⇒ v13 = v13') ∧
          (M' = BoundsCheckArray ⇒ v14 = v14') ∧
          (∀a. M' = BoundsCheckByte a ⇒ f2 a = f2' a) ∧
          (M' = ConfigGC ⇒ v15 = v15') ⇒
          mem_op_CASE M v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13
            v14 f2 v15 =
          mem_op_CASE M' v' v1' v2' v3' v4' f' v5' v6' v7' v8' f1' v9' v10'
            v11' v12' v13' v14' f2' v15'
   
   [mem_op_case_eq]  Theorem
      
      ⊢ mem_op_CASE x v v1 v2 v3 v4 f v5 v6 v7 v8 f1 v9 v10 v11 v12 v13 v14
          f2 v15 = v' ⇔
        x = Ref ∧ v = v' ∨ x = Update ∧ v1 = v' ∨ x = El ∧ v2 = v' ∨
        x = Length ∧ v3 = v' ∨ x = LengthByte ∧ v4 = v' ∨
        (∃b. x = RefByte b ∧ f b = v') ∨ x = RefArray ∧ v5 = v' ∨
        x = DerefByte ∧ v6 = v' ∨ x = UpdateByte ∧ v7 = v' ∨
        x = ConcatByteVec ∧ v8 = v' ∨ (∃b. x = CopyByte b ∧ f1 b = v') ∨
        x = FromListByte ∧ v9 = v' ∨ x = ToListByte ∧ v10 = v' ∨
        x = LengthByteVec ∧ v11 = v' ∨ x = DerefByteVec ∧ v12 = v' ∨
        x = XorByte ∧ v13 = v' ∨ x = BoundsCheckArray ∧ v14 = v' ∨
        (∃b. x = BoundsCheckByte b ∧ f2 b = v') ∨ x = ConfigGC ∧ v15 = v'
   
   [mem_op_distinct]  Theorem
      
      ⊢ Ref ≠ Update ∧ Ref ≠ El ∧ Ref ≠ Length ∧ Ref ≠ LengthByte ∧
        (∀a. Ref ≠ RefByte a) ∧ Ref ≠ RefArray ∧ Ref ≠ DerefByte ∧
        Ref ≠ UpdateByte ∧ Ref ≠ ConcatByteVec ∧ (∀a. Ref ≠ CopyByte a) ∧
        Ref ≠ FromListByte ∧ Ref ≠ ToListByte ∧ Ref ≠ LengthByteVec ∧
        Ref ≠ DerefByteVec ∧ Ref ≠ XorByte ∧ Ref ≠ BoundsCheckArray ∧
        (∀a. Ref ≠ BoundsCheckByte a) ∧ Ref ≠ ConfigGC ∧ Update ≠ El ∧
        Update ≠ Length ∧ Update ≠ LengthByte ∧ (∀a. Update ≠ RefByte a) ∧
        Update ≠ RefArray ∧ Update ≠ DerefByte ∧ Update ≠ UpdateByte ∧
        Update ≠ ConcatByteVec ∧ (∀a. Update ≠ CopyByte a) ∧
        Update ≠ FromListByte ∧ Update ≠ ToListByte ∧
        Update ≠ LengthByteVec ∧ Update ≠ DerefByteVec ∧ Update ≠ XorByte ∧
        Update ≠ BoundsCheckArray ∧ (∀a. Update ≠ BoundsCheckByte a) ∧
        Update ≠ ConfigGC ∧ El ≠ Length ∧ El ≠ LengthByte ∧
        (∀a. El ≠ RefByte a) ∧ El ≠ RefArray ∧ El ≠ DerefByte ∧
        El ≠ UpdateByte ∧ El ≠ ConcatByteVec ∧ (∀a. El ≠ CopyByte a) ∧
        El ≠ FromListByte ∧ El ≠ ToListByte ∧ El ≠ LengthByteVec ∧
        El ≠ DerefByteVec ∧ El ≠ XorByte ∧ El ≠ BoundsCheckArray ∧
        (∀a. El ≠ BoundsCheckByte a) ∧ El ≠ ConfigGC ∧
        Length ≠ LengthByte ∧ (∀a. Length ≠ RefByte a) ∧
        Length ≠ RefArray ∧ Length ≠ DerefByte ∧ Length ≠ UpdateByte ∧
        Length ≠ ConcatByteVec ∧ (∀a. Length ≠ CopyByte a) ∧
        Length ≠ FromListByte ∧ Length ≠ ToListByte ∧
        Length ≠ LengthByteVec ∧ Length ≠ DerefByteVec ∧ Length ≠ XorByte ∧
        Length ≠ BoundsCheckArray ∧ (∀a. Length ≠ BoundsCheckByte a) ∧
        Length ≠ ConfigGC ∧ (∀a. LengthByte ≠ RefByte a) ∧
        LengthByte ≠ RefArray ∧ LengthByte ≠ DerefByte ∧
        LengthByte ≠ UpdateByte ∧ LengthByte ≠ ConcatByteVec ∧
        (∀a. LengthByte ≠ CopyByte a) ∧ LengthByte ≠ FromListByte ∧
        LengthByte ≠ ToListByte ∧ LengthByte ≠ LengthByteVec ∧
        LengthByte ≠ DerefByteVec ∧ LengthByte ≠ XorByte ∧
        LengthByte ≠ BoundsCheckArray ∧
        (∀a. LengthByte ≠ BoundsCheckByte a) ∧ LengthByte ≠ ConfigGC ∧
        (∀a. RefByte a ≠ RefArray) ∧ (∀a. RefByte a ≠ DerefByte) ∧
        (∀a. RefByte a ≠ UpdateByte) ∧ (∀a. RefByte a ≠ ConcatByteVec) ∧
        (∀a' a. RefByte a ≠ CopyByte a') ∧ (∀a. RefByte a ≠ FromListByte) ∧
        (∀a. RefByte a ≠ ToListByte) ∧ (∀a. RefByte a ≠ LengthByteVec) ∧
        (∀a. RefByte a ≠ DerefByteVec) ∧ (∀a. RefByte a ≠ XorByte) ∧
        (∀a. RefByte a ≠ BoundsCheckArray) ∧
        (∀a' a. RefByte a ≠ BoundsCheckByte a') ∧
        (∀a. RefByte a ≠ ConfigGC) ∧ RefArray ≠ DerefByte ∧
        RefArray ≠ UpdateByte ∧ RefArray ≠ ConcatByteVec ∧
        (∀a. RefArray ≠ CopyByte a) ∧ RefArray ≠ FromListByte ∧
        RefArray ≠ ToListByte ∧ RefArray ≠ LengthByteVec ∧
        RefArray ≠ DerefByteVec ∧ RefArray ≠ XorByte ∧
        RefArray ≠ BoundsCheckArray ∧ (∀a. RefArray ≠ BoundsCheckByte a) ∧
        RefArray ≠ ConfigGC ∧ DerefByte ≠ UpdateByte ∧
        DerefByte ≠ ConcatByteVec ∧ (∀a. DerefByte ≠ CopyByte a) ∧
        DerefByte ≠ FromListByte ∧ DerefByte ≠ ToListByte ∧
        DerefByte ≠ LengthByteVec ∧ DerefByte ≠ DerefByteVec ∧
        DerefByte ≠ XorByte ∧ DerefByte ≠ BoundsCheckArray ∧
        (∀a. DerefByte ≠ BoundsCheckByte a) ∧ DerefByte ≠ ConfigGC ∧
        UpdateByte ≠ ConcatByteVec ∧ (∀a. UpdateByte ≠ CopyByte a) ∧
        UpdateByte ≠ FromListByte ∧ UpdateByte ≠ ToListByte ∧
        UpdateByte ≠ LengthByteVec ∧ UpdateByte ≠ DerefByteVec ∧
        UpdateByte ≠ XorByte ∧ UpdateByte ≠ BoundsCheckArray ∧
        (∀a. UpdateByte ≠ BoundsCheckByte a) ∧ UpdateByte ≠ ConfigGC ∧
        (∀a. ConcatByteVec ≠ CopyByte a) ∧ ConcatByteVec ≠ FromListByte ∧
        ConcatByteVec ≠ ToListByte ∧ ConcatByteVec ≠ LengthByteVec ∧
        ConcatByteVec ≠ DerefByteVec ∧ ConcatByteVec ≠ XorByte ∧
        ConcatByteVec ≠ BoundsCheckArray ∧
        (∀a. ConcatByteVec ≠ BoundsCheckByte a) ∧
        ConcatByteVec ≠ ConfigGC ∧ (∀a. CopyByte a ≠ FromListByte) ∧
        (∀a. CopyByte a ≠ ToListByte) ∧ (∀a. CopyByte a ≠ LengthByteVec) ∧
        (∀a. CopyByte a ≠ DerefByteVec) ∧ (∀a. CopyByte a ≠ XorByte) ∧
        (∀a. CopyByte a ≠ BoundsCheckArray) ∧
        (∀a' a. CopyByte a ≠ BoundsCheckByte a') ∧
        (∀a. CopyByte a ≠ ConfigGC) ∧ FromListByte ≠ ToListByte ∧
        FromListByte ≠ LengthByteVec ∧ FromListByte ≠ DerefByteVec ∧
        FromListByte ≠ XorByte ∧ FromListByte ≠ BoundsCheckArray ∧
        (∀a. FromListByte ≠ BoundsCheckByte a) ∧ FromListByte ≠ ConfigGC ∧
        ToListByte ≠ LengthByteVec ∧ ToListByte ≠ DerefByteVec ∧
        ToListByte ≠ XorByte ∧ ToListByte ≠ BoundsCheckArray ∧
        (∀a. ToListByte ≠ BoundsCheckByte a) ∧ ToListByte ≠ ConfigGC ∧
        LengthByteVec ≠ DerefByteVec ∧ LengthByteVec ≠ XorByte ∧
        LengthByteVec ≠ BoundsCheckArray ∧
        (∀a. LengthByteVec ≠ BoundsCheckByte a) ∧
        LengthByteVec ≠ ConfigGC ∧ DerefByteVec ≠ XorByte ∧
        DerefByteVec ≠ BoundsCheckArray ∧
        (∀a. DerefByteVec ≠ BoundsCheckByte a) ∧ DerefByteVec ≠ ConfigGC ∧
        XorByte ≠ BoundsCheckArray ∧ (∀a. XorByte ≠ BoundsCheckByte a) ∧
        XorByte ≠ ConfigGC ∧ (∀a. BoundsCheckArray ≠ BoundsCheckByte a) ∧
        BoundsCheckArray ≠ ConfigGC ∧ ∀a. BoundsCheckByte a ≠ ConfigGC
   
   [mem_op_induction]  Theorem
      
      ⊢ ∀P. P Ref ∧ P Update ∧ P El ∧ P Length ∧ P LengthByte ∧
            (∀b. P (RefByte b)) ∧ P RefArray ∧ P DerefByte ∧ P UpdateByte ∧
            P ConcatByteVec ∧ (∀b. P (CopyByte b)) ∧ P FromListByte ∧
            P ToListByte ∧ P LengthByteVec ∧ P DerefByteVec ∧ P XorByte ∧
            P BoundsCheckArray ∧ (∀b. P (BoundsCheckByte b)) ∧ P ConfigGC ⇒
            ∀m. P m
   
   [mem_op_nchotomy]  Theorem
      
      ⊢ ∀mm.
          mm = Ref ∨ mm = Update ∨ mm = El ∨ mm = Length ∨
          mm = LengthByte ∨ (∃b. mm = RefByte b) ∨ mm = RefArray ∨
          mm = DerefByte ∨ mm = UpdateByte ∨ mm = ConcatByteVec ∨
          (∃b. mm = CopyByte b) ∨ mm = FromListByte ∨ mm = ToListByte ∨
          mm = LengthByteVec ∨ mm = DerefByteVec ∨ mm = XorByte ∨
          mm = BoundsCheckArray ∨ (∃b. mm = BoundsCheckByte b) ∨
          mm = ConfigGC
   
   [op_11]  Theorem
      
      ⊢ (∀a a'. Label a = Label a' ⇔ a = a') ∧
        (∀a a'. FFI a = FFI a' ⇔ a = a') ∧
        (∀a a'. IntOp a = IntOp a' ⇔ a = a') ∧
        (∀a a'. WordOp a = WordOp a' ⇔ a = a') ∧
        (∀a a'. BlockOp a = BlockOp a' ⇔ a = a') ∧
        (∀a a'. GlobOp a = GlobOp a' ⇔ a = a') ∧
        (∀a a'. MemOp a = MemOp a' ⇔ a = a') ∧
        ∀a a'. ThunkOp a = ThunkOp a' ⇔ a = a'
   
   [op_Axiom]  Theorem
      
      ⊢ ∀f0 f1 f2 f3 f4 f5 f6 f7 f8. ∃fn.
          (∀a. fn (Label a) = f0 a) ∧ (∀a. fn (FFI a) = f1 a) ∧
          (∀a. fn (IntOp a) = f2 a) ∧ (∀a. fn (WordOp a) = f3 a) ∧
          (∀a. fn (BlockOp a) = f4 a) ∧ (∀a. fn (GlobOp a) = f5 a) ∧
          (∀a. fn (MemOp a) = f6 a) ∧ fn Install = f7 ∧
          ∀a. fn (ThunkOp a) = f8 a
   
   [op_case_cong]  Theorem
      
      ⊢ ∀M M' f f1 f2 f3 f4 f5 f6 v f7.
          M = M' ∧ (∀a. M' = Label a ⇒ f a = f' a) ∧
          (∀a. M' = FFI a ⇒ f1 a = f1' a) ∧
          (∀a. M' = IntOp a ⇒ f2 a = f2' a) ∧
          (∀a. M' = WordOp a ⇒ f3 a = f3' a) ∧
          (∀a. M' = BlockOp a ⇒ f4 a = f4' a) ∧
          (∀a. M' = GlobOp a ⇒ f5 a = f5' a) ∧
          (∀a. M' = MemOp a ⇒ f6 a = f6' a) ∧ (M' = Install ⇒ v = v') ∧
          (∀a. M' = ThunkOp a ⇒ f7 a = f7' a) ⇒
          op_CASE M f f1 f2 f3 f4 f5 f6 v f7 =
          op_CASE M' f' f1' f2' f3' f4' f5' f6' v' f7'
   
   [op_case_eq]  Theorem
      
      ⊢ op_CASE x f f1 f2 f3 f4 f5 f6 v f7 = v' ⇔
        (∃n. x = Label n ∧ f n = v') ∨ (∃m. x = FFI m ∧ f1 m = v') ∨
        (∃i. x = IntOp i ∧ f2 i = v') ∨ (∃w. x = WordOp w ∧ f3 w = v') ∨
        (∃b. x = BlockOp b ∧ f4 b = v') ∨ (∃g. x = GlobOp g ∧ f5 g = v') ∨
        (∃m. x = MemOp m ∧ f6 m = v') ∨ x = Install ∧ v = v' ∨
        ∃t. x = ThunkOp t ∧ f7 t = v'
   
   [op_distinct]  Theorem
      
      ⊢ (∀a' a. Label a ≠ FFI a') ∧ (∀a' a. Label a ≠ IntOp a') ∧
        (∀a' a. Label a ≠ WordOp a') ∧ (∀a' a. Label a ≠ BlockOp a') ∧
        (∀a' a. Label a ≠ GlobOp a') ∧ (∀a' a. Label a ≠ MemOp a') ∧
        (∀a. Label a ≠ Install) ∧ (∀a' a. Label a ≠ ThunkOp a') ∧
        (∀a' a. FFI a ≠ IntOp a') ∧ (∀a' a. FFI a ≠ WordOp a') ∧
        (∀a' a. FFI a ≠ BlockOp a') ∧ (∀a' a. FFI a ≠ GlobOp a') ∧
        (∀a' a. FFI a ≠ MemOp a') ∧ (∀a. FFI a ≠ Install) ∧
        (∀a' a. FFI a ≠ ThunkOp a') ∧ (∀a' a. IntOp a ≠ WordOp a') ∧
        (∀a' a. IntOp a ≠ BlockOp a') ∧ (∀a' a. IntOp a ≠ GlobOp a') ∧
        (∀a' a. IntOp a ≠ MemOp a') ∧ (∀a. IntOp a ≠ Install) ∧
        (∀a' a. IntOp a ≠ ThunkOp a') ∧ (∀a' a. WordOp a ≠ BlockOp a') ∧
        (∀a' a. WordOp a ≠ GlobOp a') ∧ (∀a' a. WordOp a ≠ MemOp a') ∧
        (∀a. WordOp a ≠ Install) ∧ (∀a' a. WordOp a ≠ ThunkOp a') ∧
        (∀a' a. BlockOp a ≠ GlobOp a') ∧ (∀a' a. BlockOp a ≠ MemOp a') ∧
        (∀a. BlockOp a ≠ Install) ∧ (∀a' a. BlockOp a ≠ ThunkOp a') ∧
        (∀a' a. GlobOp a ≠ MemOp a') ∧ (∀a. GlobOp a ≠ Install) ∧
        (∀a' a. GlobOp a ≠ ThunkOp a') ∧ (∀a. MemOp a ≠ Install) ∧
        (∀a' a. MemOp a ≠ ThunkOp a') ∧ ∀a. Install ≠ ThunkOp a
   
   [op_induction]  Theorem
      
      ⊢ ∀P. (∀n. P (Label n)) ∧ (∀m. P (FFI m)) ∧ (∀i. P (IntOp i)) ∧
            (∀w. P (WordOp w)) ∧ (∀b. P (BlockOp b)) ∧ (∀g. P (GlobOp g)) ∧
            (∀m. P (MemOp m)) ∧ P Install ∧ (∀t. P (ThunkOp t)) ⇒
            ∀ $o. P $o
   
   [op_nchotomy]  Theorem
      
      ⊢ ∀oo.
          (∃n. oo = Label n) ∨ (∃m. oo = FFI m) ∨ (∃i. oo = IntOp i) ∨
          (∃w. oo = WordOp w) ∨ (∃b. oo = BlockOp b) ∨
          (∃g. oo = GlobOp g) ∨ (∃m. oo = MemOp m) ∨ oo = Install ∨
          ∃t. oo = ThunkOp t
   
   [pure_def]  Theorem
      
      ⊢ (∀v1 v0. pure (Var v0 v1) ⇔ T) ∧
        (∀v2 e3 e2 e1. pure (If v2 e1 e2 e3) ⇔ pure e1 ∧ pure e2 ∧ pure e3) ∧
        (∀v3 es e2. pure (Let v3 es e2) ⇔ EVERY (λa. pure a) es ∧ pure e2) ∧
        (∀v5 v4. pure (Raise v4 v5) ⇔ F) ∧
        (∀v6 e2 e1. pure (Handle v6 e1 e2) ⇔ pure e1) ∧
        (∀v8 v7. pure (Tick v7 v8) ⇔ F) ∧
        (∀v9 v12 v11 v10. pure (Call v9 v10 v11 v12) ⇔ F) ∧
        (∀v16 v15 v14 v13. pure (App v13 v14 v15 v16) ⇔ F) ∧
        (∀v21 v20 v19 v18 v17. pure (Fn v17 v18 v19 v20 v21) ⇔ T) ∧
        (∀x v25 v24 v23 v22. pure (Letrec v22 v23 v24 v25 x) ⇔ pure x) ∧
        ∀v26 opn es.
          pure (Op v26 opn es) ⇔ EVERY (λa. pure a) es ∧ pure_op opn
   
   [pure_ind]  Theorem
      
      ⊢ ∀P. (∀v0 v1. P (Var v0 v1)) ∧
            (∀v2 e1 e2 e3. P e1 ∧ P e2 ∧ P e3 ⇒ P (If v2 e1 e2 e3)) ∧
            (∀v3 es e2. (∀a. MEM a es ⇒ P a) ∧ P e2 ⇒ P (Let v3 es e2)) ∧
            (∀v4 v5. P (Raise v4 v5)) ∧
            (∀v6 e1 e2. P e1 ⇒ P (Handle v6 e1 e2)) ∧
            (∀v7 v8. P (Tick v7 v8)) ∧
            (∀v9 v10 v11 v12. P (Call v9 v10 v11 v12)) ∧
            (∀v13 v14 v15 v16. P (App v13 v14 v15 v16)) ∧
            (∀v17 v18 v19 v20 v21. P (Fn v17 v18 v19 v20 v21)) ∧
            (∀v22 v23 v24 v25 x. P x ⇒ P (Letrec v22 v23 v24 v25 x)) ∧
            (∀v26 opn es. (∀a. MEM a es ⇒ P a) ⇒ P (Op v26 opn es)) ⇒
            ∀v. P v
   
   [word_op_11]  Theorem
      
      ⊢ (∀a0 a1 a0' a1'.
           WordOpw a0 a1 = WordOpw a0' a1' ⇔ a0 = a0' ∧ a1 = a1') ∧
        (∀a0 a1 a2 a0' a1' a2'.
           WordShift a0 a1 a2 = WordShift a0' a1' a2' ⇔
           a0 = a0' ∧ a1 = a1' ∧ a2 = a2') ∧
        (∀a0 a1 a0' a1'.
           WordTest a0 a1 = WordTest a0' a1' ⇔ a0 = a0' ∧ a1 = a1') ∧
        (∀a a'. WordFromWord a = WordFromWord a' ⇔ (a ⇔ a')) ∧
        (∀a a'. FP_cmp a = FP_cmp a' ⇔ a = a') ∧
        (∀a a'. FP_uop a = FP_uop a' ⇔ a = a') ∧
        (∀a a'. FP_bop a = FP_bop a' ⇔ a = a') ∧
        ∀a a'. FP_top a = FP_top a' ⇔ a = a'
   
   [word_op_Axiom]  Theorem
      
      ⊢ ∀f0 f1 f2 f3 f4 f5 f6 f7 f8 f9. ∃fn.
          (∀a0 a1. fn (WordOpw a0 a1) = f0 a0 a1) ∧
          (∀a0 a1 a2. fn (WordShift a0 a1 a2) = f1 a0 a1 a2) ∧
          (∀a0 a1. fn (WordTest a0 a1) = f2 a0 a1) ∧ fn WordFromInt = f3 ∧
          fn WordToInt = f4 ∧ (∀a. fn (WordFromWord a) = f5 a) ∧
          (∀a. fn (FP_cmp a) = f6 a) ∧ (∀a. fn (FP_uop a) = f7 a) ∧
          (∀a. fn (FP_bop a) = f8 a) ∧ ∀a. fn (FP_top a) = f9 a
   
   [word_op_case_cong]  Theorem
      
      ⊢ ∀M M' f f1 f2 v v1 f3 f4 f5 f6 f7.
          M = M' ∧ (∀a0 a1. M' = WordOpw a0 a1 ⇒ f a0 a1 = f' a0 a1) ∧
          (∀a0 a1 a2. M' = WordShift a0 a1 a2 ⇒ f1 a0 a1 a2 = f1' a0 a1 a2) ∧
          (∀a0 a1. M' = WordTest a0 a1 ⇒ f2 a0 a1 = f2' a0 a1) ∧
          (M' = WordFromInt ⇒ v = v') ∧ (M' = WordToInt ⇒ v1 = v1') ∧
          (∀a. M' = WordFromWord a ⇒ f3 a = f3' a) ∧
          (∀a. M' = FP_cmp a ⇒ f4 a = f4' a) ∧
          (∀a. M' = FP_uop a ⇒ f5 a = f5' a) ∧
          (∀a. M' = FP_bop a ⇒ f6 a = f6' a) ∧
          (∀a. M' = FP_top a ⇒ f7 a = f7' a) ⇒
          word_op_CASE M f f1 f2 v v1 f3 f4 f5 f6 f7 =
          word_op_CASE M' f' f1' f2' v' v1' f3' f4' f5' f6' f7'
   
   [word_op_case_eq]  Theorem
      
      ⊢ word_op_CASE x f f1 f2 v v1 f3 f4 f5 f6 f7 = v' ⇔
        (∃w o'. x = WordOpw w o' ∧ f w o' = v') ∨
        (∃w s n. x = WordShift w s n ∧ f1 w s n = v') ∨
        (∃w t. x = WordTest w t ∧ f2 w t = v') ∨ x = WordFromInt ∧ v = v' ∨
        x = WordToInt ∧ v1 = v' ∨ (∃b. x = WordFromWord b ∧ f3 b = v') ∨
        (∃f'. x = FP_cmp f' ∧ f4 f' = v') ∨
        (∃f'. x = FP_uop f' ∧ f5 f' = v') ∨
        (∃f'. x = FP_bop f' ∧ f6 f' = v') ∨ ∃f'. x = FP_top f' ∧ f7 f' = v'
   
   [word_op_distinct]  Theorem
      
      ⊢ (∀a2 a1' a1 a0' a0. WordOpw a0 a1 ≠ WordShift a0' a1' a2) ∧
        (∀a1' a1 a0' a0. WordOpw a0 a1 ≠ WordTest a0' a1') ∧
        (∀a1 a0. WordOpw a0 a1 ≠ WordFromInt) ∧
        (∀a1 a0. WordOpw a0 a1 ≠ WordToInt) ∧
        (∀a1 a0 a. WordOpw a0 a1 ≠ WordFromWord a) ∧
        (∀a1 a0 a. WordOpw a0 a1 ≠ FP_cmp a) ∧
        (∀a1 a0 a. WordOpw a0 a1 ≠ FP_uop a) ∧
        (∀a1 a0 a. WordOpw a0 a1 ≠ FP_bop a) ∧
        (∀a1 a0 a. WordOpw a0 a1 ≠ FP_top a) ∧
        (∀a2 a1' a1 a0' a0. WordShift a0 a1 a2 ≠ WordTest a0' a1') ∧
        (∀a2 a1 a0. WordShift a0 a1 a2 ≠ WordFromInt) ∧
        (∀a2 a1 a0. WordShift a0 a1 a2 ≠ WordToInt) ∧
        (∀a2 a1 a0 a. WordShift a0 a1 a2 ≠ WordFromWord a) ∧
        (∀a2 a1 a0 a. WordShift a0 a1 a2 ≠ FP_cmp a) ∧
        (∀a2 a1 a0 a. WordShift a0 a1 a2 ≠ FP_uop a) ∧
        (∀a2 a1 a0 a. WordShift a0 a1 a2 ≠ FP_bop a) ∧
        (∀a2 a1 a0 a. WordShift a0 a1 a2 ≠ FP_top a) ∧
        (∀a1 a0. WordTest a0 a1 ≠ WordFromInt) ∧
        (∀a1 a0. WordTest a0 a1 ≠ WordToInt) ∧
        (∀a1 a0 a. WordTest a0 a1 ≠ WordFromWord a) ∧
        (∀a1 a0 a. WordTest a0 a1 ≠ FP_cmp a) ∧
        (∀a1 a0 a. WordTest a0 a1 ≠ FP_uop a) ∧
        (∀a1 a0 a. WordTest a0 a1 ≠ FP_bop a) ∧
        (∀a1 a0 a. WordTest a0 a1 ≠ FP_top a) ∧ WordFromInt ≠ WordToInt ∧
        (∀a. WordFromInt ≠ WordFromWord a) ∧ (∀a. WordFromInt ≠ FP_cmp a) ∧
        (∀a. WordFromInt ≠ FP_uop a) ∧ (∀a. WordFromInt ≠ FP_bop a) ∧
        (∀a. WordFromInt ≠ FP_top a) ∧ (∀a. WordToInt ≠ WordFromWord a) ∧
        (∀a. WordToInt ≠ FP_cmp a) ∧ (∀a. WordToInt ≠ FP_uop a) ∧
        (∀a. WordToInt ≠ FP_bop a) ∧ (∀a. WordToInt ≠ FP_top a) ∧
        (∀a' a. WordFromWord a ≠ FP_cmp a') ∧
        (∀a' a. WordFromWord a ≠ FP_uop a') ∧
        (∀a' a. WordFromWord a ≠ FP_bop a') ∧
        (∀a' a. WordFromWord a ≠ FP_top a') ∧
        (∀a' a. FP_cmp a ≠ FP_uop a') ∧ (∀a' a. FP_cmp a ≠ FP_bop a') ∧
        (∀a' a. FP_cmp a ≠ FP_top a') ∧ (∀a' a. FP_uop a ≠ FP_bop a') ∧
        (∀a' a. FP_uop a ≠ FP_top a') ∧ ∀a' a. FP_bop a ≠ FP_top a'
   
   [word_op_induction]  Theorem
      
      ⊢ ∀P. (∀w $o. P (WordOpw w $o)) ∧ (∀w s n. P (WordShift w s n)) ∧
            (∀w t. P (WordTest w t)) ∧ P WordFromInt ∧ P WordToInt ∧
            (∀b. P (WordFromWord b)) ∧ (∀f. P (FP_cmp f)) ∧
            (∀f. P (FP_uop f)) ∧ (∀f. P (FP_bop f)) ∧ (∀f. P (FP_top f)) ⇒
            ∀w. P w
   
   [word_op_nchotomy]  Theorem
      
      ⊢ ∀ww.
          (∃w $o. ww = WordOpw w $o) ∨ (∃w s n. ww = WordShift w s n) ∨
          (∃w t. ww = WordTest w t) ∨ ww = WordFromInt ∨ ww = WordToInt ∨
          (∃b. ww = WordFromWord b) ∨ (∃f. ww = FP_cmp f) ∨
          (∃f. ww = FP_uop f) ∨ (∃f. ww = FP_bop f) ∨ ∃f. ww = FP_top f
   
   
*)
end
