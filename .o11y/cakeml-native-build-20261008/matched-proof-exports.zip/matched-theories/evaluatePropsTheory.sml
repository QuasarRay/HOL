structure evaluatePropsTheory :> evaluatePropsTheory =
struct
  
  val _ = if !Globals.print_thy_loads
    then TextIO.print "Loading evaluatePropsTheory ... "
    else ()
  
  open Type Term Thm
  local open evaluateTheory semanticPrimitivesPropsTheory in end;
  
  structure TDB = struct
    val path =
      holpathdb.subst_pathvars "$(CAKEMLDIR)/semantics/proofs/evaluatePropsTheory.dat"
    val timestamp = HOLFileSys.modTime path
    val thydata = 
      TheoryReader.load_thydata {
        thyname = "evaluateProps",
        hash = "06bfd48b586c092a4c343aa6b20265b496fd298b",
        path = path
      }
    fun find s = #1 (valOf (Symtab.lookup thydata s))
  end
  val () = Theory.record_metadata
    "evaluateProps" {timestamp=TDB.timestamp, path=TDB.path}
  
  fun op same_type_trans _ = ()
  val op same_type_trans = TDB.find "same_type_trans"
  fun op same_type_sym _ = ()
  val op same_type_sym = TDB.find "same_type_sym"
  fun op result_rel_list_result _ = ()
  val op result_rel_list_result = TDB.find "result_rel_list_result"
  fun op pmatch_not_type_error_EQ _ = ()
  val op pmatch_not_type_error_EQ = TDB.find "pmatch_not_type_error_EQ"
  fun op pair_CASE_eq_forall _ = ()
  val op pair_CASE_eq_forall = TDB.find "pair_CASE_eq_forall"
  fun op list_result_inj _ = ()
  val op list_result_inj = TDB.find "list_result_inj"
  fun op list_result_eq_Rval _ = ()
  val op list_result_eq_Rval = TDB.find "list_result_eq_Rval"
  fun op list_result_eq_Rerr _ = ()
  val op list_result_eq_Rerr = TDB.find "list_result_eq_Rerr"
  fun op is_clock_io_mono_set_clock _ = ()
  val op is_clock_io_mono_set_clock = TDB.find "is_clock_io_mono_set_clock"
  fun op is_clock_io_mono_return _ = ()
  val op is_clock_io_mono_return = TDB.find "is_clock_io_mono_return"
  fun op is_clock_io_mono_option_case_safe _ = ()
  val op is_clock_io_mono_option_case_safe = TDB.find
    "is_clock_io_mono_option_case_safe"
  fun op is_clock_io_mono_minimal _ = ()
  val op is_clock_io_mono_minimal = TDB.find "is_clock_io_mono_minimal"
  fun op is_clock_io_mono_match_case_safe _ = ()
  val op is_clock_io_mono_match_case_safe = TDB.find
    "is_clock_io_mono_match_case_safe"
  fun op is_clock_io_mono_match_case_pair_safe _ = ()
  val op is_clock_io_mono_match_case_pair_safe = TDB.find
    "is_clock_io_mono_match_case_pair_safe"
  fun op is_clock_io_mono_if_safe _ = ()
  val op is_clock_io_mono_if_safe = TDB.find "is_clock_io_mono_if_safe"
  fun op is_clock_io_mono_extra_mono _ = ()
  val op is_clock_io_mono_extra_mono = TDB.find
    "is_clock_io_mono_extra_mono"
  fun op is_clock_io_mono_extra _ = ()
  val op is_clock_io_mono_extra = TDB.find "is_clock_io_mono_extra"
  fun op is_clock_io_mono_evaluate_decs _ = ()
  val op is_clock_io_mono_evaluate_decs = TDB.find
    "is_clock_io_mono_evaluate_decs"
  fun op is_clock_io_mono_evaluate _ = ()
  val op is_clock_io_mono_evaluate = TDB.find "is_clock_io_mono_evaluate"
  fun op is_clock_io_mono_err _ = ()
  val op is_clock_io_mono_err = TDB.find "is_clock_io_mono_err"
  fun op is_clock_io_mono_do_app_simple _ = ()
  val op is_clock_io_mono_do_app_simple = TDB.find
    "is_clock_io_mono_do_app_simple"
  fun op is_clock_io_mono_def _ = ()
  val op is_clock_io_mono_def = TDB.find "is_clock_io_mono_def"
  fun op is_clock_io_mono_cong _ = ()
  val op is_clock_io_mono_cong = TDB.find "is_clock_io_mono_cong"
  fun op is_clock_io_mono_check _ = ()
  val op is_clock_io_mono_check = TDB.find "is_clock_io_mono_check"
  fun op is_clock_io_mono_bind _ = ()
  val op is_clock_io_mono_bind = TDB.find "is_clock_io_mono_bind"
  fun op is_clock_io_mono_acc_safe _ = ()
  val op is_clock_io_mono_acc_safe = TDB.find "is_clock_io_mono_acc_safe"
  fun op io_events_mono_trans _ = ()
  val op io_events_mono_trans = TDB.find "io_events_mono_trans"
  fun op io_events_mono_refl _ = ()
  val op io_events_mono_refl = TDB.find "io_events_mono_refl"
  fun op io_events_mono_def _ = ()
  val op io_events_mono_def = TDB.find "io_events_mono_def"
  fun op io_events_mono_antisym _ = ()
  val op io_events_mono_antisym = TDB.find "io_events_mono_antisym"
  fun op evaluate_sing _ = ()
  val op evaluate_sing = TDB.find "evaluate_sing"
  fun op evaluate_set_next_stamps _ = ()
  val op evaluate_set_next_stamps = TDB.find "evaluate_set_next_stamps"
  fun op evaluate_set_init_clock _ = ()
  val op evaluate_set_init_clock = TDB.find "evaluate_set_init_clock"
  fun op evaluate_set_clock _ = ()
  val op evaluate_set_clock = TDB.find "evaluate_set_clock"
  fun op evaluate_refs_length_mono _ = ()
  val op evaluate_refs_length_mono = TDB.find "evaluate_refs_length_mono"
  fun op evaluate_nil _ = () val op evaluate_nil = TDB.find "evaluate_nil"
  fun op evaluate_next_type_stamp_mono _ = ()
  val op evaluate_next_type_stamp_mono = TDB.find
    "evaluate_next_type_stamp_mono"
  fun op evaluate_next_exn_stamp_mono _ = ()
  val op evaluate_next_exn_stamp_mono = TDB.find
    "evaluate_next_exn_stamp_mono"
  fun op evaluate_minimal_clock _ = ()
  val op evaluate_minimal_clock = TDB.find "evaluate_minimal_clock"
  fun op evaluate_match_minimal_clock _ = ()
  val op evaluate_match_minimal_clock = TDB.find
    "evaluate_match_minimal_clock"
  fun op evaluate_match_list_result _ = ()
  val op evaluate_match_list_result = TDB.find "evaluate_match_list_result"
  fun op evaluate_match_add_to_clock _ = ()
  val op evaluate_match_add_to_clock = TDB.find
    "evaluate_match_add_to_clock"
  fun op evaluate_length _ = ()
  val op evaluate_length = TDB.find "evaluate_length"
  fun op evaluate_io_events_mono_imp _ = ()
  val op evaluate_io_events_mono_imp = TDB.find
    "evaluate_io_events_mono_imp"
  fun op evaluate_io_events_mono _ = ()
  val op evaluate_io_events_mono = TDB.find "evaluate_io_events_mono"
  fun op evaluate_history_irrelevance _ = ()
  val op evaluate_history_irrelevance = TDB.find
    "evaluate_history_irrelevance"
  fun op evaluate_ffi_intro _ = ()
  val op evaluate_ffi_intro = TDB.find "evaluate_ffi_intro"
  fun op evaluate_ffi_etc_intro _ = ()
  val op evaluate_ffi_etc_intro = TDB.find "evaluate_ffi_etc_intro"
  fun op evaluate_decs_set_clock _ = ()
  val op evaluate_decs_set_clock = TDB.find "evaluate_decs_set_clock"
  fun op evaluate_decs_nil _ = ()
  val op evaluate_decs_nil = TDB.find "evaluate_decs_nil"
  fun op evaluate_decs_ffi_mono_clock _ = ()
  val op evaluate_decs_ffi_mono_clock = TDB.find
    "evaluate_decs_ffi_mono_clock"
  fun op evaluate_decs_cons _ = ()
  val op evaluate_decs_cons = TDB.find "evaluate_decs_cons"
  fun op evaluate_decs_clock_determ _ = ()
  val op evaluate_decs_clock_determ = TDB.find "evaluate_decs_clock_determ"
  fun op evaluate_decs_call_FFI_rel_imp _ = ()
  val op evaluate_decs_call_FFI_rel_imp = TDB.find
    "evaluate_decs_call_FFI_rel_imp"
  fun op evaluate_decs_append _ = ()
  val op evaluate_decs_append = TDB.find "evaluate_decs_append"
  fun op evaluate_decs_add_to_clock_io_events_mono _ = ()
  val op evaluate_decs_add_to_clock_io_events_mono = TDB.find
    "evaluate_decs_add_to_clock_io_events_mono"
  fun op evaluate_decs_add_to_clock _ = ()
  val op evaluate_decs_add_to_clock = TDB.find "evaluate_decs_add_to_clock"
  fun op evaluate_cons _ = ()
  val op evaluate_cons = TDB.find "evaluate_cons"
  fun op evaluate_case_eqs _ = ()
  val op evaluate_case_eqs = TDB.find "evaluate_case_eqs"
  fun op evaluate_call_FFI_rel_imp _ = ()
  val op evaluate_call_FFI_rel_imp = TDB.find "evaluate_call_FFI_rel_imp"
  fun op evaluate_call_FFI_rel _ = ()
  val op evaluate_call_FFI_rel = TDB.find "evaluate_call_FFI_rel"
  fun op evaluate_append _ = ()
  val op evaluate_append = TDB.find "evaluate_append"
  fun op evaluate_add_to_clock_io_events_mono _ = ()
  val op evaluate_add_to_clock_io_events_mono = TDB.find
    "evaluate_add_to_clock_io_events_mono"
  fun op evaluate_add_to_clock _ = ()
  val op evaluate_add_to_clock = TDB.find "evaluate_add_to_clock"
  fun op evaluate_add_history _ = ()
  val op evaluate_add_history = TDB.find "evaluate_add_history"
  fun op evaluate_Apps_f_err _ = ()
  val op evaluate_Apps_f_err = TDB.find "evaluate_Apps_f_err"
  fun op evaluate_Apps_Rerr _ = ()
  val op evaluate_Apps_Rerr = TDB.find "evaluate_Apps_Rerr"
  fun op evaluate_Apps_Funs_timeout _ = ()
  val op evaluate_Apps_Funs_timeout = TDB.find "evaluate_Apps_Funs_timeout"
  fun op evaluate_Apps_Funs _ = ()
  val op evaluate_Apps_Funs = TDB.find "evaluate_Apps_Funs"
  fun op evaluate_Apps _ = ()
  val op evaluate_Apps = TDB.find "evaluate_Apps"
  fun op eval_no_eval_simulation _ = ()
  val op eval_no_eval_simulation = TDB.find "eval_no_eval_simulation"
  fun op do_app_refs_length _ = ()
  val op do_app_refs_length = TDB.find "do_app_refs_length"
  fun op do_app_io_events_mono _ = ()
  val op do_app_io_events_mono = TDB.find "do_app_io_events_mono"
  fun op do_app_ffi_unchanged _ = ()
  val op do_app_ffi_unchanged = TDB.find "do_app_ffi_unchanged"
  fun op do_app_ffi_mono _ = ()
  val op do_app_ffi_mono = TDB.find "do_app_ffi_mono"
  fun op do_app_call_FFI_rel _ = ()
  val op do_app_call_FFI_rel = TDB.find "do_app_call_FFI_rel"
  fun op do_app_SOME_ffi_same_oracle_state _ = ()
  val op do_app_SOME_ffi_same_oracle_state = TDB.find
    "do_app_SOME_ffi_same_oracle_state"
  fun op dest_IO_event_def _ = ()
  val op dest_IO_event_def = TDB.find "dest_IO_event_def"
  fun op dec_inc_clock _ = ()
  val op dec_inc_clock = TDB.find "dec_inc_clock"
  fun op combine_dec_result_eq_Rerr _ = ()
  val op combine_dec_result_eq_Rerr = TDB.find "combine_dec_result_eq_Rerr"
  fun op can_pmatch_all_EVERY _ = ()
  val op can_pmatch_all_EVERY = TDB.find "can_pmatch_all_EVERY"
  fun op call_FFI_return_unchanged _ = ()
  val op call_FFI_return_unchanged = TDB.find "call_FFI_return_unchanged"
  fun op call_FFI_rel_io_events_mono _ = ()
  val op call_FFI_rel_io_events_mono = TDB.find
    "call_FFI_rel_io_events_mono"
  fun op call_FFI_rel_def _ = ()
  val op call_FFI_rel_def = TDB.find "call_FFI_rel_def"
  fun op call_FFI_rel_consts _ = ()
  val op call_FFI_rel_consts = TDB.find "call_FFI_rel_consts"
  fun op call_FFI_LENGTH _ = ()
  val op call_FFI_LENGTH = TDB.find "call_FFI_LENGTH"
  fun op adj_clock_def _ = ()
  val op adj_clock_def = TDB.find "adj_clock_def"
  fun op RTC_call_FFI_rel_consts _ = ()
  val op RTC_call_FFI_rel_consts = TDB.find "RTC_call_FFI_rel_consts"
  fun op Apps_append _ = () val op Apps_append = TDB.find "Apps_append"
  
val _ = if !Globals.print_thy_loads then TextIO.print "done\n" else ()
val _ = Theory.load_complete "evaluateProps"

end
