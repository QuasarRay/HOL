signature evaluatePropsTheory =
sig
  type thm = Thm.thm
  
  (*  Definitions  *)
    val adj_clock_def : thm
    val call_FFI_rel_def : thm
    val dest_IO_event_def : thm
    val io_events_mono_def : thm
    val is_clock_io_mono_def : thm
  
  (*  Theorems  *)
    val Apps_append : thm
    val RTC_call_FFI_rel_consts : thm
    val call_FFI_LENGTH : thm
    val call_FFI_rel_consts : thm
    val call_FFI_rel_io_events_mono : thm
    val call_FFI_return_unchanged : thm
    val can_pmatch_all_EVERY : thm
    val combine_dec_result_eq_Rerr : thm
    val dec_inc_clock : thm
    val do_app_SOME_ffi_same_oracle_state : thm
    val do_app_call_FFI_rel : thm
    val do_app_ffi_mono : thm
    val do_app_ffi_unchanged : thm
    val do_app_io_events_mono : thm
    val do_app_refs_length : thm
    val eval_no_eval_simulation : thm
    val evaluate_Apps : thm
    val evaluate_Apps_Funs : thm
    val evaluate_Apps_Funs_timeout : thm
    val evaluate_Apps_Rerr : thm
    val evaluate_Apps_f_err : thm
    val evaluate_add_history : thm
    val evaluate_add_to_clock : thm
    val evaluate_add_to_clock_io_events_mono : thm
    val evaluate_append : thm
    val evaluate_call_FFI_rel : thm
    val evaluate_call_FFI_rel_imp : thm
    val evaluate_case_eqs : thm
    val evaluate_cons : thm
    val evaluate_decs_add_to_clock : thm
    val evaluate_decs_add_to_clock_io_events_mono : thm
    val evaluate_decs_append : thm
    val evaluate_decs_call_FFI_rel_imp : thm
    val evaluate_decs_clock_determ : thm
    val evaluate_decs_cons : thm
    val evaluate_decs_ffi_mono_clock : thm
    val evaluate_decs_nil : thm
    val evaluate_decs_set_clock : thm
    val evaluate_ffi_etc_intro : thm
    val evaluate_ffi_intro : thm
    val evaluate_history_irrelevance : thm
    val evaluate_io_events_mono : thm
    val evaluate_io_events_mono_imp : thm
    val evaluate_length : thm
    val evaluate_match_add_to_clock : thm
    val evaluate_match_list_result : thm
    val evaluate_match_minimal_clock : thm
    val evaluate_minimal_clock : thm
    val evaluate_next_exn_stamp_mono : thm
    val evaluate_next_type_stamp_mono : thm
    val evaluate_nil : thm
    val evaluate_refs_length_mono : thm
    val evaluate_set_clock : thm
    val evaluate_set_init_clock : thm
    val evaluate_set_next_stamps : thm
    val evaluate_sing : thm
    val io_events_mono_antisym : thm
    val io_events_mono_refl : thm
    val io_events_mono_trans : thm
    val is_clock_io_mono_acc_safe : thm
    val is_clock_io_mono_bind : thm
    val is_clock_io_mono_check : thm
    val is_clock_io_mono_cong : thm
    val is_clock_io_mono_do_app_simple : thm
    val is_clock_io_mono_err : thm
    val is_clock_io_mono_evaluate : thm
    val is_clock_io_mono_evaluate_decs : thm
    val is_clock_io_mono_extra : thm
    val is_clock_io_mono_extra_mono : thm
    val is_clock_io_mono_if_safe : thm
    val is_clock_io_mono_match_case_pair_safe : thm
    val is_clock_io_mono_match_case_safe : thm
    val is_clock_io_mono_minimal : thm
    val is_clock_io_mono_option_case_safe : thm
    val is_clock_io_mono_return : thm
    val is_clock_io_mono_set_clock : thm
    val list_result_eq_Rerr : thm
    val list_result_eq_Rval : thm
    val list_result_inj : thm
    val pair_CASE_eq_forall : thm
    val pmatch_not_type_error_EQ : thm
    val result_rel_list_result : thm
    val same_type_sym : thm
    val same_type_trans : thm
(*
   [evaluate] Parent theory of "evaluateProps"
   
   [semanticPrimitivesProps] Parent theory of "evaluateProps"
   
   [adj_clock_def]  Definition
      
      ⊢ ∀inc dec s.
          adj_clock inc dec s = s with clock := s.clock + inc − dec
   
   [call_FFI_rel_def]  Definition
      
      ⊢ ∀s1 s2.
          call_FFI_rel s1 s2 ⇔
          ∃n conf bytes t. call_FFI s1 n conf bytes = FFI_return s2 t
   
   [dest_IO_event_def]  Definition
      
      ⊢ ∀s c b. dest_IO_event (IO_event s c b) = (s,c,b)
   
   [io_events_mono_def]  Definition
      
      ⊢ ∀s1 s2.
          io_events_mono s1 s2 ⇔
          s1.io_events ≼ s2.io_events ∧
          (s2.io_events = s1.io_events ⇒ s2 = s1)
   
   [is_clock_io_mono_def]  Definition
      
      ⊢ ∀f s.
          is_clock_io_mono f s ⇔
          case f s of
            (s',r) =>
              io_events_mono s.ffi s'.ffi ∧ s'.clock ≤ s.clock ∧
              s.next_type_stamp ≤ s'.next_type_stamp ∧
              s.next_exn_stamp ≤ s'.next_exn_stamp ∧
              LENGTH s.refs ≤ LENGTH s'.refs ∧
              ∀clk.
                case f (s with clock := clk) of
                  (s'',r') =>
                    (r' ≠ Rerr (Rabort Rtimeout_error) ⇒
                     r ≠ Rerr (Rabort Rtimeout_error) ⇒
                     r' = r ∧
                     s'' = s' with clock := clk − (s.clock − s'.clock)) ∧
                    (r ≠ Rerr (Rabort Rtimeout_error) ⇒
                     (clk ≥ s.clock − s'.clock ⇔
                      r' ≠ Rerr (Rabort Rtimeout_error))) ∧
                    (r' ≠ Rerr (Rabort Rtimeout_error) ⇒
                     clk ≤ s.clock ⇒
                     r ≠ Rerr (Rabort Rtimeout_error)) ∧
                    (clk ≤ s.clock ⇒ io_events_mono s''.ffi s'.ffi)
   
   [Apps_append]  Theorem
      
      ⊢ ∀xs ys f. Apps f (xs ++ ys) = Apps (Apps f xs) ys
   
   [RTC_call_FFI_rel_consts]  Theorem
      
      ⊢ ∀s1 s2. call_FFI_rel꙳ s1 s2 ⇒ s2.oracle = s1.oracle
   
   [call_FFI_LENGTH]  Theorem
      
      ⊢ call_FFI st index conf x = FFI_return new_st new_bytes ⇒
        LENGTH x = LENGTH new_bytes
   
   [call_FFI_rel_consts]  Theorem
      
      ⊢ call_FFI_rel s1 s2 ⇒ s2.oracle = s1.oracle
   
   [call_FFI_rel_io_events_mono]  Theorem
      
      ⊢ ∀s1 s2. call_FFI_rel꙳ s1 s2 ⇒ io_events_mono s1 s2
   
   [call_FFI_return_unchanged]  Theorem
      
      ⊢ call_FFI ffi s conf bytes = FFI_return ffi bytes' ⇔
        s = ExtCall «» ∧ bytes' = bytes
   
   [can_pmatch_all_EVERY]  Theorem
      
      ⊢ can_pmatch_all envC refs ps v ⇔
        EVERY (λp. pmatch envC refs p v [] ≠ Match_type_error) ps
   
   [combine_dec_result_eq_Rerr]  Theorem
      
      ⊢ combine_dec_result env r = Rerr e ⇔ r = Rerr e
   
   [dec_inc_clock]  Theorem
      
      ⊢ dec_clock (adj_clock 1 0 s) = s
   
   [do_app_SOME_ffi_same_oracle_state]  Theorem
      
      ⊢ do_app (refs,ffi) op args = SOME ((refs',ffi'),r) ⇒
        do_app (refs,ffi with io_events := l) op args =
        SOME
          ((refs',
            ffi' with
            io_events := l ++ DROP (LENGTH ffi.io_events) ffi'.io_events),r)
   
   [do_app_call_FFI_rel]  Theorem
      
      ⊢ do_app (r,ffi) op vs = SOME ((r',ffi'),res) ⇒
        call_FFI_rel꙳ ffi ffi'
   
   [do_app_ffi_mono]  Theorem
      
      ⊢ do_app (refs,ffi) op args = SOME ((refs',ffi'),r) ⇒
        ∃l. ffi'.io_events = ffi.io_events ++ l
   
   [do_app_ffi_unchanged]  Theorem
      
      ⊢ do_app (refs,ffi) op vs = SOME ((refs',ffi),r) ⇒
        (∀outcome. r ≠ Rerr (Rabort (Rffi_error outcome))) ⇒
        ∀ffi2. do_app (refs,ffi2) op vs = SOME ((refs',ffi2),r)
   
   [do_app_io_events_mono]  Theorem
      
      ⊢ do_app (r,ffi) op vs = SOME ((r',ffi'),res) ⇒
        io_events_mono ffi ffi'
   
   [do_app_refs_length]  Theorem
      
      ⊢ do_app refs_ffi op vs = SOME res ⇒
        LENGTH (FST refs_ffi) ≤ LENGTH (FST (FST res))
   
   [eval_no_eval_simulation]  Theorem
      
      ⊢ (∀s env exps s' res.
           evaluate s env exps = (s',res) ∧ s.eval_state = NONE ∧
           res ≠ Rerr (Rabort Rtype_error) ⇒
           s'.eval_state = NONE ∧
           evaluate (s with eval_state := es) env exps =
           (s' with eval_state := es,res)) ∧
        (∀s env x pes err_x s' res.
           evaluate_match s env x pes err_x = (s',res) ∧
           s.eval_state = NONE ∧ res ≠ Rerr (Rabort Rtype_error) ⇒
           s'.eval_state = NONE ∧
           evaluate_match (s with eval_state := es) env x pes err_x =
           (s' with eval_state := es,res)) ∧
        ∀s env decs s' res.
          evaluate_decs s env decs = (s',res) ∧ s.eval_state = NONE ∧
          res ≠ Rerr (Rabort Rtype_error) ⇒
          s'.eval_state = NONE ∧
          evaluate_decs (s with eval_state := es) env decs =
          (s' with eval_state := es,res)
   
   [evaluate_Apps]  Theorem
      
      ⊢ ∀xs st env s1 s2 vs.
          evaluate st env xs = (s1,Rval vs) ∧ LENGTH xs = SUC (LENGTH ns) ∧
          nsLookup env.v n = SOME clos_v ∧
          do_opapp [clos_v; LAST vs] = SOME (env1,Funs ns e) ⇒
          evaluate st env [Apps (Var n) (REVERSE xs)] =
          if s1.clock < LENGTH xs then
            (s1 with clock := 0,Rerr (Rabort Rtimeout_error))
          else
            evaluate (s1 with clock := s1.clock − LENGTH xs)
              (env1 with
               v :=
                 nsAppend (alist_to_ns (ZIP (REVERSE ns,FRONT vs))) env1.v)
              [e]
   
   [evaluate_Apps_Funs]  Theorem
      
      ⊢ ∀l x ns vs st s1 s2 env env1 e.
          evaluate st env l = (s1,Rval vs) ∧
          evaluate s1 env [x] =
          (s2,Rval [Closure env1 (HD ns) (Funs (TL ns) e)]) ∧
          LENGTH l = LENGTH ns ∧ ns ≠ [] ∧ LENGTH ns ≤ s2.clock ⇒
          evaluate st env [Apps x (REVERSE l)] =
          evaluate (s2 with clock := s2.clock − LENGTH ns)
            (env1 with
             v := nsAppend (alist_to_ns (ZIP (REVERSE ns,vs))) env1.v) [e]
   
   [evaluate_Apps_Funs_timeout]  Theorem
      
      ⊢ ∀l x ns vs st s1 s2 env env1 e.
          evaluate st env l = (s1,Rval vs) ∧
          evaluate s1 env [x] =
          (s2,Rval [Closure env1 (HD ns) (Funs (TL ns) e)]) ∧
          LENGTH l = LENGTH ns ∧ ns ≠ [] ∧ s2.clock < LENGTH ns ⇒
          evaluate st env [Apps x (REVERSE l)] =
          (s2 with clock := 0,Rerr (Rabort Rtimeout_error))
   
   [evaluate_Apps_Rerr]  Theorem
      
      ⊢ ∀xs f st env s1 e.
          evaluate st env xs = (s1,Rerr e) ⇒
          evaluate st env [Apps f (REVERSE xs)] = (s1,Rerr e)
   
   [evaluate_Apps_f_err]  Theorem
      
      ⊢ ∀xs vs st envs1 f s1 s2.
          evaluate st env xs = (s1,Rval vs) ∧
          evaluate s1 env [f] = (s2,Rerr r) ⇒
          evaluate st env [Apps f (REVERSE xs)] = (s2,Rerr r)
   
   [evaluate_add_history]  Theorem
      
      ⊢ (∀st env exp st' res.
           evaluate (st with ffi := st.ffi with io_events := []) env exp =
           (st',res) ⇒
           evaluate st env exp =
           (st' with
            ffi :=
              st'.ffi with
              io_events := st.ffi.io_events ++ st'.ffi.io_events,res)) ∧
        ∀st env v pes err_v st' res.
          evaluate_match (st with ffi := st.ffi with io_events := []) env v
            pes err_v = (st',res) ⇒
          evaluate_match st env v pes err_v =
          (st' with
           ffi :=
             st'.ffi with
             io_events := st.ffi.io_events ++ st'.ffi.io_events,res)
   
   [evaluate_add_to_clock]  Theorem
      
      ⊢ ∀s env es s' r extra.
          evaluate s env es = (s',r) ∧ r ≠ Rerr (Rabort Rtimeout_error) ⇒
          evaluate (s with clock := s.clock + extra) env es =
          (s' with clock := s'.clock + extra,r)
   
   [evaluate_add_to_clock_io_events_mono]  Theorem
      
      ⊢ (∀s e d extra.
           io_events_mono (FST (evaluate s e d)).ffi
             (FST (evaluate (s with clock := s.clock + extra) e d)).ffi) ∧
        ∀s e v d er extra.
          io_events_mono (FST (evaluate_match s e v d er)).ffi
            (FST
               (evaluate_match (s with clock := s.clock + extra) e v d er)).
            ffi
   
   [evaluate_append]  Theorem
      
      ⊢ ∀s env xs ys.
          evaluate s env (xs ++ ys) =
          case evaluate s env xs of
            (s',Rval vs) =>
              (case evaluate s' env ys of
                 (s'',Rval vs') => (s'',Rval (vs ++ vs'))
               | (s'',Rerr v7) => (s'',Rerr v7))
          | (s',Rerr v9) => (s',Rerr v9)
   
   [evaluate_call_FFI_rel]  Theorem
      
      ⊢ (∀s e exp. call_FFI_rel꙳ s.ffi (FST (evaluate s e exp)).ffi) ∧
        (∀s e v pes errv.
           call_FFI_rel꙳ s.ffi (FST (evaluate_match s e v pes errv)).ffi) ∧
        ∀s e ds. call_FFI_rel꙳ s.ffi (FST (evaluate_decs s e ds)).ffi
   
   [evaluate_call_FFI_rel_imp]  Theorem
      
      ⊢ (∀s e p s' r. evaluate s e p = (s',r) ⇒ call_FFI_rel꙳ s.ffi s'.ffi) ∧
        (∀s e v pes errv s' r.
           evaluate_match s e v pes errv = (s',r) ⇒
           call_FFI_rel꙳ s.ffi s'.ffi) ∧
        ∀s e p s' r.
          evaluate_decs s e p = (s',r) ⇒ call_FFI_rel꙳ s.ffi s'.ffi
   
   [evaluate_case_eqs]  Theorem
      
      ⊢ (pair_CASE p f = v ⇔ ∃x y. p = (x,y) ∧ f x y = v) ∧
        (result_CASE x f f1 = v ⇔
         (∃a. x = Rval a ∧ f a = v) ∨ ∃e. x = Rerr e ∧ f1 e = v) ∧
        (error_result_CASE x f f1 = v ⇔
         (∃a. x = Rraise a ∧ f a = v) ∨ ∃a. x = Rabort a ∧ f1 a = v) ∧
        ((if x then t1 else t2) = v ⇔ (x ⇔ T) ∧ t1 = v ∨ (x ⇔ F) ∧ t2 = v) ∧
        (option_CASE opt nc sc = v ⇔
         opt = NONE ∧ nc = v ∨ ∃x. opt = SOME x ∧ sc x = v) ∧
        (list_CASE x v f = v' ⇔
         x = [] ∧ v = v' ∨ ∃a l. x = a::l ∧ f a l = v') ∧
        (exp_or_val_CASE x f f1 = v ⇔
         (∃e. x = Exp e ∧ f e = v) ∨ ∃v'. x = Val v' ∧ f1 v' = v) ∧
        (match_result_CASE x v v1 f = v' ⇔
         x = No_match ∧ v = v' ∨ x = Match_type_error ∧ v1 = v' ∨
         ∃a. x = Match a ∧ f a = v')
   
   [evaluate_cons]  Theorem
      
      ⊢ ∀s env e es.
          evaluate s env (e::es) =
          case evaluate s env [e] of
            (s',Rval vs) =>
              (case evaluate s' env es of
                 (s'',Rval vs') => (s'',Rval (vs ++ vs'))
               | (s'',Rerr v7) => (s'',Rerr v7))
          | (s',Rerr v9) => (s',Rerr v9)
   
   [evaluate_decs_add_to_clock]  Theorem
      
      ⊢ ∀s e p s' r extra.
          evaluate_decs s e p = (s',r) ∧ r ≠ Rerr (Rabort Rtimeout_error) ⇒
          evaluate_decs (s with clock := s.clock + extra) e p =
          (s' with clock := s'.clock + extra,r)
   
   [evaluate_decs_add_to_clock_io_events_mono]  Theorem
      
      ⊢ ∀s e d.
          io_events_mono (FST (evaluate_decs s e d)).ffi
            (FST (evaluate_decs (s with clock := s.clock + extra) e d)).ffi
   
   [evaluate_decs_append]  Theorem
      
      ⊢ ∀ds1 s env ds2.
          evaluate_decs s env (ds1 ++ ds2) =
          case evaluate_decs s env ds1 of
            (s1,Rval env1) =>
              (case evaluate_decs s1 (env1 +++ env) ds2 of
                 (s2,r) => (s2,combine_dec_result env1 r))
          | (s1,Rerr v7) => (s1,Rerr v7)
   
   [evaluate_decs_call_FFI_rel_imp]  Theorem
      
      ⊢ ∀s e p s' r.
          evaluate_decs s e p = (s',r) ⇒ call_FFI_rel꙳ s.ffi s'.ffi
   
   [evaluate_decs_clock_determ]  Theorem
      
      ⊢ ∀s e p s1 r1 s2 r2 k1 k2.
          evaluate_decs (s with clock := k1) e p = (s1,r1) ∧
          evaluate_decs (s with clock := k2) e p = (s2,r2) ⇒
          case (r1,r2) of
            (Rval v12,Rval v8) => s1.ffi = s2.ffi ∧ r1 = r2
          | (Rerr (Rraise v16),Rval v8) => s1.ffi = s2.ffi ∧ r1 = r2
          | (Rerr (Rabort Rtype_error),Rval v8) =>
            s1.ffi = s2.ffi ∧ r1 = r2
          | (Rerr (Rabort Rtimeout_error),Rval v8) => k1 < k2
          | (Rerr (Rabort (Rffi_error v19)),Rval v8) =>
            s1.ffi = s2.ffi ∧ r1 = r2
          | (Rval v24,Rerr (Rraise v28)) => s1.ffi = s2.ffi ∧ r1 = r2
          | (Rval v24,Rerr (Rabort Rtype_error)) =>
            s1.ffi = s2.ffi ∧ r1 = r2
          | (Rval v24,Rerr (Rabort Rtimeout_error)) => k2 < k1
          | (Rval v24,Rerr (Rabort (Rffi_error v31))) =>
            s1.ffi = s2.ffi ∧ r1 = r2
          | (Rerr (Rraise v40),Rerr (Rraise v36)) =>
            s1.ffi = s2.ffi ∧ r1 = r2
          | (Rerr (Rabort Rtype_error),Rerr (Rraise v36)) =>
            s1.ffi = s2.ffi ∧ r1 = r2
          | (Rerr (Rabort Rtimeout_error),Rerr (Rraise v36)) => k1 < k2
          | (Rerr (Rabort (Rffi_error v43)),Rerr (Rraise v36)) =>
            s1.ffi = s2.ffi ∧ r1 = r2
          | (Rerr (Rraise v48),Rerr (Rabort Rtype_error)) =>
            s1.ffi = s2.ffi ∧ r1 = r2
          | (Rerr (Rraise v48),Rerr (Rabort Rtimeout_error)) => k2 < k1
          | (Rerr (Rraise v48),Rerr (Rabort (Rffi_error v51))) =>
            s1.ffi = s2.ffi ∧ r1 = r2
          | (Rerr (Rabort Rtype_error),Rerr (Rabort Rtype_error)) =>
            s1.ffi = s2.ffi ∧ r1 = r2
          | (Rerr (Rabort Rtimeout_error),Rerr (Rabort Rtype_error)) =>
            k1 < k2
          | (Rerr (Rabort (Rffi_error v56)),Rerr (Rabort Rtype_error)) =>
            s1.ffi = s2.ffi ∧ r1 = r2
          | (Rerr (Rabort Rtype_error),Rerr (Rabort Rtimeout_error)) =>
            k2 < k1
          | (Rerr (Rabort Rtimeout_error),Rerr (Rabort Rtimeout_error)) =>
            T
          | (Rerr (Rabort (Rffi_error v59)),Rerr (Rabort Rtimeout_error)) =>
            k2 < k1
          | (Rerr (Rabort Rtype_error),Rerr (Rabort (Rffi_error v54))) =>
            s1.ffi = s2.ffi ∧ r1 = r2
          | (Rerr (Rabort Rtimeout_error),Rerr (Rabort (Rffi_error v54))) =>
            k1 < k2
          | (Rerr (Rabort (Rffi_error v61)),Rerr (Rabort (Rffi_error v54))) =>
            s1.ffi = s2.ffi ∧ r1 = r2
   
   [evaluate_decs_cons]  Theorem
      
      ⊢ ∀s env d ds.
          evaluate_decs s env (d::ds) =
          case evaluate_decs s env [d] of
            (s1,Rval env1) =>
              (case evaluate_decs s1 (env1 +++ env) ds of
                 (s2,r) => (s2,combine_dec_result env1 r))
          | (s1,Rerr v7) => (s1,Rerr v7)
   
   [evaluate_decs_ffi_mono_clock]  Theorem
      
      ⊢ ∀k1 k2 s e p.
          k1 ≤ k2 ⇒
          io_events_mono (FST (evaluate_decs (s with clock := k1) e p)).ffi
            (FST (evaluate_decs (s with clock := k2) e p)).ffi
   
   [evaluate_decs_nil]  Theorem
      
      ⊢ ∀s env.
          evaluate_decs s env [] = (s,Rval <|v := nsEmpty; c := nsEmpty|>)
   
   [evaluate_decs_set_clock]  Theorem
      
      ⊢ ∀s env decs s1 res.
          evaluate_decs s env decs = (s1,res) ∧
          res ≠ Rerr (Rabort Rtimeout_error) ⇒
          ∀ck. ∃ck1.
            evaluate_decs (s with clock := ck1) env decs =
            (s1 with clock := ck,res)
   
   [evaluate_ffi_etc_intro]  Theorem
      
      ⊢ evaluate s0 env xs = (s1,res) ∧
        (∀outcome. res ≠ Rerr (Rabort (Rffi_error outcome))) ∧
        s1.ffi = s0.ffi ∧ s1.next_type_stamp = s0.next_type_stamp ∧
        s1.next_exn_stamp = s0.next_exn_stamp ∧ s0.eval_state = NONE ∧
        res ≠ Rerr (Rabort Rtype_error) ∧ s.refs = s0.refs ⇒
        ∃ck1 ck2.
          evaluate (s with clock := ck1) env xs =
          (s with <|refs := s1.refs; clock := ck2|>,res)
   
   [evaluate_ffi_intro]  Theorem
      
      ⊢ (∀s env e s' r.
           evaluate s env e = (s',r) ∧ s'.ffi = s.ffi ∧
           (∀outcome. r ≠ Rerr (Rabort (Rffi_error outcome))) ⇒
           ∀nffi.
             evaluate (s with ffi := nffi) env e = (s' with ffi := nffi,r)) ∧
        (∀s env v pes errv s' r.
           evaluate_match s env v pes errv = (s',r) ∧ s'.ffi = s.ffi ∧
           (∀outcome. r ≠ Rerr (Rabort (Rffi_error outcome))) ⇒
           ∀nffi.
             evaluate_match (s with ffi := nffi) env v pes errv =
             (s' with ffi := nffi,r)) ∧
        ∀s env ds s' r.
          evaluate_decs s env ds = (s',r) ∧ s'.ffi = s.ffi ∧
          (∀outcome. r ≠ Rerr (Rabort (Rffi_error outcome))) ⇒
          ∀nffi.
            evaluate_decs (s with ffi := nffi) env ds =
            (s' with ffi := nffi,r)
   
   [evaluate_history_irrelevance]  Theorem
      
      ⊢ (∀st env exp st' res.
           evaluate st env exp = (st',res) ⇒
           ∃new_io.
             st'.ffi.io_events = st.ffi.io_events ++ new_io ∧
             ∀l. evaluate (st with ffi := st.ffi with io_events := l) env
                   exp =
                 (st' with ffi := st'.ffi with io_events := l ++ new_io,res)) ∧
        (∀st env v pes err_v st' res.
           evaluate_match st env v pes err_v = (st',res) ⇒
           ∃new_io.
             st'.ffi.io_events = st.ffi.io_events ++ new_io ∧
             ∀l. evaluate_match (st with ffi := st.ffi with io_events := l)
                   env v pes err_v =
                 (st' with ffi := st'.ffi with io_events := l ++ new_io,res)) ∧
        ∀st env ds st' res.
          evaluate_decs st env ds = (st',res) ⇒
          ∃new_io.
            st'.ffi.io_events = st.ffi.io_events ++ new_io ∧
            ∀l. evaluate_decs (st with ffi := st.ffi with io_events := l)
                  env ds =
                (st' with ffi := st'.ffi with io_events := l ++ new_io,res)
   
   [evaluate_io_events_mono]  Theorem
      
      ⊢ (∀s e exp. io_events_mono s.ffi (FST (evaluate s e exp)).ffi) ∧
        (∀s e v pes errv.
           io_events_mono s.ffi (FST (evaluate_match s e v pes errv)).ffi) ∧
        ∀s e d. io_events_mono s.ffi (FST (evaluate_decs s e d)).ffi
   
   [evaluate_io_events_mono_imp]  Theorem
      
      ⊢ (∀s e p s' r. evaluate s e p = (s',r) ⇒ io_events_mono s.ffi s'.ffi) ∧
        (∀s e v pes errv s' r.
           evaluate_match s e v pes errv = (s',r) ⇒
           io_events_mono s.ffi s'.ffi) ∧
        ∀s e p s' r.
          evaluate_decs s e p = (s',r) ⇒ io_events_mono s.ffi s'.ffi
   
   [evaluate_length]  Theorem
      
      ⊢ (∀s e p s' r. evaluate s e p = (s',Rval r) ⇒ LENGTH r = LENGTH p) ∧
        (∀s e v p er s' r.
           evaluate_match s e v p er = (s',Rval r) ⇒ LENGTH r = 1) ∧
        ∀s e ds s' r. evaluate_decs s e ds = (s',Rval r) ⇒ T
   
   [evaluate_match_add_to_clock]  Theorem
      
      ⊢ ∀s env v pes err_v s' r extra.
          evaluate_match s env v pes err_v = (s',r) ∧
          r ≠ Rerr (Rabort Rtimeout_error) ⇒
          evaluate_match (s with clock := s.clock + extra) env v pes err_v =
          (s' with clock := s'.clock + extra,r)
   
   [evaluate_match_list_result]  Theorem
      
      ⊢ evaluate_match s e v p er = (s',r) ⇒ ∃r'. r = list_result r'
   
   [evaluate_match_minimal_clock]  Theorem
      
      ⊢ ∀s env v pes err_v s' r k.
          evaluate_match s env v pes err_v = (s',r) ∧ s'.clock = 0 ∧
          r ≠ Rerr (Rabort Rtimeout_error) ∧ s.clock > k ⇒
          ∃s''.
            evaluate_match (s with clock := k) env v pes err_v =
            (s'',Rerr (Rabort Rtimeout_error)) ∧
            io_events_mono s''.ffi s'.ffi
   
   [evaluate_minimal_clock]  Theorem
      
      ⊢ ∀s env es s' r k.
          evaluate s env es = (s',r) ∧ s'.clock = 0 ∧
          r ≠ Rerr (Rabort Rtimeout_error) ∧ s.clock > k ⇒
          ∃s''.
            evaluate (s with clock := k) env es =
            (s'',Rerr (Rabort Rtimeout_error)) ∧
            io_events_mono s''.ffi s'.ffi
   
   [evaluate_next_exn_stamp_mono]  Theorem
      
      ⊢ (evaluate s env es = (s',res1) ⇒
         s.next_exn_stamp ≤ s'.next_exn_stamp) ∧
        (evaluate_match s env v pes err_v = (s',res2) ⇒
         s.next_exn_stamp ≤ s'.next_exn_stamp) ∧
        (evaluate_decs s env ds = (s',res3) ⇒
         s.next_exn_stamp ≤ s'.next_exn_stamp)
   
   [evaluate_next_type_stamp_mono]  Theorem
      
      ⊢ (evaluate s env es = (s',res1) ⇒
         s.next_type_stamp ≤ s'.next_type_stamp) ∧
        (evaluate_match s env v pes err_v = (s',res2) ⇒
         s.next_type_stamp ≤ s'.next_type_stamp) ∧
        (evaluate_decs s env ds = (s',res3) ⇒
         s.next_type_stamp ≤ s'.next_type_stamp)
   
   [evaluate_nil]  Theorem
      
      ⊢ ∀s env. evaluate s env [] = (s,Rval [])
   
   [evaluate_refs_length_mono]  Theorem
      
      ⊢ (∀s env es s' r.
           evaluate s env es = (s',r) ⇒ LENGTH s.refs ≤ LENGTH s'.refs) ∧
        ∀s env v pes err_v s' r.
          evaluate_match s env v pes err_v = (s',r) ⇒
          LENGTH s.refs ≤ LENGTH s'.refs
   
   [evaluate_set_clock]  Theorem
      
      ⊢ ∀s env exps s1 res.
          evaluate s env exps = (s1,res) ∧
          res ≠ Rerr (Rabort Rtimeout_error) ⇒
          ∀ck. ∃ck1.
            evaluate (s with clock := ck1) env exps =
            (s1 with clock := ck,res)
   
   [evaluate_set_init_clock]  Theorem
      
      ⊢ evaluate st env xs = (st',res) ∧ res ≠ Rerr (Rabort Rtimeout_error) ⇒
        ∀k. ∃ck res1 st1.
          evaluate (st with clock := k) env xs = (st1,res1) ∧
          (res1 = res ∧ st1 = st' with clock := ck ∨
           res1 = Rerr (Rabort Rtimeout_error) ∧
           io_events_mono st1.ffi st'.ffi)
   
   [evaluate_set_next_stamps]  Theorem
      
      ⊢ (∀s0 env xs s1 res.
           evaluate s0 env xs = (s1,res) ⇒
           (s1.next_type_stamp = s0.next_type_stamp ⇒
            ∀k. evaluate (s0 with next_type_stamp := k) env xs =
                (s1 with next_type_stamp := k,res)) ∧
           (s1.next_exn_stamp = s0.next_exn_stamp ⇒
            ∀k. evaluate (s0 with next_exn_stamp := k) env xs =
                (s1 with next_exn_stamp := k,res))) ∧
        (∀s0 env v pes errv s1 res.
           evaluate_match s0 env v pes errv = (s1,res) ⇒
           (s1.next_type_stamp = s0.next_type_stamp ⇒
            ∀k. evaluate_match (s0 with next_type_stamp := k) env v pes
                  errv = (s1 with next_type_stamp := k,res)) ∧
           (s1.next_exn_stamp = s0.next_exn_stamp ⇒
            ∀k. evaluate_match (s0 with next_exn_stamp := k) env v pes errv =
                (s1 with next_exn_stamp := k,res))) ∧
        ∀s0 env ds s1 res.
          evaluate_decs s0 env ds = (s1,res) ⇒
          (s1.next_type_stamp = s0.next_type_stamp ⇒
           ∀k. evaluate_decs (s0 with next_type_stamp := k) env ds =
               (s1 with next_type_stamp := k,res)) ∧
          (s1.next_exn_stamp = s0.next_exn_stamp ⇒
           ∀k. evaluate_decs (s0 with next_exn_stamp := k) env ds =
               (s1 with next_exn_stamp := k,res))
   
   [evaluate_sing]  Theorem
      
      ⊢ ∀s env e s' vs. evaluate s env [e] = (s',Rval vs) ⇒ ∃v. vs = [v]
   
   [io_events_mono_antisym]  Theorem
      
      ⊢ io_events_mono s1 s2 ∧ io_events_mono s2 s1 ⇒ s1 = s2
   
   [io_events_mono_refl]  Theorem
      
      ⊢ io_events_mono ffi ffi
   
   [io_events_mono_trans]  Theorem
      
      ⊢ io_events_mono ffi1 ffi2 ∧ io_events_mono ffi2 ffi3 ⇒
        io_events_mono ffi1 ffi3
   
   [is_clock_io_mono_acc_safe]  Theorem
      
      ⊢ ∀v g.
          (∀st clk. f (st with clock := clk) = f st) ∧
          (f st = v ∨ f st ≠ v) ∧ is_clock_io_mono (λst'. g (f st) st') st ⇒
          is_clock_io_mono (λst'. g (f st') st') st
   
   [is_clock_io_mono_bind]  Theorem
      
      ⊢ is_clock_io_mono f s ∧
        (∀s' r. f s = (s',r) ⇒ is_clock_io_mono (g r) s') ∧
        (∀s'.
           g (Rerr (Rabort Rtimeout_error)) s' =
           (s',Rerr (Rabort Rtimeout_error))) ⇒
        is_clock_io_mono (λs. case f s of (s',r) => g r s') s
   
   [is_clock_io_mono_check]  Theorem
      
      ⊢ (s.clock ≠ 0 ⇒
         is_clock_io_mono (λs. f (adj_clock 1 0 s)) (dec_clock s)) ⇒
        is_clock_io_mono
          (λs.
               if s.clock = 0 then (s,Rerr (Rabort Rtimeout_error))
               else f s) s
   
   [is_clock_io_mono_cong]  Theorem
      
      ⊢ s = t ⇒
        (∀s. s.eval_state = t.eval_state ∧ s.refs = t.refs ∧ s.ffi = t.ffi ⇒
             f s = g s) ⇒
        (is_clock_io_mono f s ⇔ is_clock_io_mono g t)
   
   [is_clock_io_mono_do_app_simple]  Theorem
      
      ⊢ ∀xs st.
          is_clock_io_mono
            (λst'.
                 case do_app (st'.refs,st'.ffi) op xs of
                   NONE => (st',Rerr (Rabort Rtype_error))
                 | SOME ((refs,ffi),r) =>
                   (st' with <|refs := refs; ffi := ffi|>,list_result r))
            st
   
   [is_clock_io_mono_err]  Theorem
      
      ⊢ is_clock_io_mono (λs. (s,Rerr r)) s
   
   [is_clock_io_mono_evaluate]  Theorem
      
      ⊢ (∀s env es. is_clock_io_mono (λs. evaluate s env es) s) ∧
        (∀s env v pes err_v.
           is_clock_io_mono (λs. evaluate_match s env v pes err_v) s) ∧
        ∀s env ds. is_clock_io_mono (λs. evaluate_decs s env ds) s
   
   [is_clock_io_mono_evaluate_decs]  Theorem
      
      ⊢ ∀s e p. is_clock_io_mono (λs. evaluate_decs s e p) s
   
   [is_clock_io_mono_extra]  Theorem
      
      ⊢ (∀s. is_clock_io_mono f s) ⇒
        f s = (s',r) ∧ r ≠ Rerr (Rabort Rtimeout_error) ⇒
        f (s with clock := s.clock + extra) =
        (s' with clock := s'.clock + extra,r)
   
   [is_clock_io_mono_extra_mono]  Theorem
      
      ⊢ (∀s. is_clock_io_mono f s) ⇒
        io_events_mono (FST (f s)).ffi
          (FST (f (s with clock := s.clock + extra))).ffi
   
   [is_clock_io_mono_if_safe]  Theorem
      
      ⊢ (∀st clk. f (st with clock := clk) ⇔ f st) ∧
        is_clock_io_mono (λst'. if f st then j st' else k st') st ⇒
        is_clock_io_mono (λst'. if f st' then j st' else k st') st
   
   [is_clock_io_mono_match_case_pair_safe]  Theorem
      
      ⊢ (∀st clk. f (st with clock := clk) = f st) ∧
        is_clock_io_mono
          (λst'.
               (st',
                case f st of
                  No_match => g st'
                | Match_type_error => h st'
                | Match env => j env st')) st ⇒
        is_clock_io_mono
          (λst'.
               (st',
                case f st' of
                  No_match => g st'
                | Match_type_error => h st'
                | Match env => j env st')) st
   
   [is_clock_io_mono_match_case_safe]  Theorem
      
      ⊢ (∀st clk. f (st with clock := clk) = f st) ∧
        is_clock_io_mono
          (λst'.
               case f st of
                 No_match => g st'
               | Match_type_error => h st'
               | Match env => j env st') st ⇒
        is_clock_io_mono
          (λst'.
               case f st' of
                 No_match => g st'
               | Match_type_error => h st'
               | Match env => j env st') st
   
   [is_clock_io_mono_minimal]  Theorem
      
      ⊢ is_clock_io_mono f s ⇒
        f s = (s',r) ∧ s'.clock = 0 ∧ r ≠ Rerr (Rabort Rtimeout_error) ∧
        s.clock > k ⇒
        ∃s''.
          f (s with clock := k) = (s'',Rerr (Rabort Rtimeout_error)) ∧
          io_events_mono s''.ffi s'.ffi
   
   [is_clock_io_mono_option_case_safe]  Theorem
      
      ⊢ (∀st clk. f (st with clock := clk) = f st) ∧
        is_clock_io_mono
          (λst'. case f st of NONE => g st' | SOME x => h x st') st ⇒
        is_clock_io_mono
          (λst'. case f st' of NONE => g st' | SOME x => h x st') st
   
   [is_clock_io_mono_return]  Theorem
      
      ⊢ is_clock_io_mono (λs. (s,Rval r)) s
   
   [is_clock_io_mono_set_clock]  Theorem
      
      ⊢ is_clock_io_mono f s ⇒
        f s = (s',r) ∧ r ≠ Rerr (Rabort Rtimeout_error) ⇒
        ∃ck0. f (s with clock := ck0) = (s' with clock := ck1,r)
   
   [list_result_eq_Rerr]  Theorem
      
      ⊢ list_result r = Rerr e ⇔ r = Rerr e
   
   [list_result_eq_Rval]  Theorem
      
      ⊢ list_result r = Rval r' ⇔ ∃v. r' = [v] ∧ r = Rval v
   
   [list_result_inj]  Theorem
      
      ⊢ list_result x = list_result y ⇒ x = y
   
   [pair_CASE_eq_forall]  Theorem
      
      ⊢ (case x of (a,b) => P a b) ⇔ ∀a b. x = (a,b) ⇒ P a b
   
   [pmatch_not_type_error_EQ]  Theorem
      
      ⊢ (pmatch envC refs Pany v acc ≠ Match_type_error ⇔ T) ∧
        (pmatch envC refs (Pvar n) v acc ≠ Match_type_error ⇔ T) ∧
        (pmatch envC refs (Pcon (SOME name) xs) v acc ≠ Match_type_error ⇔
         ∃ys t l stamp.
           v = Conv (SOME t) ys ∧ nsLookup envC name = SOME (l,stamp) ∧
           LENGTH xs = l ∧ same_type stamp t ∧
           (t = stamp ⇒
            l = LENGTH ys ∧
            pmatch_list envC refs xs ys acc ≠ Match_type_error)) ∧
        (pmatch envC refs (Pcon NONE xs) v acc ≠ Match_type_error ⇔
         ∃ys.
           v = Conv NONE ys ∧ LENGTH xs = LENGTH ys ∧
           pmatch_list envC refs xs ys acc ≠ Match_type_error) ∧
        (pmatch_list envC refs [] [] acc ≠ Match_type_error ⇔ T) ∧
        (pmatch_list envC refs [] (v::vs) acc ≠ Match_type_error ⇔ F) ∧
        (pmatch_list envC refs (p::ps) [] acc ≠ Match_type_error ⇔ F) ∧
        (pmatch_list envC refs (p::ps) (v::vs) acc ≠ Match_type_error ⇔
         pmatch envC refs p v acc ≠ Match_type_error ∧
         (∀a. pmatch envC refs p v acc = No_match ⇒
              pmatch_list envC refs ps vs acc ≠ Match_type_error) ∧
         ∀a. pmatch envC refs p v acc = Match a ⇒
             pmatch_list envC refs ps vs a ≠ Match_type_error)
   
   [result_rel_list_result]  Theorem
      
      ⊢ result_rel (LIST_REL R) Q (list_result r1) (list_result r2) ⇔
        result_rel R Q r1 r2
   
   [same_type_sym]  Theorem
      
      ⊢ same_type t1 t2 ⇒ same_type t2 t1
   
   [same_type_trans]  Theorem
      
      ⊢ same_type t1 t2 ∧ same_type t1 t3 ⇒ same_type t2 t3
   
   
*)
end
